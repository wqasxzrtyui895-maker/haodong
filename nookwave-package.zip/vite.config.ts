import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Pure static build configuration for seamless deployment to Qoder Sites
export default defineConfig({
  plugins: [react()],
  build: {
    outDir: 'dist',
    sourcemap: false,
  },
});
