/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        cream: '#FAF6EB',
        'cream-dark': '#EFE7D3',
        mint: '#78C2AD',
        'mint-dark': '#55A48E',
        coral: '#F4A261',
        'coral-dark': '#E0843B',
        sage: '#52B788',
        espresso: '#4A4238',
        'espresso-light': '#7A6F62',
      },
      fontFamily: {
        rounded: [
          '"Quicksand"',
          '"Nunito"',
          '"PingFang SC"',
          '"Hiragino Sans GB"',
          '"Microsoft YaHei"',
          'system-ui',
          'sans-serif',
        ],
      },
      boxShadow: {
        nook: '0 4px 0 #4A4238',
        'nook-sm': '0 2px 0 #4A4238',
        'nook-lg': '0 6px 0 #4A4238',
      },
    },
  },
  plugins: [],
};
