import { LanguageCode } from '../types/island';
import { translateSmart } from './apiAdapter';

export interface VoiceStreamCallbacks {
  onVolumeChange: (volume: number) => void; // 0~100 实时麦克风音量
  onInterimResult: (interimOriginal: string, interimTranslated: string) => void;
  onFinalResult: (finalOriginal: string, finalTranslated: string) => void;
  onError: (errorMsg: string) => void;
}

/**
 * Plugin slot interface for custom real-time streaming voice translation modules.
 * Assign an implementation to `voiceTranslatorBridge.customPipeline` to override
 * the built-in browser SpeechRecognition + smart translation engine.
 */
export interface CustomVoicePipeline {
  start: (
    sourceLang: LanguageCode,
    targetLang: LanguageCode,
    callbacks: VoiceStreamCallbacks
  ) => Promise<void>;
  stop: () => void;
}

interface SpeechRecognitionAlternative {
  transcript: string;
}

interface SpeechRecognitionResult {
  isFinal: boolean;
  0: SpeechRecognitionAlternative;
}

interface SpeechRecognitionEventLike {
  resultIndex: number;
  results: ArrayLike<SpeechRecognitionResult>;
}

interface SpeechRecognitionLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((ev: SpeechRecognitionEventLike) => void) | null;
  onerror: ((ev: { error: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
}

const SPEECH_LANG_MAP: Record<LanguageCode, string> = {
  zh: 'zh-CN',
  en: 'en-US',
  ja: 'ja-JP',
  ko: 'ko-KR',
  fr: 'fr-FR',
  es: 'es-ES',
  ar: 'ar-AE',
};

const DEMO_SCRIPTS: Array<{
  lang: LanguageCode;
  chunks: string[];
  final: string;
}> = [
  {
    lang: 'zh',
    chunks: ['今天工作太累啦', '今天工作太累啦，好想来杯冰美式', '今天工作太累啦，好想来杯冰美式续命！'],
    final: '今天工作太累啦，好想来杯冰美式续命！',
  },
  {
    lang: 'zh',
    chunks: ['今晚的夜宵', '今晚的夜宵想吃一碗', '今晚的夜宵想吃一碗热腾腾的拉面！'],
    final: '今晚的夜宵想吃一碗热腾腾的拉面！',
  },
  {
    lang: 'en',
    chunks: ['Heya island friends', 'Heya island friends, the sea breeze', 'Heya island friends, the sea breeze is so chill tonight!'],
    final: 'Heya island friends, the sea breeze is so chill tonight!',
  },
];

export class VoiceTranslatorBridge {
  /**
   * Plug in your custom streaming voice translation module here.
   */
  public customPipeline: CustomVoicePipeline | null = null;

  private recognition: SpeechRecognitionLike | null = null;
  private mediaStream: MediaStream | null = null;
  private audioCtx: AudioContext | null = null;
  private rafId: number | null = null;
  private demoTimerIds: number[] = [];
  private isListening = false;
  private latestTranscript = '';

  public isMicSupported(): boolean {
    if (typeof window === 'undefined') return false;
    const win = window as unknown as {
      SpeechRecognition?: unknown;
      webkitSpeechRecognition?: unknown;
    };
    return Boolean(
      (win.SpeechRecognition || win.webkitSpeechRecognition) &&
        navigator.mediaDevices &&
        navigator.mediaDevices.getUserMedia
    );
  }

  public async startListening(
    sourceLang: LanguageCode,
    targetLang: LanguageCode,
    callbacks: VoiceStreamCallbacks
  ): Promise<void> {
    if (this.isListening) return;
    this.isListening = true;
    this.latestTranscript = '';

    // Delegate to custom plugin pipeline (EchoBridge real-time engine) if provided
    if (this.customPipeline) {
      try {
        await this.customPipeline.start(sourceLang, targetLang, callbacks);
        return;
      } catch {
        // Graceful fallback to native SpeechRecognition if customPipeline server is offline
      }
    }

    const win = window as unknown as {
      SpeechRecognition?: new () => SpeechRecognitionLike;
      webkitSpeechRecognition?: new () => SpeechRecognitionLike;
    };
    const SpeechRecCtor = win.SpeechRecognition || win.webkitSpeechRecognition;

    if (!SpeechRecCtor || !navigator.mediaDevices?.getUserMedia) {
      this.isListening = false;
      callbacks.onError('');
      return;
    }

    try {
      this.mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      this.startVolumeMeter(this.mediaStream, callbacks.onVolumeChange);
    } catch {
      this.isListening = false;
      callbacks.onError('');
      return;
    }

    const recognition = new SpeechRecCtor();
    recognition.lang = SPEECH_LANG_MAP[sourceLang] || 'zh-CN';
    recognition.continuous = true;
    recognition.interimResults = true;

    recognition.onresult = (event) => {
      let interim = '';
      let finalText = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const res = event.results[i];
        const text = res[0]?.transcript || '';
        if (res.isFinal) {
          finalText += text;
        } else {
          interim += text;
        }
      }

      const combined = (finalText || interim).trim();
      if (!combined) return;
      this.latestTranscript = combined;

      const translated = translateSmart(combined, sourceLang, targetLang).translatedText;
      if (finalText.trim()) {
        callbacks.onFinalResult(finalText.trim(), translated);
        this.latestTranscript = '';
      } else {
        callbacks.onInterimResult(combined, translated);
      }
    };

    recognition.onerror = () => {
      // Silent 3-tier degradation: never expose raw network/permission error banners
      this.cleanup();
    };

    recognition.onend = () => {
      if (this.isListening && this.latestTranscript.trim()) {
        const translated = translateSmart(
          this.latestTranscript.trim(),
          sourceLang,
          targetLang
        ).translatedText;
        callbacks.onFinalResult(this.latestTranscript.trim(), translated);
        this.latestTranscript = '';
      }
      this.cleanup();
    };

    this.recognition = recognition;
    try {
      recognition.start();
    } catch {
      this.cleanup();
      callbacks.onError('');
    }
  }

  public stopListening(): void {
    if (!this.isListening) return;
    if (this.customPipeline) {
      this.customPipeline.stop();
      this.isListening = false;
      return;
    }
    try {
      this.recognition?.stop();
    } catch {
      this.cleanup();
    }
  }

  /**
   * 3-second zero-mic fallback demo: simulates live volume rings + streaming bilingual bubbles.
   */
  public runSimulatedDemo(
    sourceLang: LanguageCode,
    targetLang: LanguageCode,
    callbacks: VoiceStreamCallbacks,
    onDone?: () => void
  ): void {
    this.stopDemo();
    const candidates = DEMO_SCRIPTS.filter((d) => d.lang === sourceLang);
    const script =
      candidates.length > 0
        ? candidates[Math.floor(Math.random() * candidates.length)]
        : DEMO_SCRIPTS[0];

    let step = 0;
    const volInterval = window.setInterval(() => {
      step += 1;
      const wave = Math.round(40 + Math.sin(step * 0.7) * 28 + Math.random() * 24);
      callbacks.onVolumeChange(Math.min(100, Math.max(12, wave)));
    }, 110);
    this.demoTimerIds.push(volInterval);

    script.chunks.forEach((chunk, idx) => {
      const t = window.setTimeout(() => {
        const translated = translateSmart(chunk, script.lang, targetLang).translatedText;
        callbacks.onInterimResult(chunk, translated);
      }, 450 + idx * 750);
      this.demoTimerIds.push(t);
    });

    const finishTimer = window.setTimeout(() => {
      window.clearInterval(volInterval);
      callbacks.onVolumeChange(0);
      const finalTranslated = translateSmart(script.final, script.lang, targetLang).translatedText;
      callbacks.onFinalResult(script.final, finalTranslated);
      onDone?.();
    }, 2900);
    this.demoTimerIds.push(finishTimer);
  }

  public stopDemo(): void {
    for (const id of this.demoTimerIds) {
      window.clearTimeout(id);
      window.clearInterval(id);
    }
    this.demoTimerIds = [];
  }

  /**
   * Speak translated text aloud using browser native Web Speech Synthesis.
   */
  public speakTTS(text: string, lang: LanguageCode): void {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    try {
      window.speechSynthesis.cancel();
      const utter = new SpeechSynthesisUtterance(text);
      utter.lang = SPEECH_LANG_MAP[lang] || 'en-US';
      utter.rate = 1.02;
      utter.pitch = 1.08;
      window.speechSynthesis.speak(utter);
    } catch {
      // Ignore TTS errors in restricted environments
    }
  }

  private startVolumeMeter(stream: MediaStream, onVolumeChange: (v: number) => void): void {
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;

    this.audioCtx = new AudioCtx();
    const source = this.audioCtx.createMediaStreamSource(stream);
    const analyser = this.audioCtx.createAnalyser();
    analyser.fftSize = 256;
    source.connect(analyser);

    const dataArray = new Uint8Array(analyser.frequencyBinCount);
    const tick = () => {
      if (!this.isListening) return;
      analyser.getByteFrequencyData(dataArray);
      let sum = 0;
      for (let i = 0; i < dataArray.length; i++) {
        sum += dataArray[i];
      }
      const avg = sum / dataArray.length;
      const normalized = Math.min(100, Math.round((avg / 90) * 100));
      onVolumeChange(normalized);
      this.rafId = window.requestAnimationFrame(tick);
    };
    this.rafId = window.requestAnimationFrame(tick);
  }

  private cleanup(): void {
    this.isListening = false;
    if (this.rafId !== null) {
      window.cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((t) => t.stop());
      this.mediaStream = null;
    }
    if (this.audioCtx) {
      void this.audioCtx.close();
      this.audioCtx = null;
    }
    this.recognition = null;
  }
}

export const voiceTranslatorBridge = new VoiceTranslatorBridge();
