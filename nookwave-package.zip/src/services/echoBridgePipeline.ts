import { LanguageCode } from '../types/island';
import { CustomVoicePipeline, VoiceStreamCallbacks } from './voiceTranslatorBridge';

const STORAGE_KEYS = {
  BACKEND_URL: 'nookwave_echobridge_url',
  DS_KEY: 'nookwave_echobridge_dskey',
  SPEAKER_NAME: 'nookwave_echobridge_speaker',
  ENABLE_AUDIO: 'nookwave_echobridge_audio',
};

export function getEchoBridgeConfig(): {
  backendUrl: string;
  dashscopeApiKey: string;
  enableAudio: boolean;
} {
  if (typeof window === 'undefined') {
    return { backendUrl: 'http://127.0.0.1:8910', dashscopeApiKey: '', enableAudio: true };
  }
  return {
    backendUrl: localStorage.getItem(STORAGE_KEYS.BACKEND_URL) || 'http://127.0.0.1:8910',
    dashscopeApiKey: localStorage.getItem(STORAGE_KEYS.DS_KEY) || '',
    enableAudio: localStorage.getItem(STORAGE_KEYS.ENABLE_AUDIO) !== 'false',
  };
}

export function saveEchoBridgeConfig(cfg: {
  backendUrl: string;
  dashscopeApiKey?: string;
  enableAudio?: boolean;
}): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEYS.BACKEND_URL, cfg.backendUrl.trim() || 'http://127.0.0.1:8910');
  if (typeof cfg.dashscopeApiKey === 'string') {
    localStorage.setItem(STORAGE_KEYS.DS_KEY, cfg.dashscopeApiKey.trim());
  }
  if (typeof cfg.enableAudio === 'boolean') {
    localStorage.setItem(STORAGE_KEYS.ENABLE_AUDIO, String(cfg.enableAudio));
  }
}

function toWsBase(httpBase: string): string {
  const clean = httpBase.trim().replace(/\/+$/, '');
  if (clean.startsWith('https://')) return 'wss://' + clean.slice(8);
  if (clean.startsWith('http://')) return 'ws://' + clean.slice(7);
  if (clean.startsWith('ws://') || clean.startsWith('wss://')) return clean;
  return 'ws://' + clean;
}

export async function checkEchoBridgeHealth(): Promise<boolean> {
  const { backendUrl } = getEchoBridgeConfig();
  const base = backendUrl.trim().replace(/\/+$/, '');
  const ctrl = new AbortController();
  const timer = window.setTimeout(() => ctrl.abort(), 1800);
  try {
    const res = await fetch(`${base}/health`, { signal: ctrl.signal });
    window.clearTimeout(timer);
    return res.ok;
  } catch {
    window.clearTimeout(timer);
    return false;
  }
}

function downsampleToInt16(floatSamples: Float32Array, inRate: number, outRate: number): Int16Array {
  if (inRate === outRate) {
    const out = new Int16Array(floatSamples.length);
    for (let i = 0; i < floatSamples.length; i++) {
      const s = Math.max(-1, Math.min(1, floatSamples[i]));
      out[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
    }
    return out;
  }
  const ratio = inRate / outRate;
  const newLen = Math.floor(floatSamples.length / ratio);
  const out = new Int16Array(newLen);
  for (let i = 0; i < newLen; i++) {
    const idx = i * ratio;
    const lo = Math.floor(idx);
    const hi = Math.min(floatSamples.length - 1, lo + 1);
    const frac = idx - lo;
    const val = floatSamples[lo] * (1 - frac) + floatSamples[hi] * frac;
    const s = Math.max(-1, Math.min(1, val));
    out[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
  }
  return out;
}

export class EchoBridgeVoicePipeline implements CustomVoicePipeline {
  private ws: WebSocket | null = null;
  private captureStream: MediaStream | null = null;
  private captureCtx: AudioContext | null = null;
  private captureSource: MediaStreamAudioSourceNode | null = null;
  private captureNode: AudioNode | null = null;
  private playCtx: AudioContext | null = null;
  private playRate = 24000;
  private nextPlayTime = 0;
  private running = false;
  private currentSource = '';
  private currentTarget = '';

  public async start(
    sourceLang: LanguageCode,
    targetLang: LanguageCode,
    callbacks: VoiceStreamCallbacks
  ): Promise<void> {
    if (this.running) return;
    this.running = true;
    this.currentSource = '';
    this.currentTarget = '';

    const cfg = getEchoBridgeConfig();
    if (!navigator.mediaDevices?.getUserMedia) {
      this.running = false;
      throw new Error('MIC_UNSUPPORTED');
    }

    try {
      this.captureStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
    } catch {
      this.running = false;
      throw new Error('MIC_DENIED');
    }

    try {
      await this.openWebSocket(sourceLang, targetLang, cfg, callbacks);
    } catch (err) {
      this.stop();
      throw err;
    }

    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) {
      this.stop();
      throw new Error('AUDIO_CTX_UNSUPPORTED');
    }

    this.captureCtx = new AudioCtx();
    this.captureSource = this.captureCtx.createMediaStreamSource(this.captureStream);
    const silentGain = this.captureCtx.createGain();
    silentGain.gain.value = 0;

    let workletAttached = false;
    if (this.captureCtx.audioWorklet) {
      try {
        await this.captureCtx.audioWorklet.addModule('/audio-worklet.js');
        const workletNode = new AudioWorkletNode(this.captureCtx, 'pcm16-downsample-processor');
        workletNode.port.onmessage = (e: MessageEvent<{ pcm?: ArrayBuffer; rms?: number }>) => {
          if (!this.running || !this.ws || this.ws.readyState !== WebSocket.OPEN) return;
          const { pcm, rms } = e.data;
          callbacks.onVolumeChange(Math.min(100, Math.round((rms || 0) * 420)));
          if (pcm) this.ws.send(pcm);
        };
        this.captureNode = workletNode;
        workletAttached = true;
      } catch {
        workletAttached = false;
      }
    }

    if (!workletAttached) {
      const scriptNode = this.captureCtx.createScriptProcessor(1024, 1, 1);
      const pcmStash: number[] = [];
      scriptNode.onaudioprocess = (ev) => {
        if (!this.running || !this.ws || this.ws.readyState !== WebSocket.OPEN) return;
        const input = ev.inputBuffer.getChannelData(0);
        let sq = 0;
        for (let i = 0; i < input.length; i++) sq += input[i] * input[i];
        const rms = Math.sqrt(sq / input.length);
        callbacks.onVolumeChange(Math.min(100, Math.round(rms * 420)));

        const int16 = downsampleToInt16(input, this.captureCtx?.sampleRate || 48000, 16000);
        for (let i = 0; i < int16.length; i++) pcmStash.push(int16[i]);
        while (pcmStash.length >= 640) {
          const frame = new Int16Array(pcmStash.splice(0, 640));
          this.ws.send(frame.buffer);
        }
      };
      this.captureNode = scriptNode;
    }

    if (this.captureNode) {
      this.captureSource.connect(this.captureNode);
      this.captureNode.connect(silentGain);
    }
    silentGain.connect(this.captureCtx.destination);
  }

  public stop(): void {
    this.running = false;
    if (this.captureNode) {
      this.captureNode.disconnect();
      this.captureNode = null;
    }
    if (this.captureSource) {
      this.captureSource.disconnect();
      this.captureSource = null;
    }
    if (this.captureCtx) {
      void this.captureCtx.close().catch(() => {});
      this.captureCtx = null;
    }
    if (this.captureStream) {
      this.captureStream.getTracks().forEach((t) => t.stop());
      this.captureStream = null;
    }
    if (this.ws) {
      try {
        if (this.ws.readyState === WebSocket.OPEN) {
          this.ws.send(JSON.stringify({ type: 'stop' }));
        }
        this.ws.close();
      } catch {
        // ignore
      }
      this.ws = null;
    }
  }

  private openWebSocket(
    sourceLang: LanguageCode,
    targetLang: LanguageCode,
    cfg: { backendUrl: string; dashscopeApiKey: string; enableAudio: boolean },
    callbacks: VoiceStreamCallbacks
  ): Promise<void> {
    return new Promise((resolve, reject) => {
      const wsUrl = `${toWsBase(cfg.backendUrl)}/ws/web-translate`;
      const sock = new WebSocket(wsUrl);
      sock.binaryType = 'arraybuffer';
      this.ws = sock;
      let settled = false;

      const connectTimeout = window.setTimeout(() => {
        if (!settled) {
          settled = true;
          sock.close();
          reject(new Error('ECHOBRIDGE_TIMEOUT'));
        }
      }, 3000);

      sock.onopen = () => {
        const speakerName =
          (typeof window !== 'undefined' && localStorage.getItem(STORAGE_KEYS.SPEAKER_NAME)) ||
          'NookWave 旅人';
        sock.send(
          JSON.stringify({
            type: 'start',
            source_lang: sourceLang,
            target_lang: targetLang,
            enable_audio: cfg.enableAudio,
            live_voice_clone: true,
            voice_id: '',
            vad_silence_ms: 400,
            noise_gate: true,
            glossary: [
              { source: 'NookWave', target: 'NookWave' },
              { source: 'Kenji', target: 'Kenji' },
              { source: 'Tariq', target: 'Tariq' },
              { source: 'Camille', target: 'Camille' },
              { source: 'Minji', target: 'Minji' },
            ],
            speaker_name: speakerName,
            dashscope_api_key: cfg.dashscopeApiKey,
          })
        );
      };

      sock.onmessage = (ev: MessageEvent) => {
        if (ev.data instanceof ArrayBuffer) {
          if (cfg.enableAudio) this.schedulePcm16Playback(ev.data);
          return;
        }
        let msg: Record<string, unknown>;
        try {
          msg = JSON.parse(String(ev.data)) as Record<string, unknown>;
        } catch {
          return;
        }

        if (msg.type === 'status' && msg.ready) {
          window.clearTimeout(connectTimeout);
          if (!settled) {
            settled = true;
            resolve();
          }
        } else if (msg.type === 'audio_format') {
          this.playRate = Number(msg.sample_rate || 24000);
        } else if (msg.type === 'source_delta') {
          this.currentSource = String(msg.text || '');
          callbacks.onInterimResult(this.currentSource, this.currentTarget);
        } else if (msg.type === 'target_delta') {
          this.currentTarget = String(msg.text || '');
          callbacks.onInterimResult(this.currentSource, this.currentTarget);
        } else if (msg.type === 'target_final') {
          const src = String(msg.source || this.currentSource || '').trim();
          const tgt = String(msg.target || this.currentTarget || '').trim();
          this.currentSource = '';
          this.currentTarget = '';
          if (src || tgt) {
            callbacks.onFinalResult(src || tgt, tgt || src);
          }
        } else if (msg.type === 'error') {
          window.clearTimeout(connectTimeout);
          if (!settled) {
            settled = true;
            reject(new Error(String(msg.message || 'ECHOBRIDGE_ERROR')));
          }
        }
      };

      sock.onerror = () => {
        window.clearTimeout(connectTimeout);
        if (!settled) {
          settled = true;
          reject(new Error('ECHOBRIDGE_WS_ERROR'));
        }
      };

      sock.onclose = () => {
        window.clearTimeout(connectTimeout);
        if (this.running) this.stop();
      };
    });
  }

  private schedulePcm16Playback(arrayBuffer: ArrayBuffer): void {
    if (!arrayBuffer || arrayBuffer.byteLength < 2) return;
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;

    if (!this.playCtx || this.playCtx.state === 'closed') {
      this.playCtx = new AudioCtx({ sampleRate: this.playRate });
      this.nextPlayTime = this.playCtx.currentTime;
    }
    if (this.playCtx.state === 'suspended') {
      void this.playCtx.resume().catch(() => {});
    }

    const view = new DataView(arrayBuffer);
    const count = Math.floor(arrayBuffer.byteLength / 2);
    const buffer = this.playCtx.createBuffer(1, count, this.playRate);
    const ch = buffer.getChannelData(0);
    for (let i = 0; i < count; i++) {
      ch[i] = view.getInt16(i * 2, true) / 32768.0;
    }
    const src = this.playCtx.createBufferSource();
    src.buffer = buffer;
    src.connect(this.playCtx.destination);
    const now = this.playCtx.currentTime;
    if (this.nextPlayTime < now + 0.02) this.nextPlayTime = now + 0.04;
    src.start(this.nextPlayTime);
    this.nextPlayTime += buffer.duration;
  }
}

export const echoBridgePipeline = new EchoBridgeVoicePipeline();
