import {
  ChatMessage,
  FurnitureId,
  IslanderProfile,
  LanguageCode,
  MessageBottle,
  ReactionType,
} from '../types/island';

// Toggle to `true` when connecting to Qoder Cloud Functions (/api/messages, /api/chat, /api/bottles)
export const USE_CLOUD_BACKEND = false;

const STORAGE_KEYS = {
  MESSAGES: 'nookwave_messages_v3',
  BOTTLES: 'nookwave_bottles_v3',
  USER: 'nookwave_user_v1',
  STAMPS: 'nookwave_stamps_v1',
  ROOM: 'nookwave_room_v1',
  FURNITURE: 'nookwave_furniture_v1',
  MILES: 'nookwave_miles_v1',
  UNLOCKED: 'nookwave_unlocked_v1',
};

export const AI_ISLANDERS: IslanderProfile[] = [
  {
    id: 'ai-kenji',
    name: 'Kenji (ケンジ)',
    species: 'shiba',
    color: '#F4A261',
    avatarStyle: { furColor: '#F4A261', headwear: 'leaf', eyewear: 'none', outfit: 'sweater' },
    nativeLang: 'ja',
    city: '东京 · 下北泽',
    countryFlag: '🇯🇵',
    isAI: true,
    persona: '深夜拉面店主，热心爽朗，爱用游戏和动漫梗接话',
  },
  {
    id: 'ai-tariq',
    name: 'Tariq (طارق)',
    species: 'fennec',
    color: '#E9C46A',
    avatarStyle: { furColor: '#E9C46A', headwear: 'none', eyewear: 'sunglasses', outfit: 'bowtie' },
    nativeLang: 'ar',
    city: '迪拜 · Alserkal',
    countryFlag: '🇦🇪',
    isAI: true,
    persona: '精品咖啡烘焙师，热情风趣，精通阿拉伯语和英语',
  },
  {
    id: 'ai-camille',
    name: 'Camille',
    species: 'calico',
    color: '#F28482',
    avatarStyle: { furColor: '#F28482', headwear: 'beret', eyewear: 'glasses', outfit: 'scarf' },
    nativeLang: 'fr',
    city: '巴黎 · 玛黑区',
    countryFlag: '🇫🇷',
    isAI: true,
    persona: '独立书店插画师，浪漫细腻，喜欢分享巴黎街角日常',
  },
  {
    id: 'ai-minji',
    name: 'Minji (민지)',
    species: 'tiger',
    color: '#F8F4EC',
    avatarStyle: { furColor: '#F8F4EC', headwear: 'headphones', eyewear: 'blush', outfit: 'sailor' },
    nativeLang: 'ko',
    city: '首尔 · 汉江',
    countryFlag: '🇰🇷',
    isAI: true,
    persona: 'Lo-fi 音乐制作人，松弛治愈，总是带着温暖的节奏',
  },
];

type MultilingualDict = Record<LanguageCode, { text: string; pron: string }>;

interface TranslationRule {
  keywords: RegExp;
  translations: MultilingualDict;
  culturalTip: string;
}

const SLANG_RULES: TranslationRule[] = [
  {
    keywords: /(咖啡|续命|提神|冰美式|coffee|espresso|latte|café|قهوة|커피|コーヒー)/i,
    translations: {
      zh: { text: '来杯冰美式原地满血复活！☕', pron: 'Lái bēi bīng měi shì yuán dì mǎn xuè fù huó!' },
      en: { text: 'Grabbing an iced coffee to recharge my HP! ☕', pron: 'ˈɡræbɪŋ ən aɪst ˈkɒfi tə ˌriːˈtʃɑːdʒ maɪ eɪtʃ-piː' },
      ja: { text: 'アイスコーヒーでHP全回復だ〜！☕', pron: 'Aisu kōhī de HP zenkaifuku da~!' },
      ko: { text: '아이스 아메리카노로 HP 풀충전 중! ☕', pron: 'Aiseu amerikano-ro HP pulchungjeon jung!' },
      fr: { text: 'Un petit café serré pour recharger les batteries ! ☕', pron: 'Un pti ka-fé sé-ré pour re-char-jé lé ba-tri !' },
      es: { text: '¡Un cafecito para recargar la barra de energía! ☕', pron: 'Un ka-fe-si-to pa-ra re-kar-gar la e-ner-hí-a!' },
      ar: { text: 'قهوة مختصة سريعة لشحن الطاقة! ☕', pron: 'Qahwa mukhtassa sari‘a li-shahn at-taqa!' },
    },
    culturalTip: '💡 文化小贴士：日语与韩语年轻人常用游戏术语「HP回復 / 풀충전」形容喝咖啡续命。',
  },
  {
    keywords: /(摸鱼|划水|偷懒|下班|放假|好累|加班|chill|relax|off work|tired|퇴근|휴식|サボ|退勤)/i,
    translations: {
      zh: { text: '今日份能量告急，申请海边篝火旁躺平充电~ 🌴', pron: 'Jīn rì fèn néng liàng gào jí, shēn qǐng tǎng píng chōng diàn~' },
      en: { text: 'Clocking out mentally—time to chill by the campfire! 🌴', pron: 'ˈklɒkɪŋ aʊt ˈmɛntəli — taɪm tə tʃɪl' },
      ja: { text: 'お疲れさま！今日はここまで、焚き火の横でのんびりしよう〜 🌴', pron: 'Otsukaresama! Takibi no yoko de nonbiri shiyō~' },
      ko: { text: '오늘도 고생 많았어요! 바닷가에서 멍때리기 모드~ 🌴', pron: 'Oneuldo gosaeng manhasseoyo! Meongttaerigi modeu~' },
      fr: { text: 'Mode détente activé, on profite de la brise marine ! 🌴', pron: 'Mod dé-tant ak-ti-vé, on pro-fit de la briz ma-rin !' },
      es: { text: '¡Modo relax activado junto a las olas! 🌴', pron: 'Mo-do re-laks ak-ti-ba-do hun-to a las o-las!' },
      ar: { text: 'انتهى وقت العمل، حان وقت الاسترخاء أمام أمواج البحر! 🌴', pron: 'Intaha waqt al-‘amal, hana waqt al-istirkha!' },
    },
    culturalTip: '💡 文化小贴士：韩语「멍때리기 (发呆放空)」是首尔年轻人的解压流行词，甚至有专门的发呆大赛！',
  },
  {
    keywords: /(拉面|夜宵|饿|美食|好吃|屋台|ramen|hungry|food|ラーメン|야식|맛있|dîner)/i,
    translations: {
      zh: { text: '深夜灵魂呼唤：一碗热腾腾的豚骨拉面最治愈！🍜', pron: 'Shēn yè líng hún hū huàn: yī wǎn rè téng téng de lā miàn!' },
      en: { text: 'Late-night soul craving: a steaming bowl of ramen! 🍜', pron: 'leɪt naɪt səʊl ˈkreɪvɪŋ: ə ˈstiːmɪŋ bəʊl əv ˈrɑːmən' },
      ja: { text: '深夜の飯テロ！熱々の豚骨ラーメンが染みる〜！🍜', pron: 'Shin’ya no meshi tero! Atsuatsu no tonkotsu rāmen ga shimiru~!' },
      ko: { text: '야식 타임! 뜨끈한 라멘 한 그릇이면 천국이지~ 🍜', pron: 'Yasik taim! Tteukkeunhan ramen han geureusimyeon cheongugiji~' },
      fr: { text: 'Envie nocturne d’un bon ramen fumant, un vrai régal ! 🍜', pron: 'An-vi nok-turn dun bon ra-mèn fu-man !' },
      es: { text: '¡Antojo nocturno de un buen ramen calentito! 🍜', pron: 'An-to-ho nok-tur-no de un bwen ra-men ka-len-ti-to!' },
      ar: { text: 'وجبة منتصف الليل المثالية: وعاء رامن ساخن! 🍜', pron: 'Wajbat muntasaf al-layl: wi‘a ramen sakhin!' },
    },
    culturalTip: '💡 文化小贴士：日语「飯テロ (美食恐怖袭击)」指深夜晒诱人美食让人瞬间肚子饿的可爱网络梗。',
  },
  {
    keywords: /(你好|嗨|打招呼|认识|朋友|遇见|hello|hi|hey|bonjour|hola|안녕|こんに|مرحبا)/i,
    translations: {
      zh: { text: '哈喽呀新岛友！海风刚刚好，一起在篝火边聊聊天吧~ ✨', pron: 'Hā lóu ya xīn dǎo yǒu! Yī qǐ zài gōu huǒ biān liáo liáo tiān ba~' },
      en: { text: 'Heya island neighbor! The sea breeze is lovely—pull up a seat by the campfire! ✨', pron: 'ˈheɪə ˈaɪlənd ˈneɪbə! ðə siː briːz ɪz ˈlʌvli' },
      ja: { text: 'やっほー！潮風が気持ちいいね、焚き火を囲んでお話しよ〜 ✨', pron: 'Yahhō! Shiokaze ga kimochī ne, takibi o kakonde ohanashi yo~' },
      ko: { text: '안녕~! 바닷바람이 딱 좋다, 모닥불 옆에서 수다 떨자! ✨', pron: 'Annyeong~! Badatbarami ttak jota, modakbul yeopeseo suda tteolja!' },
      fr: { text: 'Coucou voisin d’île ! La brise est douce, viens près du feu de camp ! ✨', pron: 'Kou-kou vwa-zin dil ! La briz é dous, vyin prè du feu de kan !' },
      es: { text: '¡Hola vecin@ de isla! Qué buena brisa, ven junto a la fogata ✨', pron: 'O-la be-si-no de is-la! Ben hun-to a la fo-ga-ta!' },
      ar: { text: 'أهلاً بجارنا الجديد! نسيم البحر لطيف، تعال بجانب نار المخيم ✨', pron: 'Ahlan bi-jarina al-jadid! Nasim al-bahr latif!' },
    },
    culturalTip: '💡 文化小贴士：法语熟人打招呼常用叠词「Coucou (咕咕)」，像小鸟一样轻快亲切。',
  },
  {
    keywords: /(音乐|歌|好听|电台|music|song|lofi|노래|音楽|musique)/i,
    translations: {
      zh: { text: '海浪声混着 Lo-fi 鼓点，这波氛围感直接拉满！🎧', pron: 'Hǎi làng shēng hùn zhe Lo-fi gǔ diǎn, fēn wéi gǎn lā mǎn!' },
      en: { text: 'Ocean waves mixed with lo-fi beats—immaculate vibes! 🎧', pron: 'ˈəʊʃn weɪvz mɪkst wɪð ˈləʊfaɪ biːts — ɪˈmækjʊlət vaɪbz' },
      ja: { text: '波の音とLo-fiビートが最高にチルいね！🎧', pron: 'Nami no oto to Lo-fi bīto ga saikō ni chirui ne!' },
      ko: { text: '파도 소리랑 로파이 비트 조합 진짜 감성 터진다~ 🎧', pron: 'Pado sorirang ropai biteu johap jinjja gamseong teojinda~' },
      fr: { text: 'Le bruit des vagues avec du lo-fi, c’est purement magique ! 🎧', pron: 'Le brwi dé vag a-vèk du lo-fi, sè pur-man ma-jik !' },
      es: { text: '¡Olas del mar con ritmos lo-fi, vibra total! 🎧', pron: 'O-las del mar kon rit-mos lo-fi, bi-bra to-tal!' },
      ar: { text: 'أمواج البحر مع موسيقى هادئة، أجواء خيالية! 🎧', pron: 'Amwaj al-bahr ma‘a musiqa hadia, ajwa khayaliyya!' },
    },
    culturalTip: '💡 文化小贴士：日语「チルい (Chill-i)」是将英文 Chill 形容词化的流行语，表示松弛治愈。',
  },
  {
    keywords: /(晚安|睡觉|困|好梦|goodnight|sleep|おやすみ|잘자|bonne nuit)/i,
    translations: {
      zh: { text: '今晚星光超温柔，祝你在海浪声里做个甜梦呀 🌙', pron: 'Jīn wǎn xīng guāng chāo wēn róu, zhù nǐ zuò gè tián mèng ya' },
      en: { text: 'The stars are extra gentle tonight—sweet dreams by the shore 🌙', pron: 'ðə stɑːz ər ˈɛkstrə ˈdʒɛntl təˈnaɪt — swiːt driːmz' },
      ja: { text: '今夜は星がきれいだね、波の音を聴きながらおやすみ〜 🌙', pron: 'Kon’ya wa hoshi ga kirei da ne, nami no oto o kikinagara oyasumi~' },
      ko: { text: '오늘 밤 별빛이 진짜 포근하다, 꿀잠 자요~ 🌙', pron: 'Oneul bam byeolbichi jinjja pogeunhada, kkuljam jayo~' },
      fr: { text: 'Les étoiles veillent sur l’île, fais de doux rêves 🌙', pron: 'Lé zé-twal vèy sur lil, fè de dou rèv' },
      es: { text: 'Las estrellas brillan suave hoy, dulces sueños 🌙', pron: 'Las es-tre-yas bri-yan swa-be oy, dul-ses swe-nyos' },
      ar: { text: 'النجوم هادئة الليلة، أحلاماً سعيدة على شاطئ الجزيرة 🌙', pron: 'An-nujum hadia al-layla, ahlaman sa‘ida!' },
    },
    culturalTip: '💡 文化小贴士：韩语「꿀잠 (蜂蜜觉)」用来形容像蜂蜜一样香甜深沉的睡眠。',
  },
  {
    keywords: /(谢谢|感谢|多谢|thanks|thank you|merci|ありがとう|고마워|شكرا)/i,
    translations: {
      zh: { text: '太感谢啦！能在这个小岛遇见你真好 🌸', pron: 'Tài gǎn xiè la! Néng zài zhè gè xiǎo dǎo yù jiàn nǐ zhēn hǎo' },
      en: { text: 'Thank you so much! So glad we crossed paths on this island 🌸', pron: 'θæŋk juː səʊ mʌtʃ!' },
      ja: { text: '本当にありがとう！この島で出会えて嬉しいよ〜 🌸', pron: 'Hontō ni arigatō! Kono shima de deaete ureshī yo~' },
      ko: { text: '진짜 고마워요! 이 섬에서 만나서 너무 반가워~ 🌸', pron: 'Jinjja gomawoyo! I seom-eseo mannaseo neomu bangawo~' },
      fr: { text: 'Merci infiniment ! Ravie de te croiser sur l’île 🌸', pron: 'Mèr-si in-fi-ni-man !' },
      es: { text: '¡Muchas gracias! Qué alegría coincidir en la isla 🌸', pron: 'Mu-chas gra-sias!' },
      ar: { text: 'شكراً جزيلاً لك! سعيد جداً بلقائك هنا 🌸', pron: 'Shukran jazilan laka!' },
    },
    culturalTip: '💡 文化小贴士：法语「Merci beaucoup」表示非常感谢，而「Merci infiniment」更有浪漫诗意。',
  },
];

const LANG_LABEL: Record<LanguageCode, string> = {
  zh: '中文',
  en: 'English',
  ja: '日本語',
  ko: '한국어',
  fr: 'Français',
  es: 'Español',
  ar: 'العربية',
};

const PROPER_NOUNS = ['NookWave', 'Kenji', 'Tariq', 'Camille', 'Minji', 'Dodo'];
const recentContextBuffer: string[] = [];

export function translateSmart(
  text: string,
  fromLang: LanguageCode,
  toLang: LanguageCode
): { translatedText: string; pronunciation?: string; culturalTip?: string } {
  const clean = text.trim();
  if (!clean) return { translatedText: '' };

  // Keep recent 6 turns of context
  recentContextBuffer.push(clean);
  if (recentContextBuffer.length > 6) recentContextBuffer.shift();

  for (const rule of SLANG_RULES) {
    if (rule.keywords.test(clean)) {
      const target = rule.translations[toLang] ?? rule.translations.en;
      // Preserve proper nouns mentioned in original text if any
      const mentioned = PROPER_NOUNS.filter((n) =>
        new RegExp(`\\b${n}\\b`, 'i').test(clean)
      );
      const outText =
        mentioned.length > 0 && !target.text.includes(mentioned[0])
          ? `${mentioned.join(' · ')}：${target.text}`
          : target.text;
      return {
        translatedText: outText,
        pronunciation: target.pron,
        culturalTip: rule.culturalTip,
      };
    }
  }

  if (fromLang === toLang) {
    return {
      translatedText: clean,
      culturalTip: '💡 文化小贴士：同语种电波直连中，切换上方目标语种或点击不同国家岛民即可体验跨文化俚语转译！',
    };
  }

  // Clean natural display without clunky boilerplate suffixes
  return {
    translatedText: clean,
    pronunciation: `${LANG_LABEL[fromLang]} → ${LANG_LABEL[toLang]} 实时转译`,
    culturalTip: '💡 文化小贴士：NookWave 会自动保留专有名词与语气词，让跨国聊天像同桌喝茶一样自然。',
  };
}

interface PresetUtterance {
  sender: IslanderProfile;
  originalText: string;
  pronunciation: string;
  translations: Record<LanguageCode, string>;
  culturalTip: string;
  offsetMs?: number;
}

const INITIAL_UTTERANCES: PresetUtterance[] = [
  {
    sender: AI_ISLANDERS[0], // Kenji
    originalText: 'いらっしゃい！深夜のラーメン屋台、今日も元気に営業中だよ〜🍜',
    pronunciation: 'Irasshai! Shin’ya no rāmen yatai, kyō mo genki ni eigyōchū da yo~',
    translations: {
      zh: '欢迎光临！东京深夜拉面摊今天也元气满满营业中哦～🍜',
      en: 'Welcome! My midnight ramen stall is open and buzzing tonight~ 🍜',
      ja: 'いらっしゃい！深夜のラーメン屋台、今日も元気に営業中だよ〜🍜',
      ko: '어서 오세요! 심야 라멘 포장마차 오늘도 활기차게 영업 중~ 🍜',
      fr: 'Bienvenue ! Mon stand de ramen nocturne est ouvert ce soir~ 🍜',
      es: '¡Bienvenido! Mi puesto nocturno de ramen ya está abierto~ 🍜',
      ar: 'أهلاً بك! كشك الرامن الليلي مفتوح بكل نشاط الليلة~ 🍜',
    },
    culturalTip: '💡 文化小贴士：日语「屋台 (Yatai)」指街头暖黄灯笼下的移动小摊，是深夜治愈灵魂的圣地。',
    offsetMs: 180000,
  },
  {
    sender: AI_ISLANDERS[1], // Tariq
    originalText: 'قهوة مختصة سريعة لشحن الطاقة! أحلى تحية من دبي ☕',
    pronunciation: 'Qahwa mukhtassa sari‘a li-shahn at-taqa! Ahla tahiyya min Dubai',
    translations: {
      zh: '来杯迪拜精品手冲咖啡原地回血！给你送上沙漠落日的问候 ☕',
      en: 'Specialty coffee to recharge your energy! Warmest greetings from Dubai ☕',
      ja: 'ドバイのスペシャルティコーヒーでHP回復！素敵な挨拶をお届け☕',
      ko: '두바이 스페셜티 커피로 에너지 충전! 따뜻한 인사 보냅니다 ☕',
      fr: 'Un café de spécialité de Dubaï pour recharger vos batteries ! ☕',
      es: '¡Café de especialidad desde Dubái para recargar energía! ☕',
      ar: 'قهوة مختصة سريعة لشحن الطاقة! أحلى تحية من دبي ☕',
    },
    culturalTip: '💡 文化小贴士：在迪拜咖啡文化中，豆蔻与藏红花风味的阿拉伯咖啡（Gahwa）象征最高规格的待客之道。',
    offsetMs: 120000,
  },
  {
    sender: AI_ISLANDERS[3], // Minji
    originalText: '파도 소리랑 로파이 비트 조합 진짜 감성 터진다~ 🎧',
    pronunciation: 'Pado sorirang ropai biteu johap jinjja gamseong teojinda~',
    translations: {
      zh: '海浪声配上 Lo-fi 鼓点，今晚的氛围感简直绝了～ 🎧',
      en: 'Ocean waves mixed with lo-fi beats—the vibe tonight is immaculate~ 🎧',
      ja: '波の音とLo-fiビートの組み合わせ、エモすぎて最高だね〜 🎧',
      ko: '파도 소리랑 로파이 비트 조합 진짜 감성 터진다~ 🎧',
      fr: 'Le bruit des vagues avec du lo-fi, l’ambiance est magique~ 🎧',
      es: 'Olas del mar con ritmos lo-fi, ¡una vibra increíble! 🎧',
      ar: 'أمواج البحر مع موسيقى لو-فاي، أجواء مريحة للغاية~ 🎧',
    },
    culturalTip: '💡 文化小贴士：韩语「감성 터진다 (感性爆发)」常用来形容夕阳、咖啡馆或好听的 Lo-fi 音乐带来的氛围感。',
    offsetMs: 60000,
  },
];

const AI_REPLY_POOL: Record<string, PresetUtterance[]> = {
  'ai-kenji': [
    {
      sender: AI_ISLANDERS[0],
      originalText: 'おおっ！それ最高だね！今度うちの特製ラーメンご馳走するよ〜🍜',
      pronunciation: 'Ō! Sore saikō da ne! Kondo uchi no tokusei rāmen gochisō suru yo~',
      translations: {
        zh: '哇哦太棒了吧！下次来我摊位请你吃独家秘制豚骨拉面～🍜',
        en: 'Whoa, that’s awesome! Next time my special ramen is on the house~ 🍜',
        ja: 'おおっ！それ最高だね！今度うちの特製ラーメンご馳走するよ〜🍜',
        ko: '우와 최고다! 다음에 우리 특제 라멘 한 그릇 대접할게요~ 🍜',
        fr: 'Oh génial ! La prochaine fois, je t’offre mon ramen maison~ 🍜',
        es: '¡Genial! La próxima vez te invito a mi ramen especial~ 🍜',
        ar: 'رائع جداً! المرة القادمة سأضيفك وعاء رامن خاص مجاناً~ 🍜',
      },
      culturalTip: '💡 文化小贴士：日语「ご馳走する (请客)」原意是“为了款待客人而四处奔波采购”，充满心意。',
    },
    {
      sender: AI_ISLANDERS[0],
      originalText: 'わかる〜！夜更かし仲間として、温かいお茶でも淹れようか？🍵',
      pronunciation: 'Wakaru~! Yofukashi nakama toshite, atatakai ocha demo ireyō ka?',
      translations: {
        zh: '太懂你了！同为熬夜搭子，要不要我给你泡杯热煎茶暖暖身？🍵',
        en: 'Totally feel you! As fellow night owls, shall I brew some warm green tea? 🍵',
        ja: 'わかる〜！夜更かし仲間として、温かいお茶でも淹れようか？🍵',
        ko: '완전 공감! 밤샘 친구로서 따뜻한 녹차 한 잔 우려줄까요? 🍵',
        fr: 'Je te comprends tellement ! Un petit thé chaud pour la nuit ? 🍵',
        es: '¡Te entiendo total! ¿Te preparo un té verde calentito? 🍵',
        ar: 'أفهمك تماماً! هل أعد لك كوباً من الشاي الأخضر الدافئ؟ 🍵',
      },
      culturalTip: '💡 文化小贴士：日语「わかる (我懂)」拉长音「わかる〜」是最常用的共情神词。',
    },
  ],
  'ai-tariq': [
    {
      sender: AI_ISLANDERS[1],
      originalText: 'يا سلام! هذه الروح الإيجابية تفتح النفس، تفضل كوب قهوة عربية! ☕',
      pronunciation: 'Ya salam! Hadhihi ar-ruh al-ijabiyya taftah an-nafs, tafaddal qahwa!',
      translations: {
        zh: '太赞啦！你这元气满满的样子真让人开心，快请喝一杯现煮阿拉伯咖啡！☕',
        en: 'Amazing energy! That really brightens the island—have a cup of Arabic coffee! ☕',
        ja: '最高だね！そのポジティブな空気感、アラビアンコーヒーをどうぞ！☕',
        ko: '최고예요! 긍정적인 에너지가 넘치네요, 아라비안 커피 한 잔 드세요! ☕',
        fr: 'Quelle belle énergie ! Prends donc une tasse de café arabe ! ☕',
        es: '¡Qué buena vibra! Toma una taza de café árabe recién hecho ☕',
        ar: 'يا سلام! هذه الروح الإيجابية تفتح النفس، تفضل كوب قهوة عربية! ☕',
      },
      culturalTip: '💡 文化小贴士：阿拉伯语「يا سلام (Ya Salam)」相当于“太棒了/绝了”，带有由衷的赞叹。',
    },
    {
      sender: AI_ISLANDERS[1],
      originalText: 'أجواء الجزيرة اليوم أجمل من غروب دبي، أهلاً بك دائماً! 🌴',
      pronunciation: 'Ajwa al-jazira al-yawm ajmal min ghurub Dubai, ahlan bika daiman!',
      translations: {
        zh: '今天小岛的氛围比迪拜湾的落日还要迷人，随时欢迎来喝咖啡！🌴',
        en: 'The island breeze today beats even a Dubai sunset—welcome anytime! 🌴',
        ja: '今日の島の空気はドバイの夕日以上に素敵だね、いつでも歓迎だよ！🌴',
        ko: '오늘 섬 분위기가 두바이 노을보다 더 예쁘네요, 언제든 환영해요! 🌴',
        fr: 'L’ambiance de l’île est encore plus belle qu’un coucher de soleil à Dubaï ! 🌴',
        es: '¡El ambiente de la isla supera hasta un atardecer en Dubái! 🌴',
        ar: 'أجواء الجزيرة اليوم أجمل من غروب دبي، أهلاً بك دائماً! 🌴',
      },
      culturalTip: '💡 文化小贴士：迪拜人常在落日后去海边散步，这是一天中最凉爽惬意的社交时段。',
    },
  ],
  'ai-camille': [
    {
      sender: AI_ISLANDERS[2],
      originalText: 'C’est tellement poétique ! Je vais en faire une aquarelle tout de suite 🎨',
      pronunciation: 'Sè tèl-man po-é-tik ! Je vè an fèr un a-kwa-rèl tout swit',
      translations: {
        zh: '这也太有诗意了吧！我这就拿出画本把它画成水彩画 🎨',
        en: 'That is so poetic! I’m going to paint a watercolor of this right away 🎨',
        ja: 'なんて詩的なんだろう！今すぐ水彩画に描いて残したくなるね 🎨',
        ko: '너무 시적이에요! 당장 수채화로 그려서 간직하고 싶네요 🎨',
        fr: 'C’est tellement poétique ! Je vais en faire une aquarelle tout de suite 🎨',
        es: '¡Qué poético! Voy a pintarlo en acuarela ahora mismo 🎨',
        ar: 'يا له من مشهد شاعري! سأرسمه بالألوان المائية فوراً 🎨',
      },
      culturalTip: '💡 文化小贴士：法语「C’est poétique」用来夸赞某件事物很有生活诗意与美感。',
    },
    {
      sender: AI_ISLANDERS[2],
      originalText: 'Un petit croissant virtuel pour accompagner ta journée sur l’île ! 🥐',
      pronunciation: 'Un pti krwa-san vir-tu-èl pour a-kon-pa-nyé ta jour-né sur lil !',
      translations: {
        zh: '送你一只刚出炉的虚拟可颂面包，陪你度过悠闲的小岛时光！🥐',
        en: 'Sending you a fresh virtual croissant to brighten your island day! 🥐',
        ja: '焼きたてのクロワッサンをどうぞ！島でのんびり過ごしてね 🥐',
        ko: '갓 구운 크루아상 하나 보내드려요! 섬에서 여유로운 하루 보내세요 🥐',
        fr: 'Un petit croissant virtuel pour accompagner ta journée sur l’île ! 🥐',
        es: '¡Un cruasán virtual recién horneado para tu día en la isla! 🥐',
        ar: 'كرواسون طازج افتراضي ليرافق يومك الجميل في الجزيرة! 🥐',
      },
      culturalTip: '💡 文化小贴士：在巴黎，清晨买刚出炉的可颂边走边吃叫作「Petit déjeuner sur le pouce」。',
    },
  ],
  'ai-minji': [
    {
      sender: AI_ISLANDERS[3],
      originalText: '헐 대박! 지금 만들고 있는 로파이 비트에 딱 어울리는 분위기야~ 🎧',
      pronunciation: 'Heol daebak! Jigeum mandeulgo inneun ropai biteu-e ttak eoullineun bunwigiya~',
      translations: {
        zh: '哇塞绝了！这跟我正在编的 Lo-fi 伴奏氛围简直是天作之合～ 🎧',
        en: 'Whoa, awesome! That matches the exact mood of the lo-fi beat I’m making~ 🎧',
        ja: 'えっ最高！今作ってるLo-fiビートにぴったりの雰囲気だよ〜 🎧',
        ko: '헐 대박! 지금 만들고 있는 로파이 비트에 딱 어울리는 분위기야~ 🎧',
        fr: 'Oh génial ! Ça colle parfaitement à l’ambiance de mon morceau lo-fi~ 🎧',
        es: '¡Qué increíble! Combina perfecto con el ritmo lo-fi que estoy creando~ 🎧',
        ar: 'يا للروعة! هذا يناسب تماماً أجواء مقطوعة اللو-فاي التي أصنعها~ 🎧',
      },
      culturalTip: '💡 文化小贴士：韩语「대박 (Daebak)」原意是“大发”，现在日常用来表达“超赞、太厉害了”。',
    },
    {
      sender: AI_ISLANDERS[3],
      originalText: '소확행 그 자체네요! 오늘도 파도 소리 들으면서 힐링하자 ✨',
      pronunciation: 'Sohwakhaeng geu jacheneyo! Oneuldo pado sori deureumyeonseo hillinghaja',
      translations: {
        zh: '这就是实打实的“小确幸”呀！今天也一起听着海浪声治愈一下吧 ✨',
        en: 'Pure everyday happiness! Let’s heal together listening to the waves ✨',
        ja: 'まさに小確幸だね！今日も波の音を聴きながら癒やされよう ✨',
        ko: '소확행 그 자체네요! 오늘도 파도 소리 들으면서 힐링하자 ✨',
        fr: 'C’est le vrai petit bonheur du quotidien ! Profitons des vagues ✨',
        es: '¡Pura felicidad cotidiana! Relajémonos escuchando las olas ✨',
        ar: 'إنها السعادة البسيطة بعينها! لنستمتع بصوت الأمواج معاً ✨',
      },
      culturalTip: '💡 文化小贴士：韩语「소확행 (小确幸)」源自村上春树，指生活中微小而确切的幸福。',
    },
  ],
};

function buildInitialMessages(userLang: LanguageCode): ChatMessage[] {
  const now = Date.now();
  return INITIAL_UTTERANCES.map((item, idx) => ({
    id: `init-${idx}`,
    roomId: 'NW-739K',
    sender: item.sender,
    originalText: item.originalText,
    originalLang: item.sender.nativeLang,
    translatedText: item.translations[userLang] ?? item.translations.zh,
    pronunciation: item.pronunciation,
    culturalTip: item.culturalTip,
    timestamp: now - (item.offsetMs ?? 60000),
  }));
}

const PRESET_BOTTLES: MessageBottle[] = [
  {
    id: 'b-tokyo',
    author: AI_ISLANDERS[0],
    originalText: '下北沢のレコード屋で雨宿り中。君の街は晴れてる？',
    translatedText: '正在下北泽的唱片店里躲雨，你的城市今天放晴了吗？',
    culturalTip: '💡 文化小贴士：东京下北泽是独立音乐与古着爱好者的天堂，雨天逛唱片店格外浪漫。',
    createdAt: Date.now() - 3600000 * 5,
    replies: [
      {
        authorName: 'Camille',
        authorFlag: '🇫🇷',
        originalText: 'Il fait un soleil magnifique à Paris !',
        translatedText: '巴黎今天阳光超级灿烂哦！',
      },
    ],
  },
  {
    id: 'b-dubai',
    author: AI_ISLANDERS[1],
    originalText: 'غروب الشمس فوق خور دبي يشبه كوب كراميل دافئ اليوم ☕',
    translatedText: '今天迪拜湾的落日，像极了一杯温暖的焦糖玛奇朵 ☕',
    culturalTip: '💡 文化小贴士：迪拜湾（Dubai Creek）傍晚常有传统木质渡船（Abra）穿梭在金色余晖中。',
    createdAt: Date.now() - 3600000 * 9,
    replies: [],
  },
  {
    id: 'b-paris',
    author: AI_ISLANDERS[2],
    originalText: 'J’ai trouvé un vieux carnet de croquis près de la Seine, plein de feuilles d’automne.',
    translatedText: '在塞纳河畔的旧书摊捡到一本夹满秋叶的素描本，想把这份浪漫寄给你。',
    culturalTip: '💡 文化小贴士：塞纳河畔的绿色铁皮旧书摊（Bouquinistes）已被列入世界文化遗产。',
    createdAt: Date.now() - 3600000 * 14,
    replies: [],
  },
  {
    id: 'b-seoul',
    author: AI_ISLANDERS[3],
    originalText: '연남동 골목에서 고양이랑 눈 마주쳤어! 오늘 운이 좋을 것 같아~',
    translatedText: '在延南洞的小巷里和三花猫对视了三秒！感觉今天会有好运降临~',
    culturalTip: '💡 文化小贴士：首尔延南洞的京义线林荫道被称为“Yeontral Park”，是年轻人散步听歌的热门地。',
    createdAt: Date.now() - 3600000 * 20,
    replies: [],
  },
  {
    id: 'b-reykjavik',
    author: {
      id: 'ai-freja',
      name: 'Freja',
      species: 'koala',
      color: '#90BE6D',
      nativeLang: 'en',
      city: '雷克雅未克',
      countryFlag: '🇮🇸',
      isAI: true,
    },
    originalText: 'Soaking in a warm geothermal pool while snowflakes land on my nose ❄️',
    translatedText: '正泡在冰岛的露天温泉里，雪花轻轻落在鼻尖上 ❄️',
    culturalTip: '💡 文化小贴士：在冰岛，去社区地热泳池泡澡聊天（Sundlaug）是最重要的日常社交方式。',
    createdAt: Date.now() - 3600000 * 28,
    replies: [],
  },
  {
    id: 'b-kyoto',
    author: {
      id: 'ai-haru',
      name: 'Haru (ハル)',
      species: 'panda',
      color: '#FAF6EB',
      nativeLang: 'ja',
      city: '京都 · 鸭川',
      countryFlag: '🇯🇵',
      isAI: true,
    },
    originalText: '鴨川のほとりで抹茶団子を食べながら、のんびり雲を眺めています🍵',
    translatedText: '在鸭川河畔吃着抹茶团子，慢悠悠地看着天上的云朵飘过 🍵',
    culturalTip: '💡 文化小贴士：京都鸭川岸边有个著名的“等距坐（等間隔）”，大家都会默契地留出舒适的社交距离。',
    createdAt: Date.now() - 3600000 * 35,
    replies: [],
  },
  {
    id: 'b-barcelona',
    author: {
      id: 'ai-mateo',
      name: 'Mateo',
      species: 'shiba',
      color: '#F3722C',
      nativeLang: 'es',
      city: '巴塞罗那',
      countryFlag: '🇪🇸',
      isAI: true,
    },
    originalText: '¡La brisa del Mediterráneo y una guitarra acústica en la plaza! 🎸',
    translatedText: '地中海的微风加上广场上的木吉他弹唱，生活就是一首诗！🎸',
    culturalTip: '💡 文化小贴士：西班牙语「Sobremesa」指饭后大家留在餐桌旁继续聊天喝茶的悠闲时光。',
    createdAt: Date.now() - 3600000 * 42,
    replies: [],
  },
  {
    id: 'b-lisbon',
    author: {
      id: 'ai-ines',
      name: 'Inês',
      species: 'calico',
      color: '#577590',
      nativeLang: 'en',
      city: '里斯本',
      countryFlag: '🇵🇹',
      isAI: true,
    },
    originalText: 'Warm pastel de nata fresh out of the oven—sending you the cinnamon scent!',
    translatedText: '刚出炉的葡式蛋挞热乎乎的，隔空分你一半肉桂香气！',
    culturalTip: '💡 文化小贴士：里斯本正宗蛋挞讲究外皮酥脆带焦糖斑点，撒上肉桂粉风味更佳。',
    createdAt: Date.now() - 3600000 * 50,
    replies: [],
  },
];

export const apiAdapter = {
  async getMessages(roomId: string, viewerLang: LanguageCode): Promise<ChatMessage[]> {
    if (USE_CLOUD_BACKEND) {
      const res = await fetch(`/api/messages?roomId=${encodeURIComponent(roomId)}`);
      if (!res.ok) throw new Error('Failed to fetch messages');
      return (await res.json()) as ChatMessage[];
    }

    const raw = localStorage.getItem(STORAGE_KEYS.MESSAGES);
    if (raw) {
      try {
        const parsed = JSON.parse(raw) as ChatMessage[];
        const roomMsgs = parsed.filter((m) => m.roomId === roomId);
        if (roomMsgs.length > 0) return roomMsgs;
      } catch {
        // Ignore malformed localStorage
      }
    }

    const seeded = buildInitialMessages(viewerLang).map((m) => ({ ...m, roomId }));
    localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(seeded));
    return seeded;
  },

  async sendMessage(
    roomId: string,
    sender: IslanderProfile,
    text: string,
    targetLang: LanguageCode,
    reaction?: ReactionType,
    overrideTranslation?: string
  ): Promise<{ userMessage: ChatMessage; aiReply?: ChatMessage }> {
    if (USE_CLOUD_BACKEND) {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ roomId, sender, text, targetLang, reaction }),
      });
      if (!res.ok) throw new Error('Failed to send chat');
      return (await res.json()) as { userMessage: ChatMessage; aiReply?: ChatMessage };
    }

    const effectiveTargetLang: LanguageCode =
      targetLang !== sender.nativeLang
        ? targetLang
        : sender.nativeLang === 'zh'
          ? 'ja'
          : 'zh';

    const tr = translateSmart(text, sender.nativeLang, effectiveTargetLang);
    const userMessage: ChatMessage = {
      id: `msg-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      roomId,
      sender,
      originalText: text,
      originalLang: sender.nativeLang,
      translatedText: overrideTranslation?.trim() || tr.translatedText,
      pronunciation: tr.pronunciation,
      culturalTip: tr.culturalTip,
      reaction,
      timestamp: Date.now(),
    };

    let responder = AI_ISLANDERS[Math.floor(Math.random() * AI_ISLANDERS.length)];
    if (/拉面|东京|kenji|ramen|tokyo/i.test(text)) responder = AI_ISLANDERS[0];
    else if (/咖啡|迪拜|tariq|coffee|dubai/i.test(text)) responder = AI_ISLANDERS[1];
    else if (/巴黎|画|书|camille|paris|art/i.test(text)) responder = AI_ISLANDERS[2];
    else if (/音乐|歌|首尔|minji|lofi|music/i.test(text)) responder = AI_ISLANDERS[3];

    const pool = AI_REPLY_POOL[responder.id] ?? AI_REPLY_POOL['ai-kenji'];
    const picked = pool[Math.floor(Math.random() * pool.length)];

    const aiReply: ChatMessage = {
      id: `ai-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      roomId,
      sender: responder,
      originalText: picked.originalText,
      originalLang: responder.nativeLang,
      translatedText: picked.translations[sender.nativeLang] ?? picked.translations.zh,
      pronunciation: picked.pronunciation,
      culturalTip: picked.culturalTip,
      timestamp: Date.now() + 500,
    };

    const existingRaw = localStorage.getItem(STORAGE_KEYS.MESSAGES);
    const existing: ChatMessage[] = existingRaw ? (JSON.parse(existingRaw) as ChatMessage[]) : [];
    const updated = [...existing, userMessage, aiReply].slice(-80);
    localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(updated));

    return { userMessage, aiReply };
  },

  async getBottles(): Promise<MessageBottle[]> {
    if (USE_CLOUD_BACKEND) {
      const res = await fetch('/api/bottles');
      if (!res.ok) throw new Error('Failed to fetch bottles');
      return (await res.json()) as MessageBottle[];
    }

    const raw = localStorage.getItem(STORAGE_KEYS.BOTTLES);
    if (raw) {
      try {
        const parsed = JSON.parse(raw) as MessageBottle[];
        if (parsed.length > 0) return parsed;
      } catch {
        // fallback
      }
    }
    localStorage.setItem(STORAGE_KEYS.BOTTLES, JSON.stringify(PRESET_BOTTLES));
    return PRESET_BOTTLES;
  },

  async replyToBottle(
    bottleId: string,
    author: IslanderProfile,
    replyText: string,
    targetLang: LanguageCode
  ): Promise<MessageBottle[]> {
    if (USE_CLOUD_BACKEND) {
      const res = await fetch(`/api/bottles/${encodeURIComponent(bottleId)}/reply`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ author, replyText, targetLang }),
      });
      if (!res.ok) throw new Error('Failed to reply to bottle');
      return (await res.json()) as MessageBottle[];
    }

    const bottles = await this.getBottles();
    const tr = translateSmart(replyText, author.nativeLang, targetLang);
    const updated = bottles.map((b) =>
      b.id === bottleId
        ? {
            ...b,
            replies: [
              ...b.replies,
              {
                authorName: author.name,
                authorFlag: author.countryFlag,
                originalText: replyText,
                translatedText: tr.translatedText,
              },
            ],
          }
        : b
    );
    localStorage.setItem(STORAGE_KEYS.BOTTLES, JSON.stringify(updated));
    return updated;
  },

  async throwBottle(author: IslanderProfile, text: string): Promise<MessageBottle[]> {
    if (USE_CLOUD_BACKEND) {
      const res = await fetch('/api/bottles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ author, text }),
      });
      if (!res.ok) throw new Error('Failed to throw bottle');
      return (await res.json()) as MessageBottle[];
    }

    const bottles = await this.getBottles();
    const tr = translateSmart(text, author.nativeLang, author.nativeLang === 'zh' ? 'en' : 'zh');
    const newBottle: MessageBottle = {
      id: `b-${Date.now()}`,
      author,
      originalText: text,
      translatedText: tr.translatedText,
      culturalTip: tr.culturalTip,
      createdAt: Date.now(),
      replies: [],
    };
    const updated = [newBottle, ...bottles];
    localStorage.setItem(STORAGE_KEYS.BOTTLES, JSON.stringify(updated));
    return updated;
  },

  loadUser(): IslanderProfile | null {
    const raw = localStorage.getItem(STORAGE_KEYS.USER);
    if (!raw) return null;
    try {
      return JSON.parse(raw) as IslanderProfile;
    } catch {
      return null;
    }
  },

  saveUser(user: IslanderProfile): void {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
  },

  loadRoomCode(): string {
    return localStorage.getItem(STORAGE_KEYS.ROOM) || 'NW-739K';
  },

  saveRoomCode(code: string): void {
    localStorage.setItem(STORAGE_KEYS.ROOM, code);
  },

  loadFurniture(): FurnitureId[] {
    const raw = localStorage.getItem(STORAGE_KEYS.FURNITURE);
    if (!raw) return ['campfire', 'sakuraTree'];
    try {
      const parsed = JSON.parse(raw) as FurnitureId[];
      return Array.isArray(parsed) ? parsed : ['campfire', 'sakuraTree'];
    } catch {
      return ['campfire', 'sakuraTree'];
    }
  },

  saveFurniture(items: FurnitureId[]): void {
    localStorage.setItem(STORAGE_KEYS.FURNITURE, JSON.stringify(items));
  },

  loadMiles(): number {
    const raw = localStorage.getItem(STORAGE_KEYS.MILES);
    if (!raw) return 200;
    const n = Number(raw);
    return Number.isFinite(n) ? n : 200;
  },

  saveMiles(miles: number): void {
    localStorage.setItem(STORAGE_KEYS.MILES, String(miles));
  },

  loadUnlockedItems(): string[] {
    const defaults = ['none', 'leaf', 'strawHat', 'campfire', 'bambooTea'];
    const raw = localStorage.getItem(STORAGE_KEYS.UNLOCKED);
    if (!raw) return defaults;
    try {
      const parsed = JSON.parse(raw) as string[];
      return Array.isArray(parsed) ? Array.from(new Set([...defaults, ...parsed])) : defaults;
    } catch {
      return defaults;
    }
  },

  saveUnlockedItems(items: string[]): void {
    localStorage.setItem(STORAGE_KEYS.UNLOCKED, JSON.stringify(items));
  },
};
