import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Smartphone, Volume2, VolumeX } from 'lucide-react';
import {
  AvatarStyle,
  ChatMessage,
  FurnitureId,
  IslandMode,
  IslandTheme,
  IslanderProfile,
  LanguageCode,
  MessageBottle,
  NookQuest,
  QuestKind,
  ReactionType,
  SpeciesType,
  StampInfo,
  VoiceOutputMode,
} from './types/island';
import { AI_ISLANDERS, apiAdapter, translateSmart } from './services/apiAdapter';
import { voiceTranslatorBridge } from './services/voiceTranslatorBridge';
import { echoBridgePipeline } from './services/echoBridgePipeline';
import { animaleseAudio } from './utils/animaleseAudio';
import { PostcardPayload } from './utils/postcardCanvas';
import { BoardingModal } from './components/BoardingModal';
import {
  FURNITURE_CATALOG,
  IslandBubbleData,
  IslandStage,
  ResidentEventData,
} from './components/IslandStage';
import { ChatPanel } from './components/ChatPanel';
import { PassportModal } from './components/PassportModal';
import { DodoModal } from './components/DodoModal';
import { BottleModal } from './components/BottleModal';
import { PostcardModal } from './components/PostcardModal';
import { AvatarWorkshopModal } from './components/AvatarStudio';
import { NookPhoneModal } from './components/NookPhoneModal';

const INITIAL_STAMPS: StampInfo[] = [
  { id: 'tokyo', title: '东京拉面章', city: 'Tokyo', flag: '🇯🇵', unlocked: false },
  { id: 'dubai', title: '迪拜咖啡章', city: 'Dubai', flag: '🇦🇪', unlocked: false },
  { id: 'paris', title: '巴黎铁塔章', city: 'Paris', flag: '🇫🇷', unlocked: false },
  { id: 'seoul', title: '首尔黑胶章', city: 'Seoul', flag: '🇰🇷', unlocked: false },
];

const THEME_ORDER: IslandTheme[] = ['chengdu', 'tokyo', 'dubai', 'paris', 'reykjavik'];

const REGION_CLOCK_META: Record<
  IslandTheme,
  { label: string; icon: string; timeZone: string }
> = {
  chengdu: { label: '🇨🇳 成都', icon: '🎋', timeZone: 'Asia/Shanghai' },
  tokyo: { label: '🇯🇵 东京', icon: '🌙', timeZone: 'Asia/Tokyo' },
  dubai: { label: '🇦🇪 迪拜', icon: '🌅', timeZone: 'Asia/Dubai' },
  paris: { label: '🇫🇷 巴黎', icon: '🌧️', timeZone: 'Europe/Paris' },
  reykjavik: { label: '🇮🇸 冰岛', icon: '❄️', timeZone: 'Atlantic/Reykjavik' },
};

const ARRIVAL_GUESTS = [
  '✈️ 叮咚！来自里约的 Lucas（水豚）刚乘水上飞机抵达广场！',
  '✈️ 叮咚！来自雷克雅未克的 Freja（北极熊）刚乘水上飞机抵达广场！',
  '✈️ 叮咚！来自悉尼的 Liam（考拉）刚乘水上飞机抵达广场！',
  '✈️ 叮咚！来自京都的 Haru（大熊猫）刚乘水上飞机抵达广场！',
];

const ICEBREAKER_TOPICS: Array<{
  question: string;
  replies: Array<{
    islanderIdx: number;
    orig: string;
    zh: string;
    pron: string;
    tip: string;
  }>;
}> = [
  {
    question: '🎲 篝火破冰签：此刻你窗外的天气和手边的饮料是什么？',
    replies: [
      {
        islanderIdx: 0,
        orig: '東京は小雨だよ！手元には熱い焙じ茶があるんだ〜🍵',
        zh: '东京正下着温柔的小雨呢！手边是一杯热腾腾的焙茶～🍵',
        pron: 'Tōkyō wa kosame da yo! Temoto ni wa atsui hōjicha ga arun da~',
        tip: '💡 文化小贴士：日本拉面店和家庭常喝「焙じ茶 (烘焙绿茶)」，几乎不含咖啡因，深夜喝超安心。',
      },
      {
        islanderIdx: 1,
        orig: 'السماء صافية في دبي وأنا أشرب قهوة بالهيل الآن ☕',
        zh: '迪拜此刻晴空万里，我正端着一杯豆蔻风味阿拉伯咖啡 ☕',
        pron: 'As-sama safiya fi Dubai wa ana ashrab qahwa bil-hayl',
        tip: '💡 文化小贴士：迪拜待客咖啡一定会加现磨绿豆蔻，香气清爽解腻。',
      },
      {
        islanderIdx: 3,
        orig: '서울은 선선한 바람이 불고 있어! 나는 유자차 마시는 중~ 🍋',
        zh: '首尔正吹着凉爽的晚风！我正在喝甜甜的蜂蜜柚子茶～ 🍋',
        pron: 'Seoul-eun seonseonhan barami bulgo isseo! Yujacha masineun jung~',
        tip: '💡 文化小贴士：韩国人在换季微凉时最爱喝「유자차 (蜂蜜柚子茶)」，酸甜润喉。',
      },
    ],
  },
  {
    question: '🎲 篝火破冰签：教大家一句你母语里最酷、最常用的口头禅吧！',
    replies: [
      {
        islanderIdx: 2,
        orig: '« C’est la vie ! » — 人生就是这样，放轻松享受当下吧 ✨',
        zh: '法语最酷口头禅：「C’est la vie !」——这就是生活呀，放轻松享受当下吧 ✨',
        pron: 'Sè la vi !',
        tip: '💡 文化小贴士：遇到小插曲时法国人常耸耸肩说「C’est la vie」，瞬间化解焦虑。',
      },
      {
        islanderIdx: 3,
        orig: '« 소확행 (Sohwakhaeng) » — 작지만 확실한 행복이야! 🌸',
        zh: '韩语「소확행 (小确幸)」——指生活中微小而确切的幸福瞬间！🌸',
        pron: 'Sohwakhaeng — jakjiman hwaksilhan haengbogiya!',
        tip: '💡 文化小贴士：在韩国 SNS 上大家常晒下班后的一杯奶茶或晚霞并打上 #소확행 标签。',
      },
      {
        islanderIdx: 0,
        orig: '「なんとかなるさ！」— 船到桥头自然直，没问题的！💪',
        zh: '日语超治愈口头禅：「なんとかなるさ！」——船到桥头自然直，一定没问题的！💪',
        pron: 'Nantoka naru sa!',
        tip: '💡 文化小贴士：日语「なんとかなる」相当于英语 “Everything will work out”，非常适合互相打气。',
      },
    ],
  },
];

const QUEST_POOL: Array<Omit<NookQuest, 'id' | 'completed'>> = [
  { kind: 'greet', emoji: '👋', label: '跨国问好', reward: 100 },
  { kind: 'balloon', emoji: '🎈', label: '戳破礼物气球', reward: 150 },
  { kind: 'walkie', emoji: '🎙️', label: '体验贝壳对讲机', reward: 100 },
  { kind: 'icebreaker', emoji: '🎲', label: '抽破冰话题签', reward: 100 },
  { kind: 'bottle', emoji: '🍾', label: '捞起海边漂流瓶', reward: 120 },
  { kind: 'decor', emoji: '🔨', label: '装扮一次小岛', reward: 100 },
];

const BALLOON_REWARDS = [
  { title: '🇯🇵 东京文化冷知识卡', desc: '日本拉面店喊「ごちそうさま」表示对厨师的最高感谢！', miles: 100 },
  { title: '🇦🇪 迪拜金色咖啡豆伴手礼', desc: '迪拜待客咖啡加绿豆蔻象征温暖与好运！', miles: 120 },
  { title: '🇫🇷 巴黎左岸明信片礼盒', desc: '塞纳河畔的绿色旧书摊已入选世界文化遗产！', miles: 90 },
  { title: '🇮🇸 极光冰晶幸运符', desc: '冰岛人最喜欢的社交场所其实是露天温泉池！', miles: 150 },
];

const RESIDENT_EVENTS: ResidentEventData[] = [
  {
    residentId: 'ai-kenji',
    prompt: '我刚熬好一锅新豚骨汤底，你猜日语「飯テロ」是什么意思？',
    options: [
      { label: '🍜 深夜发美食照“馋哭”大家', reply: '正解！你太懂二次元拉面梗啦，送你一碗特制叉烧面！🍜', reward: 100 },
      { label: '🔥 厨房着火了', reply: '哈哈不是啦！「飯テロ」是深夜晒美食馋人哦，还是请你喝茶！🍵', reward: 80 },
    ],
  },
  {
    residentId: 'ai-tariq',
    prompt: '刚烘焙完一批新咖啡豆！来尝尝看加了哪种神秘香料？',
    options: [
      { label: '🌿 现磨绿豆蔻 (Cardamom)', reply: 'ممتاز！完全答对！这是迪拜最经典的待客风味 ☕', reward: 120 },
      { label: '🌶️ 辣椒粉', reply: '哇那也太刺激了！其实是清爽的绿豆蔻啦，干杯！☕', reward: 80 },
    ],
  },
  {
    residentId: 'ai-camille',
    prompt: '巴黎的午后阳光真美~ 法语里和好朋友打招呼最可爱的叠词是？',
    options: [
      { label: '🐦 Coucou (咕咕)', reply: 'Oui ! C’est mignon ! 像小鸟一样轻快亲切呢 🌸', reward: 100 },
      { label: '🥐 Croissant', reply: '哈哈那是可颂面包啦！下次请你吃刚出炉的可颂~ 🥐', reward: 80 },
    ],
  },
  {
    residentId: 'ai-minji',
    prompt: '我正在调一首 Lo-fi 新歌！韩语「소확행」代表什么？',
    options: [
      { label: '✨ 生活中微小而确切的幸福', reply: '대박！完全正确！听海浪聊天就是小确幸呀 🎧', reward: 110 },
      { label: '🎸 摇滚演唱会', reply: '嘻嘻不对哦，是“小确幸”啦！送你一段治愈鼓点 🎧', reward: 80 },
    ],
  },
];

export const App: React.FC = () => {
  const [user, setUser] = useState<IslanderProfile | null>(() => apiAdapter.loadUser());
  const [roomCode, setRoomCode] = useState<string>(() => apiAdapter.loadRoomCode());
  const [islandMode] = useState<IslandMode>('plaza');
  const [theme, setTheme] = useState<IslandTheme>('chengdu');
  const [arrivalBanner, setArrivalBanner] = useState<string | null>(null);
  const [miles, setMiles] = useState<number>(() => apiAdapter.loadMiles());
  const [unlockedItems, setUnlockedItems] = useState<string[]>(() => apiAdapter.loadUnlockedItems());
  const [quests, setQuests] = useState<NookQuest[]>(() =>
    QUEST_POOL.slice(0, 3).map((q, i) => ({ ...q, id: `q-${i}`, completed: false }))
  );
  const [balloonActive, setBalloonActive] = useState(false);
  const [balloonToast, setBalloonToast] = useState<{ title: string; desc: string; miles: number } | null>(null);
  const [residentEvent, setResidentEvent] = useState<ResidentEventData | null>(null);
  const [placedFurniture, setPlacedFurniture] = useState<FurnitureId[]>(() =>
    apiAdapter.loadFurniture()
  );
  const [targetLang, setTargetLang] = useState<LanguageCode>('ja');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [bottles, setBottles] = useState<MessageBottle[]>([]);
  const [stamps, setStamps] = useState<StampInfo[]>(() => {
    const raw = localStorage.getItem('nookwave_stamps_v1');
    if (raw) {
      try {
        return JSON.parse(raw) as StampInfo[];
      } catch {
        return INITIAL_STAMPS;
      }
    }
    return INITIAL_STAMPS;
  });

  // Modals
  const [showRegionMenu, setShowRegionMenu] = useState(false);
  const [showNookPhone, setShowNookPhone] = useState(false);
  const [showDecorDrawer, setShowDecorDrawer] = useState(false);
  const [showPassport, setShowPassport] = useState(false);
  const [showDodo, setShowDodo] = useState(false);
  const [showBottles, setShowBottles] = useState(false);
  const [showWardrobe, setShowWardrobe] = useState(false);
  const [postcardPayload, setPostcardPayload] = useState<PostcardPayload | null>(null);
  const [previewToast, setPreviewToast] = useState<string | null>(null);
  const [regionClock, setRegionClock] = useState('');

  // Audio & Voice state
  const [muted, setMuted] = useState(false);
  const [voiceMode, setVoiceMode] = useState<VoiceOutputMode>('animalese');
  const [isRecording, setIsRecording] = useState(false);
  const [isDemoRunning, setIsDemoRunning] = useState(false);
  const [micVolume, setMicVolume] = useState(0);
  const [interimOriginal, setInterimOriginal] = useState('');
  const [interimTranslated, setInterimTranslated] = useState('');
  const lastInterimUpdateRef = useRef<number>(0);

  // Island reaction & 4-second overhead bubble state
  const [islandBubbles, setIslandBubbles] = useState<Record<string, IslandBubbleData>>({});
  const [activeReaction, setActiveReaction] = useState<{
    targetId: string;
    type: ReactionType;
    key: number;
  } | null>(null);
  const [groupReaction, setGroupReaction] = useState<{
    type: ReactionType;
    key: number;
  } | null>(null);

  const showOverheadBubble = useCallback(
    (characterId: string, primary: string, secondary?: string, speakLang?: LanguageCode) => {
      setIslandBubbles((prev) => ({
        ...prev,
        [characterId]: {
          primary,
          secondary,
          onSpeak: () => voiceTranslatorBridge.speakTTS(primary, speakLang || targetLang),
        },
      }));
      window.setTimeout(() => {
        setIslandBubbles((prev) => {
          const current = prev[characterId];
          if (!current || current.primary !== primary) return prev;
          const next = { ...prev };
          delete next[characterId];
          return next;
        });
      }, 4200);
    },
    [targetLang]
  );

  const unlockStampForSender = useCallback((senderId: string) => {
    const map: Record<string, StampInfo['id']> = {
      'ai-kenji': 'tokyo',
      'ai-tariq': 'dubai',
      'ai-camille': 'paris',
      'ai-minji': 'seoul',
    };
    const stampId = map[senderId];
    if (!stampId) return;

    setStamps((prev) => {
      const next = prev.map((s) =>
        s.id === stampId && !s.unlocked ? { ...s, unlocked: true, unlockedAt: Date.now() } : s
      );
      localStorage.setItem('nookwave_stamps_v1', JSON.stringify(next));
      return next;
    });
  }, []);

  useEffect(() => {
    voiceTranslatorBridge.customPipeline = echoBridgePipeline;
    return () => {
      if (voiceTranslatorBridge.customPipeline === echoBridgePipeline) {
        voiceTranslatorBridge.customPipeline = null;
      }
    };
  }, []);

  useEffect(() => {
    if (user?.name) {
      localStorage.setItem('nookwave_echobridge_speaker', user.name);
    }
  }, [user?.name]);

  useEffect(() => {
    const viewerLang: LanguageCode = user?.nativeLang || 'zh';
    void apiAdapter.getMessages(roomCode, viewerLang).then(setMessages);
    void apiAdapter.getBottles().then(setBottles);
  }, [roomCode, user?.nativeLang]);

  // Simulated global player arrival banner every 25s in Plaza mode
  useEffect(() => {
    if (!user || islandMode !== 'plaza') {
      setArrivalBanner(null);
      return;
    }

    const triggerArrival = () => {
      const msg = ARRIVAL_GUESTS[Math.floor(Math.random() * ARRIVAL_GUESTS.length)];
      setArrivalBanner(msg);
      animaleseAudio.playShellChirp(true);
      window.setTimeout(() => setArrivalBanner(null), 5000);
    };

    const initialTimer = window.setTimeout(triggerArrival, 2500);
    const interval = window.setInterval(triggerArrival, 25000);
    return () => {
      window.clearTimeout(initialTimer);
      window.clearInterval(interval);
    };
  }, [user, islandMode]);

  // Floating Gift Balloon every 20s + Islander '!' sudden event every 22s
  useEffect(() => {
    if (!user) return;
    const firstBalloon = window.setTimeout(() => setBalloonActive(true), 5000);
    const balloonLoop = window.setInterval(() => {
      setBalloonActive(true);
    }, 20000);

    const firstEvent = window.setTimeout(() => {
      setResidentEvent(RESIDENT_EVENTS[Math.floor(Math.random() * RESIDENT_EVENTS.length)]);
    }, 7000);
    const eventLoop = window.setInterval(() => {
      setResidentEvent((prev) =>
        prev ?? RESIDENT_EVENTS[Math.floor(Math.random() * RESIDENT_EVENTS.length)]
      );
    }, 22000);

    return () => {
      window.clearTimeout(firstBalloon);
      window.clearInterval(balloonLoop);
      window.clearTimeout(firstEvent);
      window.clearInterval(eventLoop);
    };
  }, [user]);

  // Real-time local clock for active region + auto-mute mic when tab goes hidden
  useEffect(() => {
    const updateClock = () => {
      try {
        const tz = REGION_CLOCK_META[theme].timeZone;
        setRegionClock(
          new Intl.DateTimeFormat('zh-CN', {
            timeZone: tz,
            hour: '2-digit',
            minute: '2-digit',
            hour12: false,
          }).format(new Date())
        );
      } catch {
        setRegionClock('--:--');
      }
    };
    updateClock();
    const t = window.setInterval(updateClock, 15000);

    const handleVisibility = () => {
      if (document.hidden && isRecording) {
        voiceTranslatorBridge.stopListening();
        setIsRecording(false);
        setMicVolume(0);
      }
    };
    document.addEventListener('visibilitychange', handleVisibility);
    return () => {
      window.clearInterval(t);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [theme, isRecording]);

  const addMiles = useCallback((amount: number) => {
    setMiles((prev) => {
      const next = prev + amount;
      apiAdapter.saveMiles(next);
      return next;
    });
  }, []);

  const completeQuest = useCallback(
    (kind: QuestKind) => {
      setQuests((prev) => {
        const idx = prev.findIndex((q) => q.kind === kind && !q.completed);
        if (idx === -1) return prev;
        const target = prev[idx];
        animaleseAudio.playQuestCompleteSound();
        addMiles(target.reward);

        const next = prev.map((q, i) => (i === idx ? { ...q, completed: true } : q));
        // Rotate in a fresh quest after 1.6s
        window.setTimeout(() => {
          setQuests((curr) => {
            const existingKinds = new Set(curr.map((c) => c.kind));
            const candidate =
              QUEST_POOL.find((p) => !existingKinds.has(p.kind)) ??
              QUEST_POOL[Math.floor(Math.random() * QUEST_POOL.length)];
            return curr.map((c) =>
              c.id === target.id
                ? { ...candidate, id: `q-${Date.now()}`, completed: false }
                : c
            );
          });
        }, 1600);
        return next;
      });
    },
    [addMiles]
  );

  const handleUnlockItem = useCallback(
    (itemId: string, cost: number): boolean => {
      if (unlockedItems.includes(itemId)) return true;
      if (miles < cost) return false;
      const nextMiles = miles - cost;
      const nextUnlocked = [...unlockedItems, itemId];
      setMiles(nextMiles);
      setUnlockedItems(nextUnlocked);
      apiAdapter.saveMiles(nextMiles);
      apiAdapter.saveUnlockedItems(nextUnlocked);
      animaleseAudio.playQuestCompleteSound();
      return true;
    },
    [miles, unlockedItems]
  );

  const playMessageAudio = useCallback(
    (msg: ChatMessage, speakLang?: LanguageCode) => {
      if (muted) return;
      // Default: gentle Animalese chime without clashing auto-TTS; TTS plays when user toggles TTS mode or clicks speaker
      if (voiceMode === 'tts') {
        voiceTranslatorBridge.speakTTS(msg.translatedText, speakLang || targetLang);
      } else {
        animaleseAudio.speak(msg.translatedText, msg.sender.species);
      }
    },
    [muted, voiceMode, targetLang]
  );

  const handleRetryTranslate = useCallback(
    (msg: ChatMessage) => {
      const tr = translateSmart(msg.originalText, msg.originalLang, targetLang);
      setMessages((prev) =>
        prev.map((m) =>
          m.id === msg.id
            ? { ...m, translatedText: tr.translatedText, pronunciation: tr.pronunciation }
            : m
        )
      );
    },
    [targetLang]
  );

  const handleBoard = (profile: IslanderProfile) => {
    apiAdapter.saveUser(profile);
    setUser(profile);
  };

  const handleToggleMute = () => {
    const next = !muted;
    setMuted(next);
    animaleseAudio.setMuted(next);
  };

  const handleSelectTheme = (nextTheme: IslandTheme) => {
    setTheme(nextTheme);
    setShowRegionMenu(false);
    animaleseAudio.playShellChirp(true);
  };

  const handleChangeRoom = (newCode: string) => {
    apiAdapter.saveRoomCode(newCode);
    setRoomCode(newCode);
  };

  const handleSaveWardrobe = (species: SpeciesType, avatarStyle: AvatarStyle) => {
    if (!user) return;
    const updated: IslanderProfile = {
      ...user,
      species,
      color: avatarStyle.furColor,
      avatarStyle,
    };
    apiAdapter.saveUser(updated);
    setUser(updated);
    showOverheadBubble(updated.id, '✨ 换好新穿搭啦！');
  };

  const handleUpdateProfile = (name: string, islandName: string) => {
    if (!user) return;
    const updated: IslanderProfile = { ...user, name, islandName };
    apiAdapter.saveUser(updated);
    setUser(updated);
  };

  const handleToggleFurniture = (id: FurnitureId, cost: number) => {
    void animaleseAudio.resume();
    if (cost > 0 && !unlockedItems.includes(id)) {
      if (!handleUnlockItem(id, cost)) {
        if (user) {
          showOverheadBubble(user.id, `里数不足！需要 ${cost} 里数 🔒`);
        }
        return;
      }
    }
    animaleseAudio.playBuildSound();
    completeQuest('decor');
    setPlacedFurniture((prev) => {
      let next: FurnitureId[];
      const isAdding = !prev.includes(id);
      if (isAdding) {
        next = prev.length >= 4 ? [...prev.slice(1), id] : [...prev, id];
      } else {
        next = prev.filter((item) => item !== id);
      }
      apiAdapter.saveFurniture(next);

      if (isAdding && Math.random() > 0.45) {
        const itemMeta = FURNITURE_CATALOG.find((f) => f.id === id);
        const responder = AI_ISLANDERS[Math.floor(Math.random() * AI_ISLANDERS.length)];
        if (itemMeta) {
          showOverheadBubble(responder.id, `哇！新摆的${itemMeta.label}超好看！`);
        }
      }
      return next;
    });
  };

  const handleSendMessage = useCallback(
    async (text: string, overrideTranslation?: string) => {
      if (!user || !text.trim()) return;
      const { userMessage, aiReply } = await apiAdapter.sendMessage(
        roomCode,
        user,
        text,
        targetLang,
        undefined,
        overrideTranslation
      );
      setMessages((prev) => [...prev, userMessage]);
      showOverheadBubble(user.id, userMessage.translatedText, userMessage.originalText, targetLang);
      // Default to light Animalese chime to avoid TTS clash
      if (!muted) animaleseAudio.speak(userMessage.translatedText, user.species);

      if (aiReply) {
        window.setTimeout(() => {
          setMessages((prev) => [...prev, aiReply]);
          unlockStampForSender(aiReply.sender.id);
          showOverheadBubble(
            aiReply.sender.id,
            aiReply.translatedText,
            aiReply.originalText,
            user.nativeLang
          );
          if (!muted) animaleseAudio.speak(aiReply.translatedText, aiReply.sender.species);
        }, 650);
      }
    },
    [user, roomCode, targetLang, muted, unlockStampForSender, showOverheadBubble]
  );

  const handleQuickGreet = (target: IslanderProfile) => {
    if (!user) return;
    unlockStampForSender(target.id);
    completeQuest('greet');
    void handleSendMessage(`你好呀 ${target.name.split(' ')[0]}，很高兴在岛上遇见你！`);
  };

  const handleBuyCoffee = (target: IslanderProfile) => {
    if (!user) return;
    unlockStampForSender(target.id);
    completeQuest('greet');
    animaleseAudio.playReactionSound('coffee');
    void handleSendMessage(`请 ${target.name.split(' ')[0]} 喝一杯冰美式咖啡续命！☕`);
  };

  const handlePopBalloon = () => {
    animaleseAudio.playBalloonPopSound();
    setBalloonActive(false);
    const reward = BALLOON_REWARDS[Math.floor(Math.random() * BALLOON_REWARDS.length)];
    addMiles(reward.miles);
    completeQuest('balloon');
    setBalloonToast(reward);
    window.setTimeout(() => setBalloonToast(null), 4500);
  };

  const handleResolveResidentEvent = (
    resident: IslanderProfile,
    reply: string,
    reward: number
  ) => {
    setResidentEvent(null);
    addMiles(reward);
    animaleseAudio.playQuestCompleteSound();
    unlockStampForSender(resident.id);
    showOverheadBubble(resident.id, reply);
    if (!muted) {
      animaleseAudio.speak(reply, resident.species);
    }
    if (user) {
      const msg: ChatMessage = {
        id: `evt-${Date.now()}`,
        roomId: roomCode,
        sender: resident,
        originalText: reply,
        originalLang: resident.nativeLang,
        translatedText: `${reply}（获得 +${reward} 里数！）`,
        culturalTip: '💡 奇遇奖励：主动回应岛民的突发「!」请求是攒 Nook 里数的最快方式！',
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, msg]);
    }
  };

  const handleDrawIcebreaker = () => {
    if (!user) return;
    completeQuest('icebreaker');
    const topic = ICEBREAKER_TOPICS[Math.floor(Math.random() * ICEBREAKER_TOPICS.length)];
    animaleseAudio.playBoardingSound();

    const topicMsg: ChatMessage = {
      id: `ice-${Date.now()}`,
      roomId: roomCode,
      sender: user,
      originalText: topic.question,
      originalLang: user.nativeLang,
      translatedText: topic.question,
      culturalTip: '💡 篝火圆桌仪式：世界各角落的岛友正在接力回答这个问题！',
      timestamp: Date.now(),
    };
    setMessages((prev) => [...prev, topicMsg]);
    showOverheadBubble(user.id, '🎲 抽出破冰话题签！');

    topic.replies.forEach((rep, idx) => {
      window.setTimeout(() => {
        const resident = AI_ISLANDERS[rep.islanderIdx];
        unlockStampForSender(resident.id);
        const replyMsg: ChatMessage = {
          id: `ice-rep-${Date.now()}-${idx}`,
          roomId: roomCode,
          sender: resident,
          originalText: rep.orig,
          originalLang: resident.nativeLang,
          translatedText: rep.zh,
          pronunciation: rep.pron,
          culturalTip: rep.tip,
          timestamp: Date.now(),
        };
        setMessages((prev) => [...prev, replyMsg]);
        showOverheadBubble(resident.id, rep.zh, rep.orig);
        if (!muted) {
          animaleseAudio.speak(rep.zh, resident.species);
        }
      }, 750 + idx * 950);
    });
  };

  const handleTriggerReaction = (reaction: ReactionType) => {
    if (!user) return;
    const reactionLabelMap: Record<ReactionType, string> = {
      clap: '👏 拍手鼓掌！',
      flower: '🌸 开心冒花花~',
      coffee: '☕ 干杯热咖啡！',
      firework: '🎉 一起看烟花！',
      shock: '😲 哇塞太惊喜了！',
      dance: '💃 跟着节奏摇摆~',
    };
    animaleseAudio.playReactionSound(reaction);

    if (reaction === 'firework' || reaction === 'coffee' || reaction === 'dance') {
      // Group Reaction: all islanders gather around the campfire and react together!
      setGroupReaction({ type: reaction, key: Date.now() });
      showOverheadBubble(user.id, reactionLabelMap[reaction]);
      AI_ISLANDERS.forEach((res) => showOverheadBubble(res.id, reactionLabelMap[reaction]));
      window.setTimeout(() => setGroupReaction(null), 3200);
      return;
    }

    setActiveReaction({ targetId: user.id, type: reaction, key: Date.now() });
    showOverheadBubble(user.id, reactionLabelMap[reaction]);
    window.setTimeout(() => {
      const randomResident = AI_ISLANDERS[Math.floor(Math.random() * AI_ISLANDERS.length)];
      setActiveReaction({ targetId: randomResident.id, type: reaction, key: Date.now() + 1 });
      showOverheadBubble(randomResident.id, reactionLabelMap[reaction]);
    }, 350);
  };

  const startMicSession = async () => {
    if (!user || isRecording || isDemoRunning) return;
    await animaleseAudio.resume();
    animaleseAudio.playShellChirp(true);
    setIsRecording(true);
    lastInterimUpdateRef.current = 0;

    await voiceTranslatorBridge.startListening(user.nativeLang, targetLang, {
      onVolumeChange: (vol) => setMicVolume(vol),
      onInterimResult: (orig, trans) => {
        const now = Date.now();
        // Anti-flicker guard: throttle interim updates when stabilizing
        if (now - lastInterimUpdateRef.current < 180) return;
        lastInterimUpdateRef.current = now;
        setInterimOriginal(orig);
        setInterimTranslated(trans);
      },
      onFinalResult: (finalOrig, finalTrans) => {
        setIsRecording(false);
        setMicVolume(0);
        setInterimOriginal('');
        setInterimTranslated('');
        completeQuest('walkie');
        void handleSendMessage(finalOrig, finalTrans);
      },
      onError: () => {
        setIsRecording(false);
        setMicVolume(0);
      },
    });
  };

  const stopMicSession = () => {
    if (!isRecording) return;
    animaleseAudio.playShellChirp(false);
    voiceTranslatorBridge.stopListening();
    setIsRecording(false);
    setMicVolume(0);
    setInterimOriginal('');
    setInterimTranslated('');
  };

  const handleToggleMic = async () => {
    if (isRecording) {
      stopMicSession();
    } else {
      await startMicSession();
    }
  };

  const handleRunDemo = async () => {
    if (!user || isDemoRunning || isRecording) return;
    await animaleseAudio.resume();
    animaleseAudio.playShellChirp(true);
    setIsDemoRunning(true);

    voiceTranslatorBridge.runSimulatedDemo(
      user.nativeLang,
      targetLang,
      {
        onVolumeChange: (vol) => setMicVolume(vol),
        onInterimResult: (orig, trans) => {
          setInterimOriginal(orig);
          setInterimTranslated(trans);
        },
        onFinalResult: (finalOrig, finalTrans) => {
          animaleseAudio.playShellChirp(false);
          setIsDemoRunning(false);
          setMicVolume(0);
          setInterimOriginal('');
          setInterimTranslated('');
          completeQuest('walkie');
          void handleSendMessage(finalOrig, finalTrans);
        },
        onError: () => {
          setIsDemoRunning(false);
        },
      },
      () => {
        setIsDemoRunning(false);
      }
    );
  };

  const handleClickQuest = (quest: NookQuest) => {
    if (quest.completed) return;
    switch (quest.kind) {
      case 'balloon':
        setBalloonActive(true);
        break;
      case 'walkie':
        void handleRunDemo();
        break;
      case 'greet':
        handleQuickGreet(AI_ISLANDERS[Math.floor(Math.random() * AI_ISLANDERS.length)]);
        break;
      case 'icebreaker':
        handleDrawIcebreaker();
        break;
      case 'bottle':
        setShowBottles(true);
        completeQuest('bottle');
        break;
      case 'decor':
        if (user) showOverheadBubble(user.id, '点击小岛右上角【装扮】摆放一件家具吧！');
        break;
    }
  };
  const handleReplyBottle = async (bottleId: string, text: string) => {
    if (!user) return;
    completeQuest('bottle');
    const updated = await apiAdapter.replyToBottle(bottleId, user, text, targetLang);
    setBottles(updated);
  };

  const handleThrowBottle = async (text: string) => {
    if (!user) return;
    const updated = await apiAdapter.throwBottle(user, text);
    setBottles(updated);
  };

  const activePlayer: IslanderProfile = user || {
    id: 'guest',
    name: '旅行者',
    islandName: '旅行者的电波岛',
    species: 'panda',
    color: '#FAF6EB',
    avatarStyle: { furColor: '#FAF6EB', headwear: 'leaf', eyewear: 'none', outfit: 'leafShirt' },
    nativeLang: 'zh',
    city: 'NookWave',
    countryFlag: '🇨🇳',
    isAI: false,
  };

  const activeRegion = REGION_CLOCK_META[theme];

  return (
    <div className="h-[100dvh] w-screen paper-texture flex flex-col overflow-hidden">
      {/* Minimal Top Navigation Bar: Region Clock Pill (Left) + 3 Elements (Right) */}
      <header className="px-3 sm:px-5 py-1.5 sm:py-2 flex items-center justify-between gap-2 shrink-0 relative z-40">
        <div className="relative">
          <button
            type="button"
            onClick={() => setShowRegionMenu((v) => !v)}
            className="px-3 py-1.5 rounded-full bg-white text-espresso font-black text-xs nook-btn inline-flex items-center gap-1.5 truncate"
            title="点击选择全球 5 大主题航线"
          >
            <span>{activeRegion.label}</span>
            <span className="text-espresso-light">·</span>
            <span>{regionClock || '--:--'}</span>
            <span>{activeRegion.icon}</span>
          </button>

          {showRegionMenu && (
            <div className="absolute top-11 left-0 w-48 bg-cream nook-card p-1.5 space-y-1 z-50">
              {THEME_ORDER.map((t) => {
                const info = REGION_CLOCK_META[t];
                const active = t === theme;
                return (
                  <button
                    key={t}
                    type="button"
                    onClick={() => handleSelectTheme(t)}
                    className={`w-full px-3 py-1.5 rounded-xl text-left text-xs font-black flex items-center justify-between transition-colors ${
                      active
                        ? 'bg-mint text-espresso border border-espresso'
                        : 'bg-white/80 text-espresso hover:bg-coral/25'
                    }`}
                  >
                    <span>{info.label}</span>
                    <span>{info.icon}</span>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          <div className="px-2.5 py-1 rounded-full bg-coral/25 border-2 border-espresso text-[11px] font-black text-espresso inline-flex items-center gap-1">
            <span>🎫</span>
            <span>{miles}</span>
          </div>

          <button
            type="button"
            onClick={() => setShowNookPhone(true)}
            className="px-3 py-1.5 rounded-full bg-mint text-espresso font-black text-xs nook-btn inline-flex items-center gap-1"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Nook 手机</span>
          </button>

          <button
            type="button"
            onClick={handleToggleMute}
            aria-label={muted ? '取消静音' : '全局静音'}
            className={`w-8 h-8 sm:w-9 sm:h-9 rounded-full nook-btn flex items-center justify-center ${
              muted ? 'bg-cream-dark text-espresso-light' : 'bg-white text-espresso'
            }`}
          >
            {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Spatial-First Main Stage (60%-65%+ height) + Slim Bottom Control Dock */}
      <main className="flex-1 min-h-0 px-2 sm:px-5 pb-2 sm:pb-4 flex flex-col gap-2">
        <section className="flex-1 min-h-[58dvh]">
          <IslandStage
            theme={theme}
            islandMode={islandMode}
            player={activePlayer}
            islanders={AI_ISLANDERS}
            placedFurniture={placedFurniture}
            unlockedItems={unlockedItems}
            miles={miles}
            showDecorDrawer={showDecorDrawer}
            onCloseDecorDrawer={() => setShowDecorDrawer(false)}
            onToggleFurniture={handleToggleFurniture}
            micVolume={micVolume}
            isVoiceActive={isRecording || isDemoRunning}
            interimOriginal={interimOriginal}
            interimTranslated={interimTranslated}
            islandBubbles={islandBubbles}
            arrivalBanner={arrivalBanner}
            balloonActive={balloonActive}
            onPopBalloon={handlePopBalloon}
            residentEvent={residentEvent}
            onResolveResidentEvent={handleResolveResidentEvent}
            activeReaction={activeReaction}
            groupReaction={groupReaction}
            onOpenBottle={() => {
              setShowBottles(true);
              completeQuest('bottle');
            }}
            onOpenDodo={() => setShowDodo(true)}
            onQuickGreet={handleQuickGreet}
            onBuyCoffee={handleBuyCoffee}
            onDrawIcebreaker={handleDrawIcebreaker}
            onEnterCampfire={() => showOverheadBubble(activePlayer.id, '🔥 围炉烤火真暖和~')}
          />
        </section>

        <ChatPanel
          messages={messages}
          player={activePlayer}
          targetLang={targetLang}
          onChangeTargetLang={setTargetLang}
          roomCode={roomCode}
          voiceMode={voiceMode}
          isRecording={isRecording}
          isDemoRunning={isDemoRunning}
          micVolume={micVolume}
          onToggleMic={handleToggleMic}
          onStartHoldMic={() => void startMicSession()}
          onStopHoldMic={stopMicSession}
          onRunDemo={handleRunDemo}
          onToggleVoiceMode={() =>
            setVoiceMode((m) => (m === 'animalese' ? 'tts' : 'animalese'))
          }
          onSendMessage={handleSendMessage}
          onRetryTranslate={handleRetryTranslate}
          onDrawIcebreaker={handleDrawIcebreaker}
          onTriggerReaction={handleTriggerReaction}
          onReplayAudio={(msg) => playMessageAudio(msg)}
          onExportPostcard={(payload) => setPostcardPayload(payload)}
          quests={quests}
          onClickQuest={handleClickQuest}
        />
      </main>

      {/* Modals */}
      {!user && <BoardingModal roomCode={roomCode} onBoard={handleBoard} />}

      {showNookPhone && user && (
        <NookPhoneModal
          user={user}
          miles={miles}
          roomCode={roomCode}
          onOpenWardrobe={() => setShowWardrobe(true)}
          onToggleDecor={() => setShowDecorDrawer((v) => !v)}
          onOpenBottles={() => setShowBottles(true)}
          onOpenDodo={() => setShowDodo(true)}
          onOpenPassport={() => setShowPassport(true)}
          onDrawIcebreaker={handleDrawIcebreaker}
          onSummonBalloon={() => setBalloonActive(true)}
          onShowPreviewToast={(msg) => {
            setPreviewToast(msg);
            window.setTimeout(() => setPreviewToast(null), 3200);
          }}
          onClose={() => setShowNookPhone(false)}
        />
      )}

      {showPassport && user && (
        <PassportModal
          user={user}
          roomCode={roomCode}
          stamps={stamps}
          onUpdateProfile={handleUpdateProfile}
          onGreetFriend={(friend) => handleQuickGreet(friend)}
          onClose={() => setShowPassport(false)}
        />
      )}

      {showWardrobe && user && (
        <AvatarWorkshopModal
          initialSpecies={user.species}
          initialStyle={
            user.avatarStyle || {
              furColor: user.color,
              headwear: 'leaf',
              eyewear: 'none',
              outfit: 'leafShirt',
            }
          }
          miles={miles}
          unlockedItems={unlockedItems}
          onUnlockItem={handleUnlockItem}
          onSave={handleSaveWardrobe}
          onClose={() => setShowWardrobe(false)}
        />
      )}

      {balloonToast && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-cream nook-card px-4 py-3 max-w-sm text-center space-y-1">
          <div className="text-xs font-black text-coral-dark">
            🎁 气球礼盒开启！+{balloonToast.miles} Nook 里数
          </div>
          <div className="text-sm font-black text-espresso">{balloonToast.title}</div>
          <div className="text-xs font-semibold text-espresso-light">{balloonToast.desc}</div>
        </div>
      )}

      {showDodo && (
        <DodoModal
          roomCode={roomCode}
          onChangeRoom={handleChangeRoom}
          onClose={() => setShowDodo(false)}
        />
      )}

      {showBottles && user && (
        <BottleModal
          bottles={bottles}
          user={user}
          roomCode={roomCode}
          onReply={handleReplyBottle}
          onThrow={handleThrowBottle}
          onExportPostcard={(payload) => setPostcardPayload(payload)}
          onClose={() => setShowBottles(false)}
        />
      )}

      {postcardPayload && (
        <PostcardModal
          payload={postcardPayload}
          onClose={() => setPostcardPayload(null)}
        />
      )}

      {previewToast && (
        <div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 bg-cream nook-card px-4 py-2 text-xs font-black text-espresso">
          {previewToast}
        </div>
      )}
    </div>
  );
};

export default App;
