export type LanguageCode = 'zh' | 'en' | 'ja' | 'ko' | 'fr' | 'es' | 'ar';

export type SpeciesType =
  | 'panda'
  | 'shiba'
  | 'fennec'
  | 'calico'
  | 'tiger'
  | 'koala'
  | 'capybara'
  | 'polarbear';

export type HeadwearType =
  | 'none'
  | 'leaf'
  | 'strawHat'
  | 'beret'
  | 'headphones'
  | 'flowerCrown'
  | 'crown';

export type EyewearType = 'none' | 'glasses' | 'sunglasses' | 'blush' | 'bandaid';

export type OutfitType = 'leafShirt' | 'sweater' | 'sailor' | 'bowtie' | 'scarf';

export interface AvatarStyle {
  furColor: string;
  headwear: HeadwearType;
  eyewear: EyewearType;
  outfit: OutfitType;
}

export type ReactionType = 'clap' | 'flower' | 'coffee' | 'firework' | 'shock' | 'dance';
export type IslandTheme = 'chengdu' | 'tokyo' | 'dubai' | 'paris' | 'reykjavik';
export type IslandMode = 'plaza' | 'private';
export type VoiceOutputMode = 'animalese' | 'tts';

export type FurnitureId =
  | 'campfire'
  | 'ramenStall'
  | 'cafeSet'
  | 'sakuraTree'
  | 'bambooTea'
  | 'tent'
  | 'lanterns'
  | 'onsen';

export type QuestKind = 'greet' | 'balloon' | 'walkie' | 'icebreaker' | 'bottle' | 'decor';

export interface NookQuest {
  id: string;
  kind: QuestKind;
  emoji: string;
  label: string;
  reward: number;
  completed: boolean;
}

export interface IslanderProfile {
  id: string;
  name: string;
  islandName?: string;
  species: SpeciesType;
  color: string;
  avatarStyle?: AvatarStyle;
  nativeLang: LanguageCode;
  city: string;
  countryFlag: string;
  isAI: boolean;
  persona?: string;
}

export interface ChatMessage {
  id: string;
  roomId: string;
  sender: IslanderProfile;
  originalText: string;
  originalLang: LanguageCode;
  translatedText: string;
  pronunciation?: string;
  culturalTip?: string;
  reaction?: ReactionType;
  timestamp: number;
}

export interface MessageBottle {
  id: string;
  author: IslanderProfile;
  originalText: string;
  translatedText: string;
  culturalTip?: string;
  createdAt: number;
  replies: Array<{
    authorName: string;
    authorFlag: string;
    originalText: string;
    translatedText: string;
  }>;
}

export interface StampInfo {
  id: 'tokyo' | 'dubai' | 'paris' | 'seoul';
  title: string;
  city: string;
  flag: string;
  unlocked: boolean;
  unlockedAt?: number;
}
