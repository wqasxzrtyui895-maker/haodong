import React from 'react';
import { motion } from 'framer-motion';
import { AvatarStyle, SpeciesType } from '../types/island';

interface AnimalAvatarProps {
  species: SpeciesType;
  color: string;
  avatarStyle?: AvatarStyle;
  size?: number;
  fullBody?: boolean;
  isWalking?: boolean;
  className?: string;
}

export const SPECIES_META: Record<
  SpeciesType,
  { label: string; flag: string; city: string; defaultColor: string; pitchDesc: string }
> = {
  panda: { label: '大熊猫', flag: '🇨🇳', city: '中国·成都', defaultColor: '#FAF6EB', pitchDesc: '软萌低音' },
  shiba: { label: '柴犬', flag: '🇯🇵', city: '日本·东京', defaultColor: '#F4A261', pitchDesc: '温暖中音' },
  fennec: { label: '耳廓狐', flag: '🇦🇪', city: '阿联酋·迪拜', defaultColor: '#E9C46A', pitchDesc: '灵动高音' },
  calico: { label: '三花猫', flag: '🇫🇷', city: '法国·巴黎', defaultColor: '#F28482', pitchDesc: '清脆高音' },
  tiger: { label: 'Q版白虎', flag: '🇰🇷', city: '韩国·首尔', defaultColor: '#F8F4EC', pitchDesc: '元气中音' },
  koala: { label: '考拉', flag: '🇦🇺', city: '澳大利亚·悉尼', defaultColor: '#90BE6D', pitchDesc: '柔和中音' },
  capybara: { label: '水豚', flag: '🇧🇷', city: '巴西·里约', defaultColor: '#C98A5B', pitchDesc: '憨厚低音' },
  polarbear: { label: '北极熊', flag: '🇮🇸', city: '冰岛·雷克雅未克', defaultColor: '#EBF5FA', pitchDesc: '治愈低音' },
};

export const AnimalAvatar: React.FC<AnimalAvatarProps> = ({
  species,
  color,
  avatarStyle,
  size = 48,
  fullBody = false,
  isWalking = false,
  className = '',
}) => {
  const ink = '#4A4238';
  const fur = avatarStyle?.furColor || color;
  const headwear = avatarStyle?.headwear || 'none';
  const eyewear = avatarStyle?.eyewear || 'none';
  const outfit = avatarStyle?.outfit || 'leafShirt';

  const outfitColor =
    outfit === 'leafShirt'
      ? '#78C2AD'
      : outfit === 'sweater'
        ? '#FAF6EB'
        : outfit === 'sailor'
          ? '#FFFFFF'
          : outfit === 'bowtie'
            ? '#F4A261'
            : '#EFE7D3';

  const viewBox = fullBody ? '0 -14 100 142' : '4 -10 92 106';
  const height = fullBody ? Math.round(size * 1.32) : size;

  return (
    <svg
      width={size}
      height={height}
      viewBox={viewBox}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* LAYER 1: Crisp Hard Sticker Shadow + Flat Comic Body */}
      {fullBody && (
        <g>
          {/* Crisp comic hard shadow */}
          <ellipse cx="50" cy="120" rx="22" ry="5.5" fill={ink} opacity="0.24" />

          {/* Short Feet */}
          <motion.g
            animate={isWalking ? { y: [0, -5, 0] } : { y: 0 }}
            transition={isWalking ? { duration: 0.28, repeat: Infinity } : { duration: 0.2 }}
          >
            <path
              d="M32 104 C30 115, 44 117, 45 106 Z"
              fill={species === 'panda' ? ink : fur}
              stroke={ink}
              strokeWidth="3"
              strokeLinejoin="round"
            />
          </motion.g>
          <motion.g
            animate={isWalking ? { y: [-5, 0, -5] } : { y: 0 }}
            transition={isWalking ? { duration: 0.28, repeat: Infinity } : { duration: 0.2 }}
          >
            <path
              d="M55 106 C56 117, 70 115, 68 104 Z"
              fill={species === 'panda' ? ink : fur}
              stroke={ink}
              strokeWidth="3"
              strokeLinejoin="round"
            />
          </motion.g>

          {/* Torso + Paw Arms */}
          <motion.g
            animate={
              isWalking
                ? { scaleY: [1, 0.94, 1.04, 1], y: [0, 1.5, -2, 0] }
                : { scaleY: [1, 1.02, 1], y: [0, -0.6, 0] }
            }
            transition={{ duration: isWalking ? 0.28 : 2.6, repeat: Infinity, ease: 'easeInOut' }}
            style={{ transformOrigin: '50px 108px' }}
          >
            <path
              d="M30 81 C19 85, 16 97, 23 101 C28 103, 33 95, 32 87 Z"
              fill={species === 'panda' ? ink : fur}
              stroke={ink}
              strokeWidth="3"
              strokeLinejoin="round"
            />
            <path
              d="M70 81 C81 85, 84 97, 77 101 C72 103, 67 95, 68 87 Z"
              fill={species === 'panda' ? ink : fur}
              stroke={ink}
              strokeWidth="3"
              strokeLinejoin="round"
            />

            {/* Flat Comic Torso */}
            <path
              d="M30 77 C30 70, 70 70, 70 77 L76 101 C77 108, 23 108, 24 101 Z"
              fill={outfitColor}
              stroke={ink}
              strokeWidth="3"
              strokeLinejoin="round"
            />
            {/* Single crisp cel-shadow band at bottom of shirt */}
            <path
              d="M25 99 Q50 105 75 99 L76 102 C77 107, 23 107, 24 102 Z"
              fill={ink}
              opacity="0.12"
            />

            {outfit === 'leafShirt' && (
              <g>
                <path
                  d="M50 85 C55 85, 58 91, 53 96 C49 99, 44 97, 44 92 C44 88, 47 85, 50 85 Z"
                  fill="#FAF6EB"
                  stroke={ink}
                  strokeWidth="2"
                />
                <circle cx="48" cy="91" r="1.4" fill="#78C2AD" />
              </g>
            )}
            {outfit === 'sweater' && (
              <g>
                <path d="M28 89 H72" stroke="#F4A261" strokeWidth="4.5" strokeLinecap="round" />
                <path d="M26 98 H74" stroke="#78C2AD" strokeWidth="3.8" strokeLinecap="round" />
              </g>
            )}
            {outfit === 'sailor' && (
              <g>
                <path d="M32 76 L50 90 L68 76 L65 85 L50 95 L35 85 Z" fill="#2B4C7E" stroke={ink} strokeWidth="2" />
                <path d="M50 90 L46 100 H54 Z" fill="#E76F51" stroke={ink} strokeWidth="1.8" />
              </g>
            )}
            {outfit === 'bowtie' && (
              <g>
                <path d="M40 80 L50 85 L40 90 Z" fill="#E76F51" stroke={ink} strokeWidth="1.8" />
                <path d="M60 80 L50 85 L60 90 Z" fill="#E76F51" stroke={ink} strokeWidth="1.8" />
                <circle cx="50" cy="85" r="2.8" fill="#FAF6EB" stroke={ink} strokeWidth="1.8" />
              </g>
            )}
            {outfit === 'scarf' && (
              <g>
                <rect x="30" y="74" width="40" height="10" rx="5" fill="#E76F51" stroke={ink} strokeWidth="2.2" />
                <rect x="53" y="81" width="9" height="15" rx="4" fill="#D95D39" stroke={ink} strokeWidth="2.2" />
              </g>
            )}
          </motion.g>
        </g>
      )}

      {/* LAYER 2 & 3: Flat Comic Sticker Head + Crisp 3px Ink Outlines */}
      <motion.g
        animate={
          fullBody
            ? { rotate: isWalking ? [-3, 3, -3] : [-1.5, 1.5, -1.5], y: isWalking ? [0, -1.5, 0] : 0 }
            : { rotate: 0 }
        }
        transition={{ duration: isWalking ? 0.28 : 3.2, repeat: Infinity, ease: 'easeInOut' }}
        style={{ transformOrigin: '50px 76px' }}
      >
        {/* Ears */}
        {species === 'fennec' && (
          <>
            <path d="M26 47 C16 28, 10 14, 18 12 C25 10, 35 22, 42 32 Z" fill={fur} stroke={ink} strokeWidth="3" strokeLinejoin="round" />
            <path d="M26 42 C20 28, 17 19, 20 18 C24 17, 32 25, 36 33 Z" fill="#F9DEC9" />
            <path d="M74 47 C84 28, 90 14, 82 12 C75 10, 65 22, 58 32 Z" fill={fur} stroke={ink} strokeWidth="3" strokeLinejoin="round" />
            <path d="M74 42 C80 28, 83 19, 80 18 C76 17, 68 25, 64 33 Z" fill="#F9DEC9" />
          </>
        )}

        {species === 'calico' && (
          <>
            <path d="M24 46 C20 31, 20 19, 25 18 C31 17, 38 26, 43 32 Z" fill="#FAF6EB" stroke={ink} strokeWidth="3" strokeLinejoin="round" />
            <path d="M27 39 C24 30, 24 24, 27 23 C30 23, 35 28, 37 32 Z" fill={fur} />
            <path d="M76 46 C80 31, 80 19, 75 18 C69 17, 62 26, 57 32 Z" fill={ink} stroke={ink} strokeWidth="3" strokeLinejoin="round" />
            <path d="M73 39 C76 30, 76 24, 73 23 C70 23, 65 28, 63 32 Z" fill={fur} />
          </>
        )}

        {(species === 'shiba' || species === 'tiger') && (
          <>
            <path d="M24 47 C21 32, 22 20, 27 19 C32 18, 38 26, 43 32 Z" fill={fur} stroke={ink} strokeWidth="3" strokeLinejoin="round" />
            <path d="M27 40 C25 31, 26 25, 28 24 C31 24, 35 28, 37 32 Z" fill="#FAF6EB" />
            <path d="M76 47 C79 32, 78 20, 73 19 C68 18, 62 26, 57 32 Z" fill={fur} stroke={ink} strokeWidth="3" strokeLinejoin="round" />
            <path d="M73 40 C75 31, 74 25, 72 24 C69 24, 65 28, 63 32 Z" fill="#FAF6EB" />
          </>
        )}

        {species === 'panda' && (
          <>
            <ellipse cx="28" cy="31" rx="9.5" ry="8.5" transform="rotate(-24 28 31)" fill={ink} stroke={ink} strokeWidth="3" />
            <ellipse cx="72" cy="31" rx="9.5" ry="8.5" transform="rotate(24 72 31)" fill={ink} stroke={ink} strokeWidth="3" />
          </>
        )}

        {(species === 'capybara' || species === 'polarbear') && (
          <>
            <circle cx="28" cy="31" r="9.5" fill={fur} stroke={ink} strokeWidth="3" />
            <circle cx="72" cy="31" r="9.5" fill={fur} stroke={ink} strokeWidth="3" />
            <circle cx="28" cy="31" r="4.4" fill="#F9DEC9" />
            <circle cx="72" cy="31" r="4.4" fill="#F9DEC9" />
          </>
        )}

        {species === 'koala' && (
          <>
            <circle cx="22" cy="40" r="13.5" fill={fur} stroke={ink} strokeWidth="3" />
            <circle cx="78" cy="40" r="13.5" fill={fur} stroke={ink} strokeWidth="3" />
            <circle cx="22" cy="40" r="6.8" fill="#FAF6EB" />
            <circle cx="78" cy="40" r="6.8" fill="#FAF6EB" />
          </>
        )}

        {/* Crisp Flat Comic Head */}
        <path
          d={
            species === 'capybara'
              ? 'M19 59 C18 37, 33 28, 50 28 C67 28, 82 37, 81 59 C80 77, 67 83, 50 83 C33 83, 20 77, 19 59 Z'
              : 'M22 59 C21 37, 35 28, 50 28 C65 28, 79 37, 78 59 C77 77, 64 83, 50 83 C36 83, 23 77, 22 59 Z'
          }
          fill={species === 'calico' ? '#FAF6EB' : fur}
          stroke={ink}
          strokeWidth="3"
          strokeLinejoin="round"
        />

        {/* Species Markings */}
        {species === 'calico' && (
          <>
            <path d="M23 48 C29 36, 40 32, 46 37 C40 46, 32 52, 23 52 Z" fill={fur} />
            <path d="M59 32 C70 36, 76 43, 77 53 C68 51, 62 44, 59 32 Z" fill={ink} />
          </>
        )}

        {species === 'shiba' && (
          <path
            d="M24 61 C24 50, 37 54, 50 54 C63 54, 76 50, 76 61 C76 77, 64 82, 50 82 C36 82, 24 77, 24 61 Z"
            fill="#FAF6EB"
          />
        )}

        {species === 'panda' && (
          <>
            <path
              d="M27 52 C27 42, 41 41, 44 50 C46 58, 40 64, 32 63 C27 62, 26 57, 27 52 Z"
              fill={ink}
            />
            <path
              d="M73 52 C73 42, 59 41, 56 50 C54 58, 60 64, 68 63 C73 62, 74 57, 73 52 Z"
              fill={ink}
            />
          </>
        )}

        {species === 'tiger' && (
          <g stroke={ink} strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M44 31 L50 38 L56 31" />
            <path d="M24 51 L31 53 M24 57 L30 57" />
            <path d="M76 51 L69 53 M76 57 L70 57" />
          </g>
        )}

        {/* Crisp Flat Snout */}
        {species === 'koala' ? (
          <ellipse cx="50" cy="61" rx="6.8" ry="10" fill={ink} />
        ) : species !== 'panda' ? (
          <ellipse cx="50" cy="65.5" rx={species === 'capybara' ? 14.5 : 12.5} ry="9" fill="#FAF6EB" />
        ) : null}

        {/* Clean Flat Sticker Blush Cheeks (no gaussian blur) */}
        <ellipse
          cx="29"
          cy="64.5"
          rx={eyewear === 'blush' ? 7.5 : 5.5}
          ry={eyewear === 'blush' ? 4.5 : 3.4}
          fill="#F28482"
          opacity={eyewear === 'blush' ? 0.85 : 0.6}
        />
        <ellipse
          cx="71"
          cy="64.5"
          rx={eyewear === 'blush' ? 7.5 : 5.5}
          ry={eyewear === 'blush' ? 4.5 : 3.4}
          fill="#F28482"
          opacity={eyewear === 'blush' ? 0.85 : 0.6}
        />

        {/* Expressive Blinking Comic Eyes */}
        <motion.g
          animate={fullBody ? { scaleY: [1, 1, 0.08, 1, 1] } : undefined}
          transition={{ duration: 4.2, times: [0, 0.92, 0.95, 0.98, 1], repeat: Infinity }}
          style={{ transformOrigin: '50px 53px' }}
        >
          {species === 'capybara' ? (
            <g stroke={ink} strokeWidth="3.2" strokeLinecap="round">
              <path d="M32 52 Q37 50 42 52" />
              <path d="M58 52 Q63 50 68 52" />
            </g>
          ) : species === 'panda' ? (
            <>
              <circle cx="36.5" cy="52.5" r="5.2" fill="#FAF6EB" />
              <circle cx="63.5" cy="52.5" r="5.2" fill="#FAF6EB" />
              <circle cx="36.8" cy="52.7" r="3.4" fill={ink} />
              <circle cx="63.2" cy="52.7" r="3.4" fill={ink} />
              <circle cx="35.3" cy="51" r="1.6" fill="#FFFFFF" />
              <circle cx="61.7" cy="51" r="1.6" fill="#FFFFFF" />
            </>
          ) : (
            <>
              <ellipse cx="37" cy="53" rx="4.8" ry="5.6" fill={ink} />
              <ellipse cx="63" cy="53" rx="4.8" ry="5.6" fill={ink} />
              <circle cx="35.2" cy="50.8" r="2" fill="#FFFFFF" />
              <circle cx="61.2" cy="50.8" r="2" fill="#FFFFFF" />
            </>
          )}
        </motion.g>

        {/* Subtle Eyebrows */}
        {species !== 'capybara' && species !== 'panda' && (
          <g stroke={ink} strokeWidth="2" strokeLinecap="round" opacity="0.7">
            <path d="M33.5 44.5 Q37 43 40.5 44.5" />
            <path d="M59.5 44.5 Q63 43 66.5 44.5" />
          </g>
        )}

        {/* Nose + ':3' Mouth */}
        {species !== 'koala' ? (
          <>
            <ellipse cx="50" cy="61.5" rx="4.6" ry="3.2" fill={ink} />
            <path
              d="M44 67.5 Q47 71.5 50 68 Q53 71.5 56 67.5"
              stroke={ink}
              strokeWidth="2.4"
              strokeLinecap="round"
              strokeLinejoin="round"
              fill="none"
            />
          </>
        ) : (
          <path d="M45.5 74.5 Q50 78.5 54.5 74.5" stroke={ink} strokeWidth="2.4" strokeLinecap="round" fill="none" />
        )}

        {/* LAYER 4: Eyewear */}
        {eyewear === 'glasses' && (
          <g stroke={ink} strokeWidth="2.4">
            <circle cx="37" cy="53" r="8.8" fill="rgba(255,255,255,0.22)" />
            <circle cx="63" cy="53" r="8.8" fill="rgba(255,255,255,0.22)" />
            <line x1="45.8" y1="53" x2="54.2" y2="53" />
          </g>
        )}

        {eyewear === 'sunglasses' && (
          <g>
            <rect x="26" y="45" width="21" height="14.5" rx="6" fill={ink} stroke={ink} strokeWidth="2" />
            <rect x="53" y="45" width="21" height="14.5" rx="6" fill={ink} stroke={ink} strokeWidth="2" />
            <line x1="47" y1="51" x2="53" y2="51" stroke={ink} strokeWidth="2.4" />
            <line x1="30" y1="49" x2="36" y2="49" stroke="#FFFFFF" strokeOpacity="0.65" strokeWidth="1.8" strokeLinecap="round" />
            <line x1="57" y1="49" x2="63" y2="49" stroke="#FFFFFF" strokeOpacity="0.65" strokeWidth="1.8" strokeLinecap="round" />
          </g>
        )}

        {eyewear === 'bandaid' && (
          <g transform="translate(65, 60) rotate(-18)">
            <rect x="-7" y="-3.5" width="14" height="7" rx="3.5" fill="#F9DEC9" stroke={ink} strokeWidth="1.6" />
            <line x1="-2" y1="-2" x2="-2" y2="2" stroke="#C98A5B" strokeWidth="1.2" />
            <line x1="2" y1="-2" x2="2" y2="2" stroke="#C98A5B" strokeWidth="1.2" />
          </g>
        )}

        {/* LAYER 5: Headwear */}
        {headwear === 'leaf' && (
          <g>
            <path d="M50 29 Q52 17 58 13" stroke={ink} strokeWidth="2.6" strokeLinecap="round" />
            <path d="M54 15 C64 8, 72 14, 66 22 C61 27, 52 22, 54 15 Z" fill="#52B788" stroke={ink} strokeWidth="2.4" />
          </g>
        )}

        {headwear === 'strawHat' && (
          <g>
            <ellipse cx="50" cy="30" rx="33" ry="7.5" fill="#E9C46A" stroke={ink} strokeWidth="2.6" />
            <path d="M32 29 C33 13, 67 13, 68 29 Z" fill="#F4D58D" stroke={ink} strokeWidth="2.6" />
            <path d="M33 25 H67" stroke="#E76F51" strokeWidth="4" strokeLinecap="round" />
          </g>
        )}

        {headwear === 'beret' && (
          <g transform="rotate(-10 50 26)">
            <ellipse cx="50" cy="26" rx="22" ry="10" fill="#F28482" stroke={ink} strokeWidth="2.6" />
            <line x1="50" y1="16" x2="52" y2="11" stroke={ink} strokeWidth="2.6" strokeLinecap="round" />
          </g>
        )}

        {headwear === 'headphones' && (
          <g>
            <path d="M19 53 C19 19, 81 19, 81 53" stroke="#78C2AD" strokeWidth="5.2" strokeLinecap="round" fill="none" />
            <rect x="13" y="45" width="10.5" height="19" rx="5" fill="#F4A261" stroke={ink} strokeWidth="2.4" />
            <rect x="76.5" y="45" width="10.5" height="19" rx="5" fill="#F4A261" stroke={ink} strokeWidth="2.4" />
          </g>
        )}

        {headwear === 'flowerCrown' && (
          <g>
            <path d="M29 32 Q50 24 71 32" stroke="#52B788" strokeWidth="3.5" strokeLinecap="round" fill="none" />
            {[
              { cx: 36, cy: 29, c: '#FF9EAA' },
              { cx: 50, cy: 26, c: '#FFF3B0' },
              { cx: 64, cy: 29, c: '#BDE8F5' },
            ].map((fl, i) => (
              <g key={i}>
                <circle cx={fl.cx} cy={fl.cy} r="5.8" fill={fl.c} stroke={ink} strokeWidth="2" />
                <circle cx={fl.cx} cy={fl.cy} r="2" fill="#F4A261" />
              </g>
            ))}
          </g>
        )}

        {headwear === 'crown' && (
          <path
            d="M35 29 L38 14 L45 21 L50 11 L55 21 L62 14 L65 29 Z"
            fill="#FFE66D"
            stroke={ink}
            strokeWidth="2.6"
            strokeLinejoin="round"
          />
        )}
      </motion.g>
    </svg>
  );
};
