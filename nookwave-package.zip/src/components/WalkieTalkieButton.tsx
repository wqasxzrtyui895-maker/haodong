import React from 'react';
import { motion } from 'framer-motion';
import { Mic, Volume2, Radio } from 'lucide-react';
import { VoiceOutputMode } from '../types/island';

interface WalkieTalkieButtonProps {
  isRecording: boolean;
  isDemoRunning: boolean;
  micAvailable: boolean;
  volume: number;
  voiceMode: VoiceOutputMode;
  onToggleMic: () => void;
  onRunDemo: () => void;
  onToggleVoiceMode: () => void;
}

export const WalkieTalkieButton: React.FC<WalkieTalkieButtonProps> = ({
  isRecording,
  isDemoRunning,
  micAvailable,
  volume,
  voiceMode,
  onToggleMic,
  onRunDemo,
  onToggleVoiceMode,
}) => {
  const active = isRecording || isDemoRunning;
  const ringScale = 1 + (volume / 100) * 0.2;

  return (
    <div className="flex items-center justify-between gap-1.5 w-full overflow-x-auto no-scrollbar">
      {/* Left: Shell Walkie-Talkie Pill */}
      <motion.button
        type="button"
        animate={active ? { scale: ringScale } : { scale: 1 }}
        transition={{ duration: 0.15 }}
        onClick={onToggleMic}
        disabled={isDemoRunning}
        title={isRecording ? '点击结束说话并发送' : '贝壳对讲机：点击开麦实时翻译'}
        className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-full border-2 border-espresso shadow-nook-sm text-[11px] font-black whitespace-nowrap shrink-0 transition-colors ${
          active ? 'bg-coral text-espresso' : 'bg-mint text-espresso hover:bg-mint-dark'
        } disabled:opacity-60`}
      >
        <svg width="16" height="16" viewBox="0 0 64 64" fill="none" className="shrink-0">
          <path
            d="M32 10 C15 10, 6 24, 10 38 C12 45, 20 50, 24 52 L24 56 H40 L40 52 C44 50, 52 45, 54 38 C58 24, 49 10, 32 10 Z"
            fill="#FAF6EB"
            stroke="#4A4238"
            strokeWidth="5"
            strokeLinejoin="round"
          />
          <path d="M32 12 V49" stroke="#4A4238" strokeWidth="4" strokeLinecap="round" />
          <circle cx="32" cy="31" r="5" fill={active ? '#F4A261' : '#78C2AD'} stroke="#4A4238" strokeWidth="3" />
        </svg>
        <span>{isRecording ? '结束说话' : '贝壳对讲机'}</span>
      </motion.button>

      {/* Middle: Simulated Demo Pill */}
      <button
        type="button"
        onClick={onRunDemo}
        disabled={isDemoRunning || isRecording}
        className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-full border-2 border-espresso text-[11px] font-black whitespace-nowrap shrink-0 transition-all ${
          !micAvailable
            ? 'bg-coral text-espresso shadow-nook-sm'
            : 'bg-cream text-espresso hover:bg-coral/40'
        } disabled:opacity-50`}
      >
        <Mic className="w-3 h-3 shrink-0" />
        <span>{isDemoRunning ? '演示中...' : '模拟演示'}</span>
      </button>

      {/* Right: Output Mode Pill */}
      <button
        type="button"
        onClick={onToggleVoiceMode}
        className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-full bg-white border-2 border-espresso text-[11px] font-black text-espresso whitespace-nowrap shrink-0 hover:bg-cream-dark transition-colors"
        title="切换语音输出模式"
      >
        {voiceMode === 'animalese' ? (
          <>
            <Radio className="w-3 h-3 text-coral-dark shrink-0" />
            <span>电波萌音</span>
          </>
        ) : (
          <>
            <Volume2 className="w-3 h-3 text-mint-dark shrink-0" />
            <span>外语播报</span>
          </>
        )}
      </button>
    </div>
  );
};
