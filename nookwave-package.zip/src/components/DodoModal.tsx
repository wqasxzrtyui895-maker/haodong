import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Check, Copy, Plane, PlusCircle, Compass, X } from 'lucide-react';

interface DodoModalProps {
  roomCode: string;
  onChangeRoom: (newCode: string) => void;
  onClose: () => void;
}

function generateDodoCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let suffix = '';
  for (let i = 0; i < 4; i++) {
    suffix += chars[Math.floor(Math.random() * chars.length)];
  }
  return `NW-${suffix}`;
}

export const DodoModal: React.FC<DodoModalProps> = ({ roomCode, onChangeRoom, onClose }) => {
  const [joinInput, setJoinInput] = useState('');
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    const inviteText = `✈️ 来森友电波岛 NookWave 串门吧！Dodo 登岛密码：${roomCode} (${window.location.origin}/?dodo=${roomCode})`;
    try {
      await navigator.clipboard.writeText(inviteText);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleCreatePrivate = () => {
    const code = generateDodoCode();
    onChangeRoom(code);
    onClose();
  };

  const handleJoin = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = joinInput.trim().toUpperCase();
    if (!cleaned) return;
    onChangeRoom(cleaned);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-espresso/50 backdrop-blur-sm p-4">
      <motion.div
        initial={{ scale: 0.92, opacity: 0, y: 16 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        className="w-full max-w-md bg-cream nook-card overflow-hidden"
      >
        <div className="bg-mint px-5 py-3.5 border-b-[3px] border-espresso flex items-center justify-between">
          <div className="flex items-center gap-2 text-espresso font-black text-base">
            <Plane className="w-5 h-5" />
            Dodo 航空 · 登岛密码联机
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-cream border-2 border-espresso flex items-center justify-center hover:bg-cream-dark"
          >
            <X className="w-4 h-4 text-espresso" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Current Room Code */}
          <div className="bg-white p-4 rounded-2xl border-2 border-espresso text-center space-y-2">
            <div className="text-xs font-extrabold text-espresso-light">当前小岛 Dodo 密码</div>
            <div className="text-3xl font-black tracking-widest text-espresso">{roomCode}</div>
            <button
              type="button"
              onClick={handleCopy}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-coral text-espresso font-black text-xs nook-btn"
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              {copied ? '已复制邀请链接！' : '一键复制邀请链接'}
            </button>
          </div>

          {/* Create Private Island */}
          <button
            type="button"
            onClick={handleCreatePrivate}
            className="w-full py-3 rounded-2xl bg-sage text-cream font-black text-sm nook-btn flex items-center justify-center gap-2"
          >
            <PlusCircle className="w-4 h-4" />
            创建我的私密小岛 (生成新密码)
          </button>

          {/* Visit Friend's Island */}
          <form onSubmit={handleJoin} className="space-y-2 pt-2 border-t-2 border-dashed border-espresso/20">
            <label className="block text-xs font-extrabold text-espresso-light">
              输入朋友的 Dodo 密码串门
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={joinInput}
                onChange={(e) => setJoinInput(e.target.value)}
                placeholder="例如 NW-882A"
                maxLength={10}
                className="flex-1 px-3 py-2.5 rounded-xl bg-white border-2 border-espresso font-black uppercase text-sm focus:outline-none focus:ring-2 focus:ring-mint"
              />
              <button
                type="submit"
                className="px-4 py-2.5 rounded-xl bg-mint text-espresso font-black text-sm nook-btn inline-flex items-center gap-1.5"
              >
                <Compass className="w-4 h-4" />
                出发
              </button>
            </div>
          </form>
        </div>
      </motion.div>
    </div>
  );
};
