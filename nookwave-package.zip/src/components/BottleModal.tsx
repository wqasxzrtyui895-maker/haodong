import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Image as ImageIcon, Send, Shuffle, Sparkles, X } from 'lucide-react';
import { IslanderProfile, MessageBottle } from '../types/island';
import { AnimalAvatar } from './AnimalAvatar';
import { PostcardPayload } from '../utils/postcardCanvas';

interface BottleModalProps {
  bottles: MessageBottle[];
  user: IslanderProfile;
  roomCode: string;
  onReply: (bottleId: string, text: string) => Promise<void>;
  onThrow: (text: string) => Promise<void>;
  onExportPostcard: (payload: PostcardPayload) => void;
  onClose: () => void;
}

export const BottleModal: React.FC<BottleModalProps> = ({
  bottles,
  user,
  roomCode,
  onReply,
  onThrow,
  onExportPostcard,
  onClose,
}) => {
  const [tab, setTab] = useState<'read' | 'write'>('read');
  const [index, setIndex] = useState(0);
  const [replyText, setReplyText] = useState('');
  const [throwText, setThrowText] = useState('');
  const [busy, setBusy] = useState(false);

  const currentBottle = bottles[index % Math.max(1, bottles.length)];

  const handleRandomPick = () => {
    if (bottles.length <= 1) return;
    let next = Math.floor(Math.random() * bottles.length);
    if (next === index) next = (index + 1) % bottles.length;
    setIndex(next);
  };

  const handleReplySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim() || !currentBottle || busy) return;
    setBusy(true);
    await onReply(currentBottle.id, replyText.trim());
    setReplyText('');
    setBusy(false);
  };

  const handleThrowSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!throwText.trim() || busy) return;
    setBusy(true);
    await onThrow(throwText.trim());
    setThrowText('');
    setTab('read');
    setIndex(0);
    setBusy(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-espresso/50 backdrop-blur-sm p-3 sm:p-4">
      <motion.div
        initial={{ scale: 0.92, opacity: 0, y: 18 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        className="w-full max-w-lg bg-cream nook-card overflow-hidden max-h-[90dvh] flex flex-col"
      >
        <div className="bg-mint px-5 py-3.5 border-b-[3px] border-espresso flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2 font-black text-espresso text-base">
            🍾 海边漂流瓶 · Ocean Bottles
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-cream border-2 border-espresso flex items-center justify-center hover:bg-cream-dark"
          >
            <X className="w-4 h-4 text-espresso" />
          </button>
        </div>

        {/* Tabs */}
        <div className="px-5 pt-3 flex gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setTab('read')}
            className={`flex-1 py-2 rounded-xl font-black text-xs border-2 border-espresso transition-all ${
              tab === 'read' ? 'bg-coral text-espresso shadow-nook-sm' : 'bg-white text-espresso-light'
            }`}
          >
            🏖️ 捞起漂流瓶 ({bottles.length})
          </button>
          <button
            type="button"
            onClick={() => setTab('write')}
            className={`flex-1 py-2 rounded-xl font-black text-xs border-2 border-espresso transition-all ${
              tab === 'write' ? 'bg-coral text-espresso shadow-nook-sm' : 'bg-white text-espresso-light'
            }`}
          >
            ✉️ 写瓶子扔进大海
          </button>
        </div>

        <div className="p-5 overflow-y-auto nook-scroll flex-1 space-y-4">
          {tab === 'read' && currentBottle && (
            <>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-1 rounded-xl bg-white border-2 border-espresso">
                    <AnimalAvatar
                      species={currentBottle.author.species}
                      color={currentBottle.author.color}
                      avatarStyle={currentBottle.author.avatarStyle}
                      size={40}
                    />
                  </div>
                  <div>
                    <div className="font-black text-sm text-espresso">
                      {currentBottle.author.countryFlag} {currentBottle.author.name}
                    </div>
                    <div className="text-[11px] font-bold text-espresso-light">
                      漂流自 {currentBottle.author.city}
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleRandomPick}
                  className="px-3 py-1.5 rounded-xl bg-white text-espresso font-black text-xs nook-btn inline-flex items-center gap-1"
                >
                  <Shuffle className="w-3.5 h-3.5" />
                  再捞一个
                </button>
              </div>

              {/* Bottle Message */}
              <div className="bg-white p-4 rounded-2xl border-2 border-espresso space-y-2">
                <p className="font-black text-base text-espresso leading-relaxed">
                  {currentBottle.translatedText}
                </p>
                <p className="text-xs font-semibold text-espresso-light border-t border-dashed border-espresso/20 pt-2">
                  原文：{currentBottle.originalText}
                </p>
                {currentBottle.culturalTip && (
                  <div className="text-xs font-bold bg-cream-dark/70 px-3 py-1.5 rounded-xl text-espresso">
                    {currentBottle.culturalTip}
                  </div>
                )}
                <div className="pt-1 flex justify-end">
                  <button
                    type="button"
                    onClick={() =>
                      onExportPostcard({
                        sender: currentBottle.author,
                        receiver: user,
                        primaryText: currentBottle.translatedText,
                        secondaryText: currentBottle.originalText,
                        culturalTip: currentBottle.culturalTip,
                        roomCode,
                        timestamp: currentBottle.createdAt,
                      })
                    }
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-cream border border-espresso text-[11px] font-black text-espresso hover:bg-coral/25"
                  >
                    <ImageIcon className="w-3.5 h-3.5" />
                    生成纪念明信片
                  </button>
                </div>
              </div>

              {/* Replies */}
              {currentBottle.replies.length > 0 && (
                <div className="space-y-2">
                  <div className="text-xs font-black text-espresso-light">
                    暖心回信 ({currentBottle.replies.length})
                  </div>
                  {currentBottle.replies.map((rep, idx) => (
                    <div
                      key={idx}
                      className="bg-mint/15 p-3 rounded-2xl border-2 border-espresso/30 space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-espresso">
                          {rep.authorFlag} {rep.authorName}
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            onExportPostcard({
                              sender: user,
                              receiver: currentBottle.author,
                              primaryText: rep.translatedText,
                              secondaryText: rep.originalText,
                              roomCode,
                              timestamp: Date.now(),
                            })
                          }
                          className="inline-flex items-center gap-1 text-[10px] font-black text-espresso-light hover:text-espresso"
                        >
                          <ImageIcon className="w-3 h-3" />
                          生成纪念明信片
                        </button>
                      </div>
                      <div className="text-sm font-bold text-espresso">{rep.translatedText}</div>
                      <div className="text-[11px] text-espresso-light">{rep.originalText}</div>
                    </div>
                  ))}
                </div>
              )}

              {/* Reply Input */}
              <form onSubmit={handleReplySubmit} className="flex gap-2">
                <input
                  type="text"
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  placeholder="用你的母语写一句暖心回信（自动翻译）..."
                  className="flex-1 px-3 py-2.5 rounded-xl bg-white border-2 border-espresso text-sm font-bold focus:outline-none focus:ring-2 focus:ring-mint"
                />
                <button
                  type="submit"
                  disabled={busy || !replyText.trim()}
                  className="px-4 py-2.5 rounded-xl bg-coral text-espresso font-black text-xs nook-btn disabled:opacity-50 inline-flex items-center gap-1"
                >
                  <Send className="w-3.5 h-3.5" />
                  回信
                </button>
              </form>
            </>
          )}

          {tab === 'write' && (
            <form onSubmit={handleThrowSubmit} className="space-y-3">
              <div className="text-xs font-bold text-espresso-light">
                写下一句此刻的心情或问题，NookWave 会自动附带双语转译，让大洋彼岸的岛友捡到它：
              </div>
              <textarea
                rows={4}
                value={throwText}
                onChange={(e) => setThrowText(e.target.value)}
                placeholder="例如：今天加班好累呀，真想在东京深夜拉面摊吃一碗热汤面..."
                className="w-full p-3.5 rounded-2xl bg-white border-2 border-espresso text-sm font-bold focus:outline-none focus:ring-2 focus:ring-mint resize-none"
              />
              <button
                type="submit"
                disabled={busy || !throwText.trim()}
                className="w-full py-3 rounded-2xl bg-mint text-espresso font-black text-sm nook-btn disabled:opacity-50 inline-flex items-center justify-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                塞进玻璃瓶扔进大海 🌊
              </button>
            </form>
          )}
        </div>
      </motion.div>
    </div>
  );
};
