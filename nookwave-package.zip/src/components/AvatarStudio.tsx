import React from 'react';
import { motion } from 'framer-motion';
import { Dices, Sparkles, X } from 'lucide-react';
import {
  AvatarStyle,
  EyewearType,
  HeadwearType,
  OutfitType,
  SpeciesType,
} from '../types/island';
import { AnimalAvatar, SPECIES_META } from './AnimalAvatar';

interface AvatarStudioProps {
  species: SpeciesType;
  avatarStyle: AvatarStyle;
  onChangeSpecies: (sp: SpeciesType) => void;
  onChangeStyle: (style: AvatarStyle) => void;
  compact?: boolean;
  miles?: number;
  unlockedItems?: string[];
  onUnlockItem?: (itemId: string, cost: number) => boolean;
}

const SPECIES_LIST: SpeciesType[] = [
  'panda',
  'shiba',
  'fennec',
  'calico',
  'tiger',
  'koala',
  'capybara',
  'polarbear',
];

const FUR_COLORS = ['#FAF6EB', '#F4A261', '#78C2AD', '#F28482', '#E9C46A', '#C98A5B'];

const HEADWEAR_OPTIONS: Array<{ id: HeadwearType; label: string; cost: number }> = [
  { id: 'none', label: '无', cost: 0 },
  { id: 'leaf', label: '🌱 小树叶', cost: 0 },
  { id: 'strawHat', label: '👒 草帽', cost: 0 },
  { id: 'beret', label: '🎨 贝雷帽', cost: 100 },
  { id: 'headphones', label: '🎧 耳机', cost: 150 },
  { id: 'flowerCrown', label: '🌸 花环', cost: 200 },
  { id: 'crown', label: '👑 小皇冠', cost: 300 },
];

const EYEWEAR_OPTIONS: Array<{ id: EyewearType; label: string }> = [
  { id: 'none', label: '自然' },
  { id: 'glasses', label: '🤓 圆眼镜' },
  { id: 'sunglasses', label: '😎 墨镜' },
  { id: 'blush', label: '😊 腮红' },
  { id: 'bandaid', label: '🩹 创可贴' },
];

const OUTFIT_OPTIONS: Array<{ id: OutfitType; label: string }> = [
  { id: 'leafShirt', label: '🍃 叶子衫' },
  { id: 'sweater', label: '🧶 条纹毛衣' },
  { id: 'sailor', label: '⚓ 水手服' },
  { id: 'bowtie', label: '🎀 蝴蝶结' },
  { id: 'scarf', label: '🧣 暖围巾' },
];

export const AvatarStudio: React.FC<AvatarStudioProps> = ({
  species,
  avatarStyle,
  onChangeSpecies,
  onChangeStyle,
  compact = false,
  miles,
  unlockedItems,
  onUnlockItem,
}) => {
  const [unlockHint, setUnlockHint] = React.useState<string | null>(null);

  const handleRandomize = () => {
    const sp = SPECIES_LIST[Math.floor(Math.random() * SPECIES_LIST.length)];
    const furColor =
      Math.random() > 0.35
        ? SPECIES_META[sp].defaultColor
        : FUR_COLORS[Math.floor(Math.random() * FUR_COLORS.length)];
    const availHeadwear = unlockedItems
      ? HEADWEAR_OPTIONS.filter((h) => h.cost === 0 || unlockedItems.includes(h.id))
      : HEADWEAR_OPTIONS.filter((h) => h.cost === 0);
    const headwear = availHeadwear[Math.floor(Math.random() * availHeadwear.length)].id;
    const eyewear = EYEWEAR_OPTIONS[Math.floor(Math.random() * EYEWEAR_OPTIONS.length)].id;
    const outfit = OUTFIT_OPTIONS[Math.floor(Math.random() * OUTFIT_OPTIONS.length)].id;
    onChangeSpecies(sp);
    onChangeStyle({ furColor, headwear, eyewear, outfit });
  };

  const handleSelectHeadwear = (opt: { id: HeadwearType; label: string; cost: number }) => {
    if (opt.cost === 0 || !unlockedItems || unlockedItems.includes(opt.id)) {
      setUnlockHint(null);
      onChangeStyle({ ...avatarStyle, headwear: opt.id });
      return;
    }
    if (!onUnlockItem) {
      setUnlockHint(`「${opt.label}」登岛后可用 ${opt.cost} 里数解锁哦~`);
      return;
    }
    if (onUnlockItem(opt.id, opt.cost)) {
      setUnlockHint(`✨ 已消耗 ${opt.cost} 里数解锁 ${opt.label}！`);
      onChangeStyle({ ...avatarStyle, headwear: opt.id });
    } else {
      setUnlockHint(`🎫 里数不足！需要 ${opt.cost} 里数（当前 ${miles ?? 0}），快去聊天做任务攒里数吧~`);
    }
  };

  return (
    <div className="space-y-3">
      {/* Live Full-Body Preview + Randomize */}
      <div className="flex items-center justify-between gap-3 bg-white/85 p-3 rounded-2xl border-2 border-espresso">
        <div className="flex items-center gap-3">
          <div className="w-16 h-20 rounded-2xl bg-mint/15 border-2 border-espresso flex items-center justify-center shrink-0">
            <AnimalAvatar
              species={species}
              color={avatarStyle.furColor}
              avatarStyle={avatarStyle}
              size={52}
              fullBody
            />
          </div>
          <div>
            <div className="text-sm font-black text-espresso">
              {SPECIES_META[species].flag} {SPECIES_META[species].label}
            </div>
            <div className="text-[11px] font-bold text-espresso-light">
              {SPECIES_META[species].city} · {SPECIES_META[species].pitchDesc}
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={handleRandomize}
          className="px-3 py-1.5 rounded-xl bg-coral text-espresso font-black text-xs nook-btn inline-flex items-center gap-1 shrink-0"
        >
          <Dices className="w-3.5 h-3.5" />
          <span>随机灵感搭配</span>
        </button>
      </div>

      {/* Layer 1: 8 Country Species */}
      <div>
        <label className="block text-[11px] font-extrabold text-espresso-light mb-1">
          1. 国家/地区代表动物 (8选1)
        </label>
        <div className={`grid ${compact ? 'grid-cols-4' : 'grid-cols-4 sm:grid-cols-8'} gap-1.5`}>
          {SPECIES_LIST.map((sp) => {
            const active = species === sp;
            const meta = SPECIES_META[sp];
            return (
              <button
                key={sp}
                type="button"
                onClick={() => {
                  onChangeSpecies(sp);
                  onChangeStyle({ ...avatarStyle, furColor: meta.defaultColor });
                }}
                className={`flex flex-col items-center p-1.5 rounded-xl border-2 transition-all ${
                  active
                    ? 'bg-coral/25 border-espresso shadow-nook-sm -translate-y-0.5'
                    : 'bg-white/75 border-espresso/20 hover:border-espresso/60'
                }`}
              >
                <AnimalAvatar species={sp} color={active ? avatarStyle.furColor : meta.defaultColor} size={30} />
                <span className="text-[10px] font-black text-espresso leading-tight mt-0.5">
                  {meta.flag} {meta.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Layer 2: 6 Fur Colors */}
      <div className="flex items-center justify-between gap-2 bg-white/60 px-3 py-2 rounded-xl border border-espresso/20">
        <span className="text-[11px] font-extrabold text-espresso-light">2. 治愈毛色</span>
        <div className="flex items-center gap-2">
          {FUR_COLORS.map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => onChangeStyle({ ...avatarStyle, furColor: c })}
              className={`w-6 h-6 rounded-full border-2 border-espresso transition-transform ${
                avatarStyle.furColor === c ? 'scale-125 ring-2 ring-mint' : 'opacity-85 hover:opacity-100'
              }`}
              style={{ backgroundColor: c }}
              aria-label={`fur-${c}`}
            />
          ))}
        </div>
      </div>

      {/* Layer 3: 7 Headwear (with Nook Miles unlock badges) */}
      <div>
        <div className="flex items-center justify-between mb-1">
          <label className="block text-[11px] font-extrabold text-espresso-light">
            3. 头饰配饰
          </label>
          {typeof miles === 'number' && (
            <span className="text-[10px] font-black text-coral-dark">
              🎫 当前余额：{miles} 里数
            </span>
          )}
        </div>
        <div className="flex flex-wrap gap-1.5">
          {HEADWEAR_OPTIONS.map((opt) => {
            const unlocked = opt.cost === 0 || (unlockedItems ? unlockedItems.includes(opt.id) : false);
            return (
              <button
                key={opt.id}
                type="button"
                onClick={() => handleSelectHeadwear(opt)}
                className={`px-2 py-1 rounded-xl text-[11px] font-black border-2 transition-all ${
                  avatarStyle.headwear === opt.id
                    ? 'bg-mint text-espresso border-espresso shadow-nook-sm'
                    : unlocked
                      ? 'bg-white text-espresso-light border-espresso/25 hover:border-espresso'
                      : 'bg-cream-dark/70 text-espresso-light border-dashed border-espresso/35 hover:border-coral'
                }`}
              >
                {opt.label}
                {!unlocked && <span className="ml-1 text-[9px] text-coral-dark">🔒{opt.cost}</span>}
              </button>
            );
          })}
        </div>
        {unlockHint && (
          <div className="mt-1 text-[10px] font-bold text-coral-dark">{unlockHint}</div>
        )}
      </div>

      {/* Layer 4: 5 Eyewear / Face */}
      <div>
        <label className="block text-[11px] font-extrabold text-espresso-light mb-1">
          4. 面部配饰
        </label>
        <div className="flex flex-wrap gap-1.5">
          {EYEWEAR_OPTIONS.map((opt) => (
            <button
              key={opt.id}
              type="button"
              onClick={() => onChangeStyle({ ...avatarStyle, eyewear: opt.id })}
              className={`px-2 py-1 rounded-xl text-[11px] font-black border-2 transition-all ${
                avatarStyle.eyewear === opt.id
                  ? 'bg-coral text-espresso border-espresso shadow-nook-sm'
                  : 'bg-white text-espresso-light border-espresso/25 hover:border-espresso'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* Layer 5: 5 Outfits */}
      <div>
        <label className="block text-[11px] font-extrabold text-espresso-light mb-1">
          5. 岛屿穿搭
        </label>
        <div className="flex flex-wrap gap-1.5">
          {OUTFIT_OPTIONS.map((opt) => (
            <button
              key={opt.id}
              type="button"
              onClick={() => onChangeStyle({ ...avatarStyle, outfit: opt.id })}
              className={`px-2 py-1 rounded-xl text-[11px] font-black border-2 transition-all ${
                avatarStyle.outfit === opt.id
                  ? 'bg-sage text-cream border-espresso shadow-nook-sm'
                  : 'bg-white text-espresso-light border-espresso/25 hover:border-espresso'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

interface AvatarWorkshopModalProps {
  initialSpecies: SpeciesType;
  initialStyle: AvatarStyle;
  miles: number;
  unlockedItems: string[];
  onUnlockItem: (itemId: string, cost: number) => boolean;
  onSave: (species: SpeciesType, style: AvatarStyle) => void;
  onClose: () => void;
}

export const AvatarWorkshopModal: React.FC<AvatarWorkshopModalProps> = ({
  initialSpecies,
  initialStyle,
  miles,
  unlockedItems,
  onUnlockItem,
  onSave,
  onClose,
}) => {
  const [species, setSpecies] = React.useState<SpeciesType>(initialSpecies);
  const [style, setStyle] = React.useState<AvatarStyle>(initialStyle);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-espresso/55 backdrop-blur-sm p-3 sm:p-4">
      <motion.div
        initial={{ scale: 0.92, opacity: 0, y: 16 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        className="w-full max-w-lg bg-cream nook-card overflow-hidden max-h-[90dvh] flex flex-col"
      >
        <div className="bg-coral px-5 py-3 border-b-[3px] border-espresso flex items-center justify-between shrink-0">
          <div className="font-black text-espresso text-base">
            👕 动物形象 DIY 工坊 · Wardrobe
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-cream border-2 border-espresso flex items-center justify-center"
          >
            <X className="w-4 h-4 text-espresso" />
          </button>
        </div>

        <div className="p-4 overflow-y-auto nook-scroll flex-1">
          <AvatarStudio
            species={species}
            avatarStyle={style}
            onChangeSpecies={setSpecies}
            onChangeStyle={setStyle}
            miles={miles}
            unlockedItems={unlockedItems}
            onUnlockItem={onUnlockItem}
          />
        </div>

        <div className="p-4 pt-2 border-t-2 border-espresso/15 flex justify-end gap-2 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-white border-2 border-espresso text-xs font-black text-espresso"
          >
            取消
          </button>
          <button
            type="button"
            onClick={() => {
              onSave(species, style);
              onClose();
            }}
            className="px-5 py-2 rounded-xl bg-mint text-espresso text-xs font-black nook-btn inline-flex items-center gap-1.5"
          >
            <Sparkles className="w-4 h-4" />
            保存新穿搭并同步全岛
          </button>
        </div>
      </motion.div>
    </div>
  );
};
