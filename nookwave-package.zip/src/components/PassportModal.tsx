import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Award, Check, CloudSun, Edit3, MapPin, X } from 'lucide-react';
import { IslanderProfile, StampInfo } from '../types/island';
import { AnimalAvatar, SPECIES_META } from './AnimalAvatar';
import { AI_ISLANDERS } from '../services/apiAdapter';

interface PassportModalProps {
  user: IslanderProfile;
  roomCode: string;
  stamps: StampInfo[];
  onUpdateProfile: (name: string, islandName: string) => void;
  onGreetFriend?: (friend: IslanderProfile) => void;
  onClose: () => void;
}

const StampSvg: React.FC<{ id: StampInfo['id']; unlocked: boolean }> = ({ id, unlocked }) => {
  const stroke = unlocked ? '#E0843B' : '#B8AFA3';
  const accent = unlocked ? '#78C2AD' : '#D6CFC3';

  return (
    <svg width="58" height="58" viewBox="0 0 80 80" fill="none">
      <circle cx="40" cy="40" r="35" stroke={stroke} strokeWidth="3" strokeDasharray="5 4" />
      <circle cx="40" cy="40" r="28" stroke={stroke} strokeWidth="2" />
      {id === 'tokyo' && (
        <>
          <path d="M22 44 C22 57, 58 57, 58 44 Z" fill={accent} stroke={stroke} strokeWidth="2.5" />
          <line x1="25" y1="36" x2="55" y2="30" stroke={stroke} strokeWidth="2.5" strokeLinecap="round" />
          <line x1="25" y1="40" x2="55" y2="35" stroke={stroke} strokeWidth="2.5" strokeLinecap="round" />
        </>
      )}
      {id === 'dubai' && (
        <>
          <path d="M26 36 H50 V48 C50 55, 26 55, 26 48 Z" fill={accent} stroke={stroke} strokeWidth="2.5" />
          <path d="M50 38 C58 38, 58 47, 50 47" stroke={stroke} strokeWidth="2.5" fill="none" />
          <path d="M33 27 Q36 22 33 18 M42 27 Q45 22 42 18" stroke={stroke} strokeWidth="2.2" strokeLinecap="round" />
        </>
      )}
      {id === 'paris' && (
        <>
          <path d="M40 16 L33 56 H47 Z" fill={accent} stroke={stroke} strokeWidth="2.5" strokeLinejoin="round" />
          <path d="M35 42 H45 M37 32 H43" stroke={stroke} strokeWidth="2.5" />
        </>
      )}
      {id === 'seoul' && (
        <>
          <circle cx="40" cy="40" r="15" fill={accent} stroke={stroke} strokeWidth="2.5" />
          <circle cx="40" cy="40" r="5" fill="#FAF6EB" stroke={stroke} strokeWidth="2" />
        </>
      )}
    </svg>
  );
};

type FriendFilter = 'all' | 'online' | 'highPrice' | 'giftable';

const FRIEND_META: Record<string, { online: boolean; highPrice: string | null; giftable: boolean }> = {
  'ai-kenji': { online: true, highPrice: '3x 收购🐼盖碗茶', giftable: true },
  'ai-tariq': { online: true, highPrice: '3x 收购🥐牛角包', giftable: true },
  'ai-camille': { online: true, highPrice: null, giftable: true },
  'ai-minji': { online: false, highPrice: '3x 收购🍵抹茶', giftable: false },
};

export const PassportModal: React.FC<PassportModalProps> = ({
  user,
  roomCode,
  stamps,
  onUpdateProfile,
  onGreetFriend,
  onClose,
}) => {
  const [timeStr, setTimeStr] = useState('');
  const [editing, setEditing] = useState(false);
  const [draftName, setDraftName] = useState(user.name);
  const [draftIsland, setDraftIsland] = useState(user.islandName || `${user.name}的电波岛`);
  const [friendFilter, setFriendFilter] = useState<FriendFilter>('all');

  useEffect(() => {
    const update = () => {
      setTimeStr(
        new Date().toLocaleTimeString('zh-CN', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      );
    };
    update();
    const timer = window.setInterval(update, 1000);
    return () => window.clearInterval(timer);
  }, []);

  const unlockedCount = stamps.filter((s) => s.unlocked).length;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const finalName = draftName.trim() || user.name;
    const finalIsland = draftIsland.trim() || `${finalName}的电波岛`;
    onUpdateProfile(finalName, finalIsland);
    setEditing(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-espresso/50 backdrop-blur-sm p-4">
      <motion.div
        initial={{ scale: 0.92, opacity: 0, y: 18 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        className="w-full max-w-md bg-cream nook-card overflow-hidden max-h-[90dvh] flex flex-col"
      >
        <div className="bg-sage px-5 py-3.5 border-b-[3px] border-espresso flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2 text-cream font-black text-base">
            <Award className="w-5 h-5" />
            Nook 岛屿护照 · PASSPORT
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-cream border-2 border-espresso flex items-center justify-center hover:bg-cream-dark"
          >
            <X className="w-4 h-4 text-espresso" />
          </button>
        </div>

        <div className="p-5 space-y-4 overflow-y-auto nook-scroll">
          {/* Profile Card */}
          <div className="bg-white p-3.5 rounded-2xl border-2 border-espresso space-y-3">
            <div className="flex items-center gap-3.5">
              <div className="p-1.5 rounded-2xl bg-cream border-2 border-espresso shrink-0">
                <AnimalAvatar
                  species={user.species}
                  color={user.color}
                  avatarStyle={user.avatarStyle}
                  size={60}
                  fullBody
                />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <div className="font-black text-base text-espresso truncate">
                    {user.countryFlag} {user.name}
                  </div>
                  <button
                    type="button"
                    onClick={() => setEditing((v) => !v)}
                    className="px-2 py-0.5 rounded-full bg-cream border border-espresso text-[10px] font-black text-espresso inline-flex items-center gap-1"
                  >
                    <Edit3 className="w-3 h-3" />
                    <span>{editing ? '取消' : '改名'}</span>
                  </button>
                </div>
                <div className="text-xs font-black text-mint-dark truncate mt-0.5">
                  🏝️ {user.islandName || `${user.name}的电波岛`}
                </div>
                <div className="text-[11px] font-bold text-espresso-light mt-0.5">
                  {SPECIES_META[user.species].label} · {SPECIES_META[user.species].pitchDesc}
                </div>
                <div className="flex flex-wrap items-center gap-1.5 mt-2 text-[11px] font-extrabold">
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-mint/20 border border-espresso/30">
                    <CloudSun className="w-3 h-3 text-coral-dark" />
                    {timeStr}
                  </span>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-coral/25 border border-espresso/30">
                    <MapPin className="w-3 h-3" />
                    {roomCode}
                  </span>
                </div>
              </div>
            </div>

            {editing && (
              <form onSubmit={handleSave} className="pt-2 border-t border-dashed border-espresso/20 space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    value={draftName}
                    onChange={(e) => setDraftName(e.target.value)}
                    placeholder="岛民昵称"
                    maxLength={14}
                    className="px-2.5 py-1.5 rounded-xl bg-cream border-2 border-espresso text-xs font-bold"
                  />
                  <input
                    type="text"
                    value={draftIsland}
                    onChange={(e) => setDraftIsland(e.target.value)}
                    placeholder="个人岛屿名称"
                    maxLength={18}
                    className="px-2.5 py-1.5 rounded-xl bg-cream border-2 border-espresso text-xs font-bold"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-1.5 rounded-xl bg-mint text-espresso font-black text-xs nook-btn inline-flex items-center justify-center gap-1"
                >
                  <Check className="w-3.5 h-3.5" />
                  保存昵称与岛名
                </button>
              </form>
            )}
          </div>

          {/* Commemorative Stamps */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-black text-espresso">
                跨国纪念邮票印章 ({unlockedCount}/{stamps.length})
              </span>
              <span className="text-[11px] font-bold text-espresso-light">
                与对应国家岛民对话自动点亮
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2.5">
              {stamps.map((stamp) => (
                <div
                  key={stamp.id}
                  className={`p-2.5 rounded-2xl border-2 flex items-center gap-2 transition-all ${
                    stamp.unlocked
                      ? 'bg-white border-espresso shadow-nook-sm'
                      : 'bg-cream-dark/50 border-dashed border-espresso/30 opacity-65'
                  }`}
                >
                  <StampSvg id={stamp.id} unlocked={stamp.unlocked} />
                  <div className="min-w-0">
                    <div className="text-xs font-black text-espresso truncate">
                      {stamp.flag} {stamp.title}
                    </div>
                    <div className="text-[11px] font-bold text-espresso-light">{stamp.city}</div>
                    <div className="text-[10px] font-extrabold mt-0.5 text-mint-dark">
                      {stamp.unlocked ? '✓ 已盖章' : '待解锁'}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Friends & Island List with 1st-level Filter Tabs */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-black text-espresso">
                🌍 护照好友录 & 岛屿行情
              </span>
            </div>
            <div className="flex items-center gap-1.5 mb-2.5 overflow-x-auto no-scrollbar">
              {[
                { id: 'all' as FriendFilter, label: '全部' },
                { id: 'online' as FriendFilter, label: '在线' },
                { id: 'highPrice' as FriendFilter, label: '今日高价' },
                { id: 'giftable' as FriendFilter, label: '可送礼' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setFriendFilter(tab.id)}
                  className={`px-2.5 py-1 rounded-full text-[11px] font-black border-2 whitespace-nowrap transition-all ${
                    friendFilter === tab.id
                      ? 'bg-mint text-espresso border-espresso shadow-nook-sm'
                      : 'bg-white text-espresso-light border-espresso/25 hover:border-espresso'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
            <div className="space-y-1.5">
              {AI_ISLANDERS.filter((f) => {
                const meta = FRIEND_META[f.id];
                if (!meta) return true;
                if (friendFilter === 'online') return meta.online;
                if (friendFilter === 'highPrice') return Boolean(meta.highPrice);
                if (friendFilter === 'giftable') return meta.giftable;
                return true;
              }).map((friend) => {
                const meta = FRIEND_META[friend.id];
                return (
                  <div
                    key={friend.id}
                    className="p-2 rounded-2xl bg-white border-2 border-espresso/40 flex items-center justify-between gap-2"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <AnimalAvatar
                        species={friend.species}
                        color={friend.color}
                        avatarStyle={friend.avatarStyle}
                        size={30}
                      />
                      <div className="min-w-0">
                        <div className="text-xs font-black text-espresso truncate">
                          {friend.countryFlag} {friend.name}
                          {meta?.online && (
                            <span className="ml-1.5 inline-block w-2 h-2 rounded-full bg-sage" />
                          )}
                        </div>
                        <div className="text-[10px] font-bold text-espresso-light truncate">
                          {friend.city}
                          {meta?.highPrice && (
                            <span className="ml-1.5 text-coral-dark font-black">
                              · {meta.highPrice}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    {onGreetFriend && (
                      <button
                        type="button"
                        onClick={() => {
                          onGreetFriend(friend);
                          onClose();
                        }}
                        className="px-2.5 py-1 rounded-xl bg-coral text-espresso text-[10px] font-black nook-btn shrink-0"
                      >
                        打招呼
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
