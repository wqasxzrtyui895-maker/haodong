import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plane, Sparkles } from 'lucide-react';
import { AvatarStyle, IslanderProfile, LanguageCode, SpeciesType } from '../types/island';
import { animaleseAudio } from '../utils/animaleseAudio';
import { AvatarStudio } from './AvatarStudio';

interface BoardingModalProps {
  roomCode: string;
  onBoard: (profile: IslanderProfile) => void;
}

const LANGUAGES: Array<{ code: LanguageCode; label: string; flag: string }> = [
  { code: 'zh', label: '中文', flag: '🇨🇳' },
  { code: 'en', label: 'English', flag: '🇬🇧' },
  { code: 'ja', label: '日本語', flag: '🇯🇵' },
  { code: 'ko', label: '한국어', flag: '🇰🇷' },
  { code: 'fr', label: 'Français', flag: '🇫🇷' },
  { code: 'es', label: 'Español', flag: '🇪🇸' },
  { code: 'ar', label: 'العربية', flag: '🇦🇪' },
];

export const BoardingModal: React.FC<BoardingModalProps> = ({ roomCode, onBoard }) => {
  const [name, setName] = useState('阿森');
  const [islandName, setIslandName] = useState('阿森的星愿岛');
  const [nativeLang, setNativeLang] = useState<LanguageCode>('zh');
  const [species, setSpecies] = useState<SpeciesType>('panda');
  const [avatarStyle, setAvatarStyle] = useState<AvatarStyle>({
    furColor: '#FAF6EB',
    headwear: 'leaf',
    eyewear: 'none',
    outfit: 'leafShirt',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await animaleseAudio.resume();
    animaleseAudio.playBoardingSound();

    const finalName = name.trim() || '旅行者';
    const finalIsland = islandName.trim() || `${finalName}的电波岛`;
    const langInfo = LANGUAGES.find((l) => l.code === nativeLang) ?? LANGUAGES[0];
    const profile: IslanderProfile = {
      id: `player-${Date.now().toString(36)}`,
      name: finalName,
      islandName: finalIsland,
      species,
      color: avatarStyle.furColor,
      avatarStyle,
      nativeLang,
      city: 'NookWave 旅人',
      countryFlag: langInfo.flag,
      isAI: false,
    };
    onBoard(profile);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-espresso/55 backdrop-blur-sm p-3 sm:p-4 overflow-y-auto">
      <motion.div
        initial={{ scale: 0.9, y: 24, opacity: 0 }}
        animate={{ scale: 1, y: 0, opacity: 1 }}
        transition={{ type: 'spring', stiffness: 260, damping: 22 }}
        className="w-full max-w-xl bg-cream nook-card overflow-hidden my-auto max-h-[94dvh] flex flex-col"
      >
        {/* Dodo Airlines Ticket Header */}
        <div className="bg-mint px-5 py-3 border-b-[3px] border-espresso flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5 text-cream">
            <div className="w-8 h-8 rounded-full bg-cream text-espresso border-2 border-espresso flex items-center justify-center">
              <Plane className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[10px] font-extrabold tracking-widest uppercase text-espresso/80">
                DODO AIRLINES · 登岛机票
              </div>
              <div className="text-sm sm:text-base font-black text-espresso leading-tight">
                森友电波岛 NookWave
              </div>
            </div>
          </div>
          <div className="bg-cream px-3 py-1 rounded-full border-2 border-espresso text-xs font-black tracking-wider">
            {roomCode}
          </div>
        </div>

        {/* Dashed Tear-Off Perforation */}
        <div className="relative h-3.5 bg-cream-dark/60 flex items-center shrink-0">
          <div className="w-3.5 h-3.5 rounded-full bg-espresso/55 -ml-2" />
          <div className="flex-1 border-b-2 border-dashed border-espresso/40 mx-1" />
          <div className="w-3.5 h-3.5 rounded-full bg-espresso/55 -mr-2" />
        </div>

        <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-3.5 overflow-y-auto nook-scroll flex-1">
          {/* Nickname + Personal Island Name */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div>
              <label className="block text-[11px] font-extrabold text-espresso-light mb-1">
                我的岛民昵称
              </label>
              <input
                type="text"
                maxLength={14}
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="例如：阿森"
                className="w-full px-3 py-2 rounded-xl bg-white border-2 border-espresso text-sm font-bold text-espresso focus:outline-none focus:ring-2 focus:ring-mint"
              />
            </div>
            <div>
              <label className="block text-[11px] font-extrabold text-espresso-light mb-1">
                我的专属个人岛名
              </label>
              <input
                type="text"
                maxLength={18}
                value={islandName}
                onChange={(e) => setIslandName(e.target.value)}
                placeholder="例如：阿森的星愿岛"
                className="w-full px-3 py-2 rounded-xl bg-white border-2 border-espresso text-sm font-bold text-espresso focus:outline-none focus:ring-2 focus:ring-mint"
              />
            </div>
          </div>

          {/* Native Language */}
          <div>
            <label className="block text-[11px] font-extrabold text-espresso-light mb-1">
              我的母语电波频道
            </label>
            <div className="flex flex-wrap gap-1.5">
              {LANGUAGES.map((lang) => {
                const active = nativeLang === lang.code;
                return (
                  <button
                    key={lang.code}
                    type="button"
                    onClick={() => setNativeLang(lang.code)}
                    className={`px-2.5 py-1 rounded-xl text-xs font-bold border-2 transition-all ${
                      active
                        ? 'bg-mint text-espresso border-espresso shadow-nook-sm'
                        : 'bg-white text-espresso border-espresso/25 hover:border-espresso'
                    }`}
                  >
                    {lang.flag} {lang.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* 5-Layer Animal DIY Studio */}
          <AvatarStudio
            species={species}
            avatarStyle={avatarStyle}
            onChangeSpecies={setSpecies}
            onChangeStyle={setAvatarStyle}
            compact
          />

          {/* Submit */}
          <button
            type="submit"
            className="w-full py-3 rounded-2xl bg-coral hover:bg-coral-dark text-espresso font-black text-base nook-btn flex items-center justify-center gap-2"
          >
            <Sparkles className="w-5 h-5" />
            乘坐水上飞机登岛 ✈️
          </button>
        </form>
      </motion.div>
    </div>
  );
};
