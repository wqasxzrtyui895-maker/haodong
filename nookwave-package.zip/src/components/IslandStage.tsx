import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Coffee, Dices, MessageCircleHeart, Volume2, X } from 'lucide-react';
import {
  FurnitureId,
  IslandMode,
  IslandTheme,
  IslanderProfile,
  ReactionType,
} from '../types/island';
import { AnimalAvatar } from './AnimalAvatar';

export interface IslandBubbleData {
  primary: string;
  secondary?: string;
  onSpeak?: () => void;
}

export interface ResidentEventData {
  residentId: string;
  prompt: string;
  options: Array<{ label: string; reply: string; reward: number }>;
}

interface IslandStageProps {
  theme: IslandTheme;
  islandMode: IslandMode;
  player: IslanderProfile;
  islanders: IslanderProfile[];
  placedFurniture: FurnitureId[];
  unlockedItems: string[];
  miles: number;
  showDecorDrawer: boolean;
  onCloseDecorDrawer: () => void;
  onToggleFurniture: (id: FurnitureId, cost: number) => void;
  micVolume: number;
  isVoiceActive: boolean;
  interimOriginal: string;
  interimTranslated: string;
  islandBubbles: Record<string, IslandBubbleData>;
  arrivalBanner: string | null;
  balloonActive: boolean;
  onPopBalloon: () => void;
  residentEvent: ResidentEventData | null;
  onResolveResidentEvent: (resident: IslanderProfile, reply: string, reward: number) => void;
  activeReaction: { targetId: string; type: ReactionType; key: number } | null;
  groupReaction: { type: ReactionType; key: number } | null;
  onOpenBottle: () => void;
  onOpenDodo: () => void;
  onQuickGreet: (target: IslanderProfile) => void;
  onBuyCoffee: (target: IslanderProfile) => void;
  onDrawIcebreaker: () => void;
  onEnterCampfire?: () => void;
}

const THEME_META: Record<
  IslandTheme,
  {
    name: string;
    skyTop: string;
    skyMid: string;
    skyBot: string;
    deepSea: string;
    shallowSea: string;
    sand: string;
    sandShade: string;
    groundTop: string;
    groundBot: string;
    cliffFace: string;
    cliffShade: string;
    pathColor: string;
    isNight: boolean;
  }
> = {
  chengdu: {
    name: '🇨🇳 成都竹海茶社',
    skyTop: '#7EC8E3',
    skyMid: '#B9E6DC',
    skyBot: '#F7F3E3',
    deepSea: '#2D7D7A',
    shallowSea: '#63C5B8',
    sand: '#F5DFB0',
    sandShade: '#D7B97E',
    groundTop: '#8BD46E',
    groundBot: '#5AAE4A',
    cliffFace: '#A67C52',
    cliffShade: '#7A5636',
    pathColor: '#D9CDB8',
    isNight: false,
  },
  tokyo: {
    name: '🇯🇵 东京夜樱屋台',
    skyTop: '#14132E',
    skyMid: '#2D2459',
    skyBot: '#6B427B',
    deepSea: '#1C224A',
    shallowSea: '#433A7A',
    sand: '#C9B3C7',
    sandShade: '#9A829C',
    groundTop: '#5E4B75',
    groundBot: '#3E2F52',
    cliffFace: '#685873',
    cliffShade: '#45384F',
    pathColor: '#B8A8B8',
    isNight: true,
  },
  dubai: {
    name: '🇦🇪 迪拜金沙绿洲',
    skyTop: '#D96B43',
    skyMid: '#F4A261',
    skyBot: '#FDE49E',
    deepSea: '#26687A',
    shallowSea: '#48A9B8',
    sand: '#F6D186',
    sandShade: '#D6A656',
    groundTop: '#F4C66A',
    groundBot: '#D99B3C',
    cliffFace: '#B87D4B',
    cliffShade: '#8A5830',
    pathColor: '#EBD3A7',
    isNight: false,
  },
  paris: {
    name: '🇫🇷 巴黎塞纳雨夜',
    skyTop: '#16213E',
    skyMid: '#283C63',
    skyBot: '#536D8E',
    deepSea: '#1E324A',
    shallowSea: '#385A7C',
    sand: '#B8B2A6',
    sandShade: '#8F887B',
    groundTop: '#8E8B84',
    groundBot: '#6B6862',
    cliffFace: '#757069',
    cliffShade: '#524E49',
    pathColor: '#B5AFA4',
    isNight: true,
  },
  reykjavik: {
    name: '🇮🇸 冰岛极光雪夜',
    skyTop: '#0B192C',
    skyMid: '#16324F',
    skyBot: '#295773',
    deepSea: '#1A3E52',
    shallowSea: '#3D7E96',
    sand: '#CFE0EA',
    sandShade: '#9FB9C9',
    groundTop: '#F4F9FC',
    groundBot: '#D2E5F0',
    cliffFace: '#6D8596',
    cliffShade: '#4B6170',
    pathColor: '#B8D0DE',
    isNight: true,
  },
};

export const FURNITURE_CATALOG: Array<{
  id: FurnitureId;
  emoji: string;
  label: string;
  cost: number;
}> = [
  { id: 'campfire', emoji: '🔥', label: '暖心篝火', cost: 0 },
  { id: 'bambooTea', emoji: '🎋', label: '翠竹茶桌', cost: 0 },
  { id: 'cafeSet', emoji: '☕', label: '露天咖啡座', cost: 100 },
  { id: 'lanterns', emoji: '🏮', label: '庆典灯笼串', cost: 120 },
  { id: 'tent', emoji: '⛺', label: '复古露营帐篷', cost: 150 },
  { id: 'sakuraTree', emoji: '🌸', label: '垂枝樱花树', cost: 200 },
  { id: 'ramenStall', emoji: '🍜', label: '深夜拉面摊', cost: 250 },
  { id: 'onsen', emoji: '♨️', label: '露天温泉', cost: 300 },
];

const REACTION_EMOJI: Record<ReactionType, string> = {
  clap: '👏',
  flower: '🌸',
  coffee: '☕',
  firework: '🎉',
  shock: '😲',
  dance: '💃',
};

const RESIDENT_POS_BY_ID: Record<string, { xPct: number; yPct: number }> = {
  'ai-camille': { xPct: 24, yPct: 39 },
  'ai-kenji': { xPct: 22, yPct: 63 },
  'ai-tariq': { xPct: 76, yPct: 39 },
  'ai-minji': { xPct: 76, yPct: 64 },
};

const GATHER_POSITIONS: Array<{ xPct: number; yPct: number }> = [
  { xPct: 39, yPct: 47 },
  { xPct: 61, yPct: 47 },
  { xPct: 37, yPct: 61 },
  { xPct: 63, yPct: 61 },
];

const OverheadBubble: React.FC<{
  primary: string;
  secondary?: string;
  dashed?: boolean;
  onSpeak?: () => void;
}> = ({ primary, secondary, dashed = false, onSpeak }) => (
  <motion.div
    initial={{ opacity: 0, y: 6, scale: 0.9 }}
    animate={{ opacity: 1, y: 0, scale: 1 }}
    exit={{ opacity: 0, y: -4, scale: 0.92 }}
    className={`relative mb-1 max-w-[175px] sm:max-w-[220px] px-2.5 py-1.5 rounded-2xl bg-cream/95 border-2 ${
      dashed ? 'border-dashed italic' : 'border-solid'
    } border-espresso shadow-nook-sm text-center`}
  >
    <div className="flex items-start justify-center gap-1">
      <div className="text-[10.5px] font-black text-espresso leading-snug line-clamp-2">
        {primary}
      </div>
      {onSpeak && !dashed && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onSpeak();
          }}
          className="w-4 h-4 rounded-full bg-mint/40 border border-espresso/40 flex items-center justify-center shrink-0 mt-0.5 hover:bg-coral/40"
          title="朗读外语"
        >
          <Volume2 className="w-2.5 h-2.5 text-espresso" />
        </button>
      )}
    </div>
    {secondary && (
      <div className="text-[9px] font-semibold text-espresso-light mt-0.5 truncate">
        {secondary}
      </div>
    )}
    <div className="w-2 h-2 bg-cream border-r-2 border-b-2 border-espresso rotate-45 mx-auto -mb-2 mt-0.5" />
  </motion.div>
);

/**
 * Handcrafted multi-lobed Animal Crossing style tree SVG.
 */
const LushTree: React.FC<{
  x: number;
  y: number;
  scale?: number;
  leafMain: string;
  leafLight: string;
  leafDark: string;
  fruitColor?: string;
}> = ({ x, y, scale = 1, leafMain, leafLight, leafDark, fruitColor }) => (
  <g transform={`translate(${x}, ${y}) scale(${scale})`}>
    {/* Cast shadow */}
    <ellipse cx="38" cy="92" rx="28" ry="9" fill="#1F1A17" opacity="0.22" />
    {/* Curved trunk */}
    <path
      d="M27 54 Q29 74 23 90 L41 90 Q36 74 37 54 Z"
      fill="#8D5B4C"
      stroke="#4A4238"
      strokeWidth="2.5"
      strokeLinejoin="round"
    />
    <path d="M30 62 L30 84" stroke="#6E4234" strokeWidth="2" strokeLinecap="round" opacity="0.55" />
    {/* Lower-right shaded foliage puff */}
    <circle cx="44" cy="46" r="21" fill={leafDark} stroke="#4A4238" strokeWidth="2.5" />
    {/* Lower-left foliage puff */}
    <circle cx="19" cy="46" r="20" fill={leafMain} stroke="#4A4238" strokeWidth="2.5" />
    {/* Top crown puff */}
    <circle cx="32" cy="27" r="23" fill={leafMain} stroke="#4A4238" strokeWidth="2.5" />
    {/* Seamless inner foliage fill */}
    <circle cx="32" cy="39" r="21" fill={leafMain} />
    {/* Sunlit top-left highlight puff */}
    <ellipse cx="26" cy="20" rx="13" ry="9" fill={leafLight} opacity="0.72" transform="rotate(-15 26 20)" />
    {/* Fruits */}
    {fruitColor && (
      <g>
        <circle cx="18" cy="41" r="4.5" fill={fruitColor} stroke="#4A4238" strokeWidth="1.6" />
        <circle cx="16.8" cy="39.8" r="1.4" fill="#FFFFFF" opacity="0.7" />
        <circle cx="35" cy="25" r="4.5" fill={fruitColor} stroke="#4A4238" strokeWidth="1.6" />
        <circle cx="33.8" cy="23.8" r="1.4" fill="#FFFFFF" opacity="0.7" />
        <circle cx="44" cy="44" r="4.5" fill={fruitColor} stroke="#4A4238" strokeWidth="1.6" />
        <circle cx="42.8" cy="42.8" r="1.4" fill="#FFFFFF" opacity="0.7" />
      </g>
    )}
  </g>
);

export const IslandStage: React.FC<IslandStageProps> = ({
  theme,
  islandMode,
  player,
  islanders,
  placedFurniture,
  unlockedItems,
  miles,
  showDecorDrawer,
  onCloseDecorDrawer,
  onToggleFurniture,
  micVolume,
  isVoiceActive,
  interimOriginal,
  interimTranslated,
  islandBubbles,
  arrivalBanner,
  balloonActive,
  onPopBalloon,
  residentEvent,
  onResolveResidentEvent,
  activeReaction,
  groupReaction,
  onOpenBottle,
  onOpenDodo,
  onQuickGreet,
  onBuyCoffee,
  onDrawIcebreaker,
  onEnterCampfire,
}) => {
  const stageRef = useRef<HTMLDivElement | null>(null);
  const [selectedResident, setSelectedResident] = useState<IslanderProfile | null>(null);
  const [isPageVisible, setIsPageVisible] = useState(true);

  const [playerPos, setPlayerPos] = useState<{ xPct: number; yPct: number }>({
    xPct: 49,
    yPct: 54,
  });
  const [isSeated, setIsSeated] = useState(false);
  const [isWalking, setIsWalking] = useState(false);
  const walkTimerRef = useRef<number | null>(null);
  const [walkRipple, setWalkRipple] = useState<{ xPct: number; yPct: number; key: number } | null>(
    null
  );

  const inPrivateZone =
    (playerPos.xPct <= 33 && playerPos.yPct >= 44 && playerPos.yPct <= 64) ||
    (playerPos.xPct >= 67 && playerPos.yPct >= 44 && playerPos.yPct <= 64);

  const meta = THEME_META[theme];

  useEffect(() => {
    const handleVis = () => setIsPageVisible(!document.hidden);
    document.addEventListener('visibilitychange', handleVis);
    return () => document.removeEventListener('visibilitychange', handleVis);
  }, []);

  // Clear open resident popup when switching region
  useEffect(() => {
    setSelectedResident(null);
  }, [theme]);

  const triggerWalkAnim = () => {
    setIsWalking(true);
    if (walkTimerRef.current) window.clearTimeout(walkTimerRef.current);
    walkTimerRef.current = window.setTimeout(() => setIsWalking(false), 650);
  };

  const handleStageClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!stageRef.current) return;
    const rect = stageRef.current.getBoundingClientRect();
    const rawX = ((e.clientX - rect.left) / rect.width) * 100;
    const rawY = ((e.clientY - rect.top) / rect.height) * 100;
    const xPct = Math.max(17, Math.min(83, rawX));
    const yPct = Math.max(36, Math.min(72, rawY));

    setSelectedResident(null);
    setIsSeated(false);
    setPlayerPos({ xPct, yPct });
    setWalkRipple({ xPct, yPct, key: Date.now() });
    triggerWalkAnim();
  };

  const handleSitOnBench = (side: 'left' | 'right', e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedResident(null);
    setPlayerPos(side === 'left' ? { xPct: 42, yPct: 55 } : { xPct: 58, yPct: 55 });
    setIsSeated(true);
    triggerWalkAnim();
    onEnterCampfire?.();
  };

  const handleSelectResident = (resident: IslanderProfile, e: React.MouseEvent) => {
    e.stopPropagation();
    const pos = RESIDENT_POS_BY_ID[resident.id] ?? { xPct: 50, yPct: 50 };
    setIsSeated(false);
    setPlayerPos({
      xPct: pos.xPct + (pos.xPct < 50 ? 9 : -9),
      yPct: pos.yPct + 2,
    });
    triggerWalkAnim();
    setSelectedResident(resident);
  };

  return (
    <div
      ref={stageRef}
      className="relative w-full h-full rounded-3xl border-[3px] border-espresso shadow-nook overflow-hidden select-none"
    >
      {/* Private Space Zone Gentle Toast */}
      <AnimatePresence>
        {inPrivateZone && (
          <motion.div
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            className="absolute top-3 left-1/2 -translate-x-1/2 z-30 px-3 py-1 rounded-full bg-mint/95 border-2 border-espresso shadow-nook-sm text-[10.5px] font-black text-espresso whitespace-nowrap"
          >
            ☕ 进入私密双语对话区（已屏蔽周围噪声）
          </motion.div>
        )}
      </AnimatePresence>

      {/* Dodo Airport Live Arrival Banner */}
      <AnimatePresence>
        {arrivalBanner && !inPrivateZone && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.94 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -16, scale: 0.94 }}
            className="absolute top-3 left-1/2 -translate-x-1/2 z-30 px-3 py-1 rounded-full bg-cream/95 border-2 border-espresso shadow-nook-sm text-[10.5px] font-black text-espresso whitespace-nowrap max-w-[92%] truncate"
          >
            {arrivalBanner}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Gift Balloon */}
      <AnimatePresence>
        {balloonActive && (
          <motion.button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onPopBalloon();
            }}
            initial={{ left: '-8%', top: '16%' }}
            animate={{
              left: '96%',
              top: ['16%', '12%', '20%', '14%'],
            }}
            exit={{ scale: 1.8, opacity: 0 }}
            transition={{
              left: { duration: 15, ease: 'linear' },
              top: { duration: 4, repeat: Infinity, ease: 'easeInOut' },
            }}
            className="absolute z-30 -translate-x-1/2 -translate-y-1/2 cursor-pointer focus:outline-none hover:scale-110 transition-transform"
            title="点击戳破礼物气球！"
          >
            <svg width="44" height="60" viewBox="0 0 60 80" fill="none">
              <path d="M30 42 Q28 50 32 56" stroke="#4A4238" strokeWidth="2.5" />
              <ellipse cx="30" cy="22" rx="18" ry="20" fill="#F28482" stroke="#4A4238" strokeWidth="3" />
              <ellipse cx="24" cy="15" rx="4" ry="7" fill="#FFFFFF" opacity="0.45" />
              <rect x="19" y="56" width="22" height="18" rx="4" fill="#FAF6EB" stroke="#4A4238" strokeWidth="2.8" />
              <line x1="30" y1="56" x2="30" y2="74" stroke="#E76F51" strokeWidth="4" />
              <line x1="19" y1="65" x2="41" y2="65" stroke="#E76F51" strokeWidth="4" />
            </svg>
          </motion.button>
        )}
      </AnimatePresence>

      {/* DIY Furniture Drawer (Triggered via NookPhone) */}
      <AnimatePresence>
        {showDecorDrawer && (
          <motion.div
            initial={{ opacity: 0, y: -10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            className="absolute top-3 right-3 z-30 w-68 bg-cream nook-card p-3 space-y-2"
          >
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-black text-espresso">
                🔨 岛屿装扮 (余额 {miles} 里数)
              </span>
              <button
                type="button"
                onClick={onCloseDecorDrawer}
                className="w-5 h-5 rounded-full bg-white border border-espresso flex items-center justify-center"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              {FURNITURE_CATALOG.map((item) => {
                const placed = placedFurniture.includes(item.id);
                const unlocked = item.cost === 0 || unlockedItems.includes(item.id);
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => onToggleFurniture(item.id, item.cost)}
                    className={`px-2 py-1.5 rounded-xl border-2 text-[10.5px] font-black text-left transition-all flex items-center justify-between gap-1 ${
                      placed
                        ? 'bg-mint text-espresso border-espresso shadow-nook-sm'
                        : unlocked
                          ? 'bg-white text-espresso-light border-espresso/25 hover:border-espresso'
                          : 'bg-cream-dark/70 text-espresso-light border-dashed border-espresso/35 hover:border-coral'
                    }`}
                  >
                    <span className="truncate">
                      {item.emoji} {item.label}
                    </span>
                    {!unlocked && (
                      <span className="text-[9px] text-coral-dark shrink-0">🔒{item.cost}</span>
                    )}
                  </button>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Unified Flat Comic Sticker 2.5D Plaza SVG (Zoomed-in camera viewBox) */}
      <svg
        key={theme}
        viewBox="95 95 610 355"
        preserveAspectRatio="xMidYMid slice"
        onClick={handleStageClick}
        className="w-full h-full block cursor-pointer"
      >
        <defs>
          <linearGradient id={`skyGrad-${theme}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={meta.skyTop} />
            <stop offset="100%" stopColor={meta.skyBot} />
          </linearGradient>
          <linearGradient id={`auroraGrad-${theme}`} x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#52B788" stopOpacity="0.15" />
            <stop offset="40%" stopColor="#52E5B7" stopOpacity="0.7" />
            <stop offset="75%" stopColor="#A663CC" stopOpacity="0.6" />
            <stop offset="100%" stopColor="#52B788" stopOpacity="0.15" />
          </linearGradient>
        </defs>

        {/* 1. Flat Comic Sky */}
        <rect x="95" y="95" width="610" height="355" fill={`url(#skyGrad-${theme})`} />

        {/* Distant Horizon Clouds / Silhouettes */}
        {!meta.isNight && (
          <g opacity="0.72" fill="#FFFFFF">
            <path d="M40 92 Q65 72 95 84 Q120 65 148 84 Q172 78 184 96 L40 96 Z" />
            <path d="M580 78 Q605 56 640 70 Q668 50 698 72 Q725 66 740 84 L580 84 Z" />
          </g>
        )}

        {theme === 'dubai' && (
          <g>
            <circle cx="400" cy="138" r="68" fill="#FFF3B0" opacity="0.28" />
            <circle cx="400" cy="138" r="46" fill="#FFE699" opacity="0.92" />
            {/* Distant desert skyline silhouette */}
            <path
              d="M0 156 L80 144 L180 154 L300 142 L390 152 L400 94 L410 152 L530 140 L670 152 L800 142 L800 160 L0 160 Z"
              fill="#C9643B"
              opacity="0.32"
            />
          </g>
        )}

        {theme === 'reykjavik' && (
          <g>
            {/* Distant snow-capped mountains */}
            <path
              d="M0 158 L95 108 L175 142 L265 96 L355 145 L465 104 L575 142 L685 98 L800 146 L800 160 L0 160 Z"
              fill="#355C7D"
              opacity="0.55"
            />
            <path d="M95 108 L76 125 L114 125 Z M265 96 L242 118 L288 118 Z M685 98 L662 120 L708 120 Z" fill="#EBF5FA" opacity="0.7" />
            {isPageVisible && (
              <motion.path
                d="M40 72 Q220 20, 400 66 T760 48 L760 110 Q560 128, 400 92 T40 116 Z"
                fill={`url(#auroraGrad-${theme})`}
                animate={{ y: [-6, 8, -6], opacity: [0.6, 0.95, 0.6] }}
                transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
              />
            )}
          </g>
        )}

        {theme === 'paris' && (
          <g>
            {/* Parisian Rooftops & Detailed Lattice Eiffel Tower */}
            <path
              d="M0 158 L0 132 L65 132 L85 118 L120 132 L210 132 L210 140 L590 140 L615 124 L670 136 L740 128 L800 138 L800 158 Z"
              fill="#18263D"
              opacity="0.55"
            />
            <g transform="translate(370, 42)">
              <path d="M30 0 L26 42 L18 76 L6 116 H18 L24 94 H36 L42 116 H54 L42 76 L34 42 Z" fill="#233754" stroke="#FDE49E" strokeWidth="1.4" />
              <line x1="21" y1="68" x2="39" y2="68" stroke="#FDE49E" strokeWidth="2" />
              <line x1="25" y1="42" x2="35" y2="42" stroke="#FDE49E" strokeWidth="2" />
              <circle cx="30" cy="4" r="3.5" fill="#FFF3B0" />
            </g>
          </g>
        )}

        {theme === 'tokyo' && (
          <g>
            {/* Distant Tokyo Hills & Stars */}
            <path d="M0 158 Q180 128 380 148 Q600 124 800 152 L800 160 L0 160 Z" fill="#221942" opacity="0.55" />
            {isPageVisible &&
              [
                [85, 48],
                [175, 82],
                [295, 40],
                [515, 36],
                [665, 72],
                [735, 45],
              ].map(([cx, cy], idx) => (
                <motion.circle
                  key={idx}
                  cx={cx}
                  cy={cy}
                  r={2}
                  fill="#FFF3B0"
                  animate={{ opacity: [0.3, 1, 0.3] }}
                  transition={{ duration: 2.2 + idx * 0.4, repeat: Infinity }}
                />
              ))}
          </g>
        )}

        {/* 2. Clean Flat Comic Ocean + Shallow Turquoise Coast Band */}
        <rect x="95" y="154" width="610" height="300" fill={meta.deepSea} />
        <ellipse cx="400" cy="312" rx="340" ry="148" fill={meta.shallowSea} opacity="0.65" />

        {/* Floating Icebergs in Reykjavik */}
        {theme === 'reykjavik' && (
          <g stroke="#4A4238" strokeWidth="2" strokeLinejoin="round">
            <polygon points="62,226 112,216 130,236 74,244" fill="#EBF5FA" />
            <polygon points="668,236 724,228 738,248 680,254" fill="#EBF5FA" />
          </g>
        )}

        {/* Animated Shoreline Sea Foam */}
        <motion.path
          d="M95 312 C95 224, 240 168, 400 168 C560 168, 705 224, 705 312 C705 404, 565 456, 400 456 C235 456, 95 404, 95 312 Z"
          fill="none"
          stroke="#FFFFFF"
          strokeWidth="3.5"
          strokeDasharray="18 10"
          opacity="0.4"
          animate={isPageVisible ? { strokeDashoffset: [0, 56] } : undefined}
          transition={{ duration: 8, repeat: Infinity, ease: 'linear' }}
        />

        {/* 3. Organic Hand-Sculpted 2.5D Island Diorama Base */}
        {/* 3a. Rocky Cliff Extrusion */}
        <path
          d="M106 286 L106 332 C112 408, 246 446, 400 446 C554 446, 688 408, 694 332 L694 286 Z"
          fill={meta.cliffFace}
          stroke="#4A4238"
          strokeWidth="3.5"
          strokeLinejoin="round"
        />
        <g stroke="#4A4238" strokeWidth="2" opacity="0.22" strokeLinecap="round">
          <line x1="185" y1="364" x2="185" y2="394" />
          <line x1="295" y1="398" x2="295" y2="428" />
          <line x1="400" y1="408" x2="400" y2="440" />
          <line x1="510" y1="396" x2="510" y2="426" />
          <line x1="620" y1="362" x2="620" y2="392" />
        </g>

        {/* 3b. Organic Sandy Beach Coastline */}
        <path
          d="M106 290 C106 212, 244 166, 400 166 C556 166, 694 212, 694 290 C694 374, 560 416, 400 416 C240 416, 106 374, 106 290 Z"
          fill={meta.sand}
          stroke="#4A4238"
          strokeWidth="3.5"
        />

        {/* 3c. Upper Plateau Overhang Rim + Grass/Snow/Desert Surface */}
        <path
          d="M150 280 C150 212, 266 174, 400 174 C534 174, 650 212, 650 280 C650 350, 534 388, 400 388 C266 388, 150 350, 150 280 Z"
          fill={meta.sandShade}
          opacity="0.45"
        />
        <path
          d="M152 272 C152 204, 268 168, 400 168 C532 168, 648 204, 648 272 C648 342, 532 378, 400 378 C268 378, 152 342, 152 272 Z"
          fill={meta.groundTop}
          stroke="#4A4238"
          strokeWidth="3.2"
        />

        {/* 4. Winding Cobblestone Plaza Path + Central Circle */}
        <ellipse
          cx="400"
          cy="274"
          rx="96"
          ry="44"
          fill={meta.pathColor}
          stroke="#4A4238"
          strokeWidth="2"
          opacity="0.88"
        />
        <path
          d="M225 276 Q300 296 320 274 M480 274 Q515 296 575 274"
          stroke={meta.pathColor}
          strokeWidth="16"
          strokeLinecap="round"
          fill="none"
          opacity="0.82"
        />

        {/* Two Private Coffee Booth Mats (Left & Right) */}
        <g>
          <rect x="178" y="254" width="76" height="38" rx="14" fill="#FAF6EB" opacity="0.72" stroke="#E0843B" strokeWidth="2.2" strokeDasharray="5 3" />
          <rect x="546" y="254" width="76" height="38" rx="14" fill="#FAF6EB" opacity="0.72" stroke="#E0843B" strokeWidth="2.2" strokeDasharray="5 3" />
        </g>

        {/* Warm Flat Sticker Campfire Glow */}
        {(islandMode === 'plaza' || placedFurniture.includes('campfire')) && (
          <motion.ellipse
            cx="400"
            cy="272"
            rx="72"
            ry="32"
            fill="#F4A261"
            opacity="0.22"
            animate={isPageVisible ? { opacity: [0.16, 0.28, 0.16], rx: [68, 76, 68] } : undefined}
            transition={{ duration: 1.6, repeat: Infinity, ease: 'easeInOut' }}
          />
        )}

        {/* 5. Country-Specific Architectural Landmarks & Lush Trees */}
        {theme === 'chengdu' && (
          <g>
            {/* Emerald Bamboo Groves */}
            <g stroke="#2D6A4F" strokeWidth="5.5" strokeLinecap="round">
              <line x1="252" y1="215" x2="246" y2="148" />
              <line x1="266" y1="218" x2="270" y2="156" />
              <line x1="538" y1="215" x2="544" y2="148" />
              <line x1="552" y1="218" x2="548" y2="160" />
            </g>
            {/* Flying-Eaves Chinese Tea Pavilion */}
            <g transform="translate(348, 128)">
              <ellipse cx="52" cy="78" rx="44" ry="10" fill="#1F1A17" opacity="0.2" />
              <rect x="18" y="40" width="8" height="36" fill="#B5382A" stroke="#4A4238" strokeWidth="2" />
              <rect x="78" y="40" width="8" height="36" fill="#B5382A" stroke="#4A4238" strokeWidth="2" />
              <path d="M2 42 Q52 8 102 42 L86 44 Q52 24 18 44 Z" fill="#2D6A4F" stroke="#4A4238" strokeWidth="2.5" strokeLinejoin="round" />
              <circle cx="52" cy="18" r="4" fill="#F4A261" stroke="#4A4238" strokeWidth="1.5" />
            </g>
            <LushTree x={165} y={142} scale={0.95} leafMain="#52B788" leafLight="#8FD694" leafDark="#2D6A4F" fruitColor="#E76F51" />
            <LushTree x={570} y={148} scale={0.92} leafMain="#6BCB77" leafLight="#A5E887" leafDark="#3D8B40" fruitColor="#F4A261" />
          </g>
        )}

        {theme === 'tokyo' && (
          <g>
            {/* Detailed Red Torii Gate */}
            <g transform="translate(356, 124)">
              <ellipse cx="44" cy="74" rx="38" ry="9" fill="#14132E" opacity="0.3" />
              <rect x="20" y="24" width="9" height="48" fill="#E63946" stroke="#4A4238" strokeWidth="2" />
              <rect x="59" y="24" width="9" height="48" fill="#E63946" stroke="#4A4238" strokeWidth="2" />
              <rect x="12" y="34" width="64" height="7" rx="2" fill="#E63946" stroke="#4A4238" strokeWidth="2" />
              <path d="M4 18 Q44 10 84 18 L80 26 Q44 20 8 26 Z" fill="#E63946" stroke="#4A4238" strokeWidth="2.2" />
            </g>
            <LushTree x={165} y={142} scale={0.96} leafMain="#FF9EAA" leafLight="#FFD6E0" leafDark="#D96B84" />
            <LushTree x={570} y={148} scale={0.92} leafMain="#FFB7C5" leafLight="#FFE3E8" leafDark="#D96B84" />
          </g>
        )}

        {theme === 'dubai' && (
          <g>
            {/* Oasis Lagoon Pool */}
            <ellipse cx="482" cy="306" rx="44" ry="18" fill="#48A9B8" stroke="#FAF6EB" strokeWidth="2.5" />
            <ellipse cx="476" cy="303" rx="22" ry="7" fill="#FFFFFF" opacity="0.28" />
            {/* Curved Palm Trees */}
            <g transform="translate(182, 146)">
              <ellipse cx="26" cy="86" rx="24" ry="8" fill="#1F1A17" opacity="0.18" />
              <path d="M22 86 Q28 50 16 18" stroke="#8D5B4C" strokeWidth="8" strokeLinecap="round" fill="none" />
              <path d="M16 18 Q-12 8 -18 28" stroke="#52B788" strokeWidth="7" strokeLinecap="round" fill="none" />
              <path d="M16 18 Q40 4 50 26" stroke="#52B788" strokeWidth="7" strokeLinecap="round" fill="none" />
              <path d="M16 18 Q16 -4 36 4" stroke="#6BCB77" strokeWidth="6" strokeLinecap="round" fill="none" />
            </g>
            <g transform="translate(572, 150)">
              <ellipse cx="26" cy="86" rx="24" ry="8" fill="#1F1A17" opacity="0.18" />
              <path d="M22 86 Q16 50 28 18" stroke="#8D5B4C" strokeWidth="8" strokeLinecap="round" fill="none" />
              <path d="M28 18 Q0 8 -8 28" stroke="#52B788" strokeWidth="7" strokeLinecap="round" fill="none" />
              <path d="M28 18 Q52 4 60 26" stroke="#52B788" strokeWidth="7" strokeLinecap="round" fill="none" />
            </g>
          </g>
        )}

        {theme === 'paris' && (
          <g>
            {/* Vintage Iron Streetlamp */}
            <g transform="translate(268, 168)">
              <rect x="8" y="18" width="5" height="44" fill="#233142" />
              <circle cx="10.5" cy="14" r="9" fill="#FFF3B0" stroke="#233142" strokeWidth="2" />
              <circle cx="10.5" cy="14" r="18" fill="#FFF3B0" opacity="0.22" />
            </g>
            {/* Red Bistro Café Awning */}
            <g transform="translate(465, 165)">
              <rect x="6" y="24" width="66" height="32" rx="4" fill="#FAF6EB" stroke="#4A4238" strokeWidth="2.5" />
              <path d="M0 26 L10 10 H68 L78 26 Z" fill="#E63946" stroke="#4A4238" strokeWidth="2.5" />
              <line x1="20" y1="10" x2="16" y2="26" stroke="#FAF6EB" strokeWidth="4" />
              <line x1="40" y1="10" x2="40" y2="26" stroke="#FAF6EB" strokeWidth="4" />
              <line x1="58" y1="10" x2="62" y2="26" stroke="#FAF6EB" strokeWidth="4" />
            </g>
            <LushTree x={165} y={142} scale={0.92} leafMain="#6B8E6E" leafLight="#95B898" leafDark="#446347" />
          </g>
        )}

        {theme === 'reykjavik' && (
          <g>
            <LushTree x={165} y={142} scale={0.94} leafMain="#CBE4EA" leafLight="#FFFFFF" leafDark="#8FB8C7" />
            <LushTree x={570} y={148} scale={0.92} leafMain="#D8EEF5" leafLight="#FFFFFF" leafDark="#9BC2D1" />
          </g>
        )}

        {/* Dynamic Atmospheric Particles (<= 24 total, paused when tab hidden) */}
        {isPageVisible &&
          (theme === 'chengdu' || theme === 'tokyo') &&
          [
            [150, 42],
            [290, 56],
            [465, 32],
            [620, 48],
          ].map(([px, py], i) => (
            <motion.ellipse
              key={i}
              cx={px}
              cy={py}
              rx="5"
              ry="2.6"
              fill={theme === 'tokyo' ? '#FF9EAA' : '#52B788'}
              animate={{ y: [0, 145], x: [0, 26, -12], rotate: [0, 180] }}
              transition={{ duration: 4.5 + i * 0.7, repeat: Infinity, ease: 'linear' }}
            />
          ))}

        {isPageVisible &&
          theme === 'paris' &&
          [130, 230, 340, 470, 580, 670].map((rx, i) => (
            <motion.line
              key={i}
              x1={rx}
              y1={24 + (i % 3) * 18}
              x2={rx - 10}
              y2={48 + (i % 3) * 18}
              stroke="#BDE8F5"
              strokeWidth="2"
              strokeLinecap="round"
              opacity="0.55"
              animate={{ y: [0, 140], x: [0, -22] }}
              transition={{ duration: 1.4 + (i % 3) * 0.25, repeat: Infinity, ease: 'linear' }}
            />
          ))}

        {isPageVisible &&
          theme === 'reykjavik' &&
          [130, 250, 380, 510, 640].map((sx, i) => (
            <motion.circle
              key={i}
              cx={sx}
              cy={26 + (i % 2) * 18}
              r="3"
              fill="#FFFFFF"
              opacity="0.85"
              animate={{ y: [0, 155], x: [-8, 8, -8] }}
              transition={{ duration: 4.5 + i * 0.4, repeat: Infinity, ease: 'linear' }}
            />
          ))}

        {/* Clickable Campfire Log Benches */}
        <g
          transform="translate(318, 264)"
          onClick={(e) => handleSitOnBench('left', e)}
          className="cursor-pointer hover:opacity-90"
        >
          <ellipse cx="19" cy="18" rx="20" ry="5" fill="#1F1A17" opacity="0.2" />
          <rect x="0" y="6" width="38" height="12" rx="6" fill="#C98A5B" stroke="#4A4238" strokeWidth="2.5" />
          <ellipse cx="4" cy="12" rx="3" ry="5" fill="#E9C46A" stroke="#4A4238" strokeWidth="1.8" />
        </g>
        <g
          transform="translate(444, 264)"
          onClick={(e) => handleSitOnBench('right', e)}
          className="cursor-pointer hover:opacity-90"
        >
          <ellipse cx="19" cy="18" rx="20" ry="5" fill="#1F1A17" opacity="0.2" />
          <rect x="0" y="6" width="38" height="12" rx="6" fill="#C98A5B" stroke="#4A4238" strokeWidth="2.5" />
          <ellipse cx="34" cy="12" rx="3" ry="5" fill="#E9C46A" stroke="#4A4238" strokeWidth="1.8" />
        </g>

        {/* Central Campfire */}
        {(islandMode === 'plaza' || placedFurniture.includes('campfire')) && (
          <g transform="translate(382, 244)">
            <ellipse cx="18" cy="36" rx="22" ry="8" fill="#1F1A17" opacity="0.22" />
            <rect x="4" y="28" width="28" height="8" rx="3" fill="#8D5B4C" stroke="#4A4238" strokeWidth="2" />
            <motion.path
              d="M18 4 C28 16, 28 28, 18 30 C8 28, 8 16, 18 4 Z"
              fill="#F4A261"
              stroke="#4A4238"
              strokeWidth="2.5"
              animate={isPageVisible ? { scaleY: [1, 1.12, 0.96, 1] } : undefined}
              transition={{ duration: 0.9, repeat: Infinity }}
              style={{ transformOrigin: '18px 30px' }}
            />
            <path d="M18 14 C23 20, 23 27, 18 28 C13 27, 13 20, 18 14 Z" fill="#FFF3B0" />
          </g>
        )}

        {/* DIY Placed Furniture Props */}
        {placedFurniture.includes('ramenStall') && (
          <g transform="translate(345, 162)">
            <rect x="8" y="30" width="96" height="44" rx="6" fill="#C98A5B" stroke="#4A4238" strokeWidth="3" />
            <path d="M0 32 L12 12 H100 L112 32 Z" fill="#E76F51" stroke="#4A4238" strokeWidth="3" />
            <circle cx="8" cy="42" r="7" fill="#FFF3B0" stroke="#4A4238" strokeWidth="2" />
            <circle cx="104" cy="42" r="7" fill="#FFF3B0" stroke="#4A4238" strokeWidth="2" />
            <text x="56" y="27" textAnchor="middle" fontSize="11" fontWeight="900" fill="#FAF6EB">
              ラーメン
            </text>
          </g>
        )}

        {placedFurniture.includes('sakuraTree') && (
          <LushTree x={456} y={145} scale={0.78} leafMain="#FF9EAA" leafLight="#FFD6E0" leafDark="#D96B84" />
        )}

        {placedFurniture.includes('cafeSet') && (
          <g transform="translate(268, 224)">
            <ellipse cx="24" cy="36" rx="18" ry="6" fill="#1F1A17" opacity="0.2" />
            <circle cx="24" cy="24" r="16" fill="#FAF6EB" stroke="#4A4238" strokeWidth="2.5" />
            <rect x="16" y="18" width="16" height="10" rx="3" fill="#8D5B4C" />
            <circle cx="24" cy="23" r="4" fill="#FAF6EB" />
          </g>
        )}

        {placedFurniture.includes('bambooTea') && (
          <g transform="translate(472, 232)">
            <ellipse cx="23" cy="34" rx="20" ry="6" fill="#1F1A17" opacity="0.18" />
            <rect x="4" y="16" width="38" height="18" rx="6" fill="#90BE6D" stroke="#4A4238" strokeWidth="2.5" />
            <circle cx="18" cy="18" r="5" fill="#FAF6EB" stroke="#4A4238" strokeWidth="2" />
            <circle cx="30" cy="18" r="5" fill="#FAF6EB" stroke="#4A4238" strokeWidth="2" />
          </g>
        )}

        {placedFurniture.includes('tent') && (
          <g transform="translate(274, 174)">
            <ellipse cx="28" cy="48" rx="24" ry="7" fill="#1F1A17" opacity="0.2" />
            <path d="M4 46 L28 10 L52 46 Z" fill="#F4A261" stroke="#4A4238" strokeWidth="3" strokeLinejoin="round" />
            <path d="M22 46 L28 28 L34 46 Z" fill="#4A4238" />
          </g>
        )}

        {placedFurniture.includes('lanterns') && (
          <g transform="translate(310, 146)">
            <path d="M0 10 Q90 26 180 10" stroke="#4A4238" strokeWidth="2.5" fill="none" />
            {[25, 70, 115, 155].map((lx, i) => (
              <circle
                key={i}
                cx={lx}
                cy={16 + (i === 1 || i === 2 ? 4 : 0)}
                r="7"
                fill={i % 2 === 0 ? '#FFE66D' : '#F28482'}
                stroke="#4A4238"
                strokeWidth="2"
              />
            ))}
          </g>
        )}

        {(placedFurniture.includes('onsen') || theme === 'reykjavik') && (
          <g transform="translate(495, 272)">
            <ellipse cx="26" cy="22" rx="30" ry="16" fill="#1F1A17" opacity="0.2" />
            <ellipse cx="26" cy="20" rx="28" ry="15" fill="#8D5B4C" stroke="#4A4238" strokeWidth="2.8" />
            <ellipse cx="26" cy="19" rx="21" ry="10" fill="#63C5B8" />
            <motion.path
              d="M18 14 Q20 7 18 2 M28 12 Q30 5 28 0 M36 14 Q38 7 36 2"
              stroke="#FFFFFF"
              strokeWidth="2.2"
              strokeLinecap="round"
              fill="none"
              animate={isPageVisible ? { y: [-2, 2, -2], opacity: [0.4, 0.9, 0.4] } : undefined}
              transition={{ duration: 2.2, repeat: Infinity }}
            />
          </g>
        )}

        {/* Wooden Pier + Seaplane Hotspot (Clean icon, no text badge) */}
        <g
          onClick={(e) => {
            e.stopPropagation();
            onOpenDodo();
          }}
          transform="translate(86, -6)"
          className="cursor-pointer"
        >
          <rect x="96" y="296" width="86" height="24" rx="6" fill="#C98A5B" stroke="#4A4238" strokeWidth="3" />
          <motion.g
            animate={isPageVisible ? { y: [-3, 3, -3] } : undefined}
            transition={{ duration: 2.8, repeat: Infinity, ease: 'easeInOut' }}
          >
            <ellipse cx="86" cy="348" rx="44" ry="11" fill="#4A4238" opacity="0.18" />
            <path
              d="M42 330 C42 318, 98 314, 116 328 C120 332, 114 342, 98 342 H52 C44 342, 42 336, 42 330 Z"
              fill="#F4A261"
              stroke="#4A4238"
              strokeWidth="3"
            />
            <path d="M58 319 L72 308 H94 L100 320 Z" fill="#FAF6EB" stroke="#4A4238" strokeWidth="2.5" />
            <rect x="68" y="342" width="30" height="7" rx="3" fill="#78C2AD" stroke="#4A4238" strokeWidth="2" />
          </motion.g>
        </g>

        {/* Beach Message Bottle Hotspot (Clean icon, no text badge) */}
        <g
          onClick={(e) => {
            e.stopPropagation();
            onOpenBottle();
          }}
          transform="translate(618, 352) scale(0.84)"
          className="cursor-pointer"
        >
          <motion.g
            animate={isPageVisible ? { y: [-4, 4, -4], rotate: [-4, 4, -4] } : undefined}
            transition={{ duration: 3.2, repeat: Infinity, ease: 'easeInOut' }}
            style={{ transformOrigin: '30px 25px' }}
          >
            <ellipse cx="32" cy="38" rx="24" ry="7" fill="#FFFFFF" opacity="0.4" />
            <rect
              x="20"
              y="8"
              width="22"
              height="30"
              rx="8"
              transform="rotate(24 31 23)"
              fill="#BDE8F5"
              stroke="#4A4238"
              strokeWidth="3"
            />
            <rect
              x="32"
              y="0"
              width="9"
              height="8"
              rx="2"
              transform="rotate(24 36 4)"
              fill="#D4A373"
              stroke="#4A4238"
              strokeWidth="2.5"
            />
          </motion.g>
        </g>
      </svg>

      {/* Grass Walk Ripple */}
      <AnimatePresence>
        {walkRipple && (
          <motion.div
            key={walkRipple.key}
            initial={{ scale: 0.3, opacity: 0.9 }}
            animate={{ scale: 1.9, opacity: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.55 }}
            style={{ left: `${walkRipple.xPct}%`, top: `${walkRipple.yPct}%` }}
            className="absolute -translate-x-1/2 -translate-y-1/2 w-10 h-6 rounded-full border-2 border-cream pointer-events-none z-10"
          />
        )}
      </AnimatePresence>

      {/* Interactive Residents Overlay */}
      {islanders.slice(0, 4).map((resident, idx) => {
        const defaultPos = RESIDENT_POS_BY_ID[resident.id] ?? { xPct: 50, yPct: 50 };
        const pos = groupReaction ? GATHER_POSITIONS[idx] : defaultPos;
        const reactionToShow =
          groupReaction?.type || (activeReaction?.targetId === resident.id ? activeReaction.type : null);
        const bubble = islandBubbles[resident.id];
        const hasEvent = residentEvent?.residentId === resident.id;

        return (
          <motion.button
            key={resident.id}
            type="button"
            onClick={(e) => handleSelectResident(resident, e)}
            animate={{
              left: `${pos.xPct}%`,
              top: `${pos.yPct}%`,
              y: reactionToShow ? [0, -14, 0, -8, 0] : [0, -2, 0],
            }}
            transition={{
              left: { type: 'spring', stiffness: 120, damping: 16 },
              top: { type: 'spring', stiffness: 120, damping: 16 },
              y: reactionToShow
                ? { duration: 0.7 }
                : { duration: 2.8 + idx * 0.4, repeat: Infinity, ease: 'easeInOut' },
            }}
            className="absolute -translate-x-1/2 -translate-y-1/2 z-10 flex flex-col items-center group cursor-pointer focus:outline-none"
          >
            {hasEvent && !bubble && (
              <motion.div
                animate={{ y: [0, -6, 0], scale: [1, 1.15, 1] }}
                transition={{ duration: 0.75, repeat: Infinity }}
                className="mb-1 w-6 h-6 rounded-full bg-coral border-2 border-espresso shadow-nook-sm flex items-center justify-center text-xs font-black text-espresso"
              >
                !
              </motion.div>
            )}

            <AnimatePresence>
              {bubble && (
                <OverheadBubble
                  primary={bubble.primary}
                  secondary={bubble.secondary}
                  onSpeak={bubble.onSpeak}
                />
              )}
            </AnimatePresence>

            {reactionToShow && (
              <motion.span
                key={`${resident.id}-${groupReaction?.key || activeReaction?.key}`}
                initial={{ opacity: 0, y: 8, scale: 0.6 }}
                animate={{ opacity: [0, 1, 0], y: -24, scale: 1.2 }}
                transition={{ duration: 1.2 }}
                className="text-xl pointer-events-none absolute -top-5"
              >
                {REACTION_EMOJI[reactionToShow]}
              </motion.span>
            )}

            <div className="group-hover:scale-110 transition-transform">
              <AnimalAvatar
                species={resident.species}
                color={resident.color}
                avatarStyle={resident.avatarStyle}
                size={54}
                fullBody
              />
            </div>

            <span className="-mt-1 px-2 py-0.5 rounded-full bg-cream/90 backdrop-blur-sm border border-espresso text-[9.5px] font-black text-espresso whitespace-nowrap shadow-nook-sm">
              {resident.countryFlag} {resident.name.split(' ')[0]}
            </span>
          </motion.button>
        );
      })}

      {/* Player Avatar */}
      <motion.div
        animate={{
          left: `${playerPos.xPct}%`,
          top: `${playerPos.yPct}%`,
          y: isSeated ? [0, -2, 0] : [0, -2, 0],
        }}
        transition={{
          left: { type: 'spring', stiffness: 120, damping: 16 },
          top: { type: 'spring', stiffness: 120, damping: 16 },
          y: { duration: 2.6, repeat: Infinity, ease: 'easeInOut' },
        }}
        className="absolute -translate-x-1/2 -translate-y-1/2 z-20 flex flex-col items-center pointer-events-none"
      >
        <AnimatePresence>
          {isVoiceActive && (interimOriginal || interimTranslated) ? (
            <OverheadBubble
              primary={interimTranslated || interimOriginal}
              secondary={interimTranslated ? interimOriginal : undefined}
              dashed
            />
          ) : islandBubbles[player.id] ? (
            <OverheadBubble
              primary={islandBubbles[player.id].primary}
              secondary={islandBubbles[player.id].secondary}
              onSpeak={islandBubbles[player.id].onSpeak}
            />
          ) : null}
        </AnimatePresence>

        <div className="relative flex items-center justify-center">
          <div className="absolute -bottom-1 w-14 h-5 rounded-full border border-mint/60 bg-mint/10 pointer-events-none" />
          {isVoiceActive && (
            <>
              <motion.div
                animate={{
                  scale: 1 + (micVolume / 100) * 0.95,
                  opacity: Math.max(0.25, micVolume / 120),
                }}
                transition={{ duration: 0.12 }}
                className="absolute w-14 h-14 rounded-full border-[3px] border-coral bg-coral/25"
              />
              <motion.div
                animate={{
                  scale: 1.2 + (micVolume / 100) * 1.25,
                  opacity: Math.max(0.15, micVolume / 160),
                }}
                transition={{ duration: 0.15 }}
                className="absolute w-14 h-14 rounded-full border-2 border-mint bg-mint/15"
              />
            </>
          )}

          {(groupReaction || activeReaction?.targetId === player.id) && (
            <motion.span
              key={groupReaction?.key || activeReaction?.key}
              initial={{ opacity: 0, y: 8, scale: 0.6 }}
              animate={{ opacity: [0, 1, 0], y: -28, scale: 1.25 }}
              transition={{ duration: 1.2 }}
              className="text-xl absolute -top-6"
            >
              {REACTION_EMOJI[(groupReaction?.type || activeReaction?.type) as ReactionType]}
            </motion.span>
          )}

          <div className="relative z-10">
            <AnimalAvatar
              species={player.species}
              color={player.color}
              avatarStyle={player.avatarStyle}
              size={58}
              fullBody
              isWalking={isWalking}
            />
          </div>
        </div>

        <span className="-mt-1 px-2 py-0.5 rounded-full bg-coral text-espresso border-2 border-espresso text-[9.5px] font-black shadow-nook-sm whitespace-nowrap">
          {player.countryFlag} {player.name} {isSeated ? '🔥围炉' : '(我)'}
        </span>
      </motion.div>

      {/* Face-to-Face Islander Card OR '!' Sudden Event Card */}
      <AnimatePresence>
        {selectedResident && (
          <motion.div
            initial={{ opacity: 0, y: 12, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 12, scale: 0.95 }}
            className="absolute bottom-2.5 left-2.5 right-2.5 sm:left-auto sm:right-3 sm:w-80 z-30 bg-cream nook-card p-3"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2">
                <div className="p-1 rounded-xl bg-white border-2 border-espresso">
                  <AnimalAvatar
                    species={selectedResident.species}
                    color={selectedResident.color}
                    avatarStyle={selectedResident.avatarStyle}
                    size={36}
                  />
                </div>
                <div>
                  <div className="font-black text-xs sm:text-sm text-espresso">
                    {selectedResident.countryFlag} {selectedResident.name}
                  </div>
                  <div className="text-[10px] font-bold text-espresso-light">
                    {selectedResident.city} · 母语 {selectedResident.nativeLang.toUpperCase()}
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedResident(null)}
                className="w-6 h-6 rounded-full bg-white border border-espresso flex items-center justify-center"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            {residentEvent?.residentId === selectedResident.id ? (
              <div className="mt-2 p-2.5 rounded-2xl bg-coral/20 border-2 border-espresso space-y-2">
                <div className="text-xs font-black text-espresso">
                  ❗ 突发奇遇：{residentEvent.prompt}
                </div>
                <div className="flex flex-col gap-1.5">
                  {residentEvent.options.map((opt, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => {
                        onResolveResidentEvent(selectedResident, opt.reply, opt.reward);
                        setSelectedResident(null);
                      }}
                      className="w-full py-1.5 px-2.5 rounded-xl bg-white border-2 border-espresso text-left text-[11px] font-black text-espresso hover:bg-mint/30 transition-colors flex items-center justify-between"
                    >
                      <span>{opt.label}</span>
                      <span className="text-coral-dark">+{opt.reward} 里数</span>
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <>
                {selectedResident.persona && (
                  <p className="text-[11px] font-semibold text-espresso mt-1.5 leading-snug">
                    {selectedResident.persona}
                  </p>
                )}
                <div className="grid grid-cols-3 gap-1.5 mt-2.5">
                  <button
                    type="button"
                    onClick={() => {
                      onQuickGreet(selectedResident);
                      setSelectedResident(null);
                    }}
                    className="py-1.5 px-1 rounded-xl bg-mint text-espresso font-black text-[10px] nook-btn inline-flex items-center justify-center gap-1"
                  >
                    <MessageCircleHeart className="w-3 h-3 shrink-0" />
                    <span>打招呼</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onBuyCoffee(selectedResident);
                      setSelectedResident(null);
                    }}
                    className="py-1.5 px-1 rounded-xl bg-coral text-espresso font-black text-[10px] nook-btn inline-flex items-center justify-center gap-1"
                  >
                    <Coffee className="w-3 h-3 shrink-0" />
                    <span>请喝咖啡</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onDrawIcebreaker();
                      setSelectedResident(null);
                    }}
                    className="py-1.5 px-1 rounded-xl bg-white text-espresso font-black text-[10px] nook-btn inline-flex items-center justify-center gap-1"
                  >
                    <Dices className="w-3 h-3 shrink-0" />
                    <span>破冰话题</span>
                  </button>
                </div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
