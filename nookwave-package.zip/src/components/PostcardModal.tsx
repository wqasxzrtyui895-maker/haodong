import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { Download, X } from 'lucide-react';
import {
  downloadPostcardPng,
  PostcardPayload,
  renderPostcardDataUrl,
} from '../utils/postcardCanvas';

interface PostcardModalProps {
  payload: PostcardPayload;
  onClose: () => void;
}

export const PostcardModal: React.FC<PostcardModalProps> = ({ payload, onClose }) => {
  const dataUrl = useMemo(() => renderPostcardDataUrl(payload), [payload]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-espresso/60 backdrop-blur-sm p-4">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-full max-w-2xl bg-cream nook-card overflow-hidden"
      >
        <div className="bg-coral px-5 py-3 border-b-[3px] border-espresso flex items-center justify-between">
          <div className="font-black text-espresso text-base">
            📮 复古双语纪念明信片预览
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-cream border-2 border-espresso flex items-center justify-center hover:bg-cream-dark"
          >
            <X className="w-4 h-4 text-espresso" />
          </button>
        </div>

        <div className="p-4 sm:p-5 space-y-4">
          {dataUrl && (
            <div className="rounded-2xl overflow-hidden border-2 border-espresso shadow-nook-sm bg-white">
              <img
                src={dataUrl}
                alt="NookWave Bilingual Postcard"
                className="w-full h-auto block"
              />
            </div>
          )}

          <div className="flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-white text-espresso font-bold text-sm border-2 border-espresso"
            >
              关闭
            </button>
            <button
              type="button"
              onClick={() => downloadPostcardPng(dataUrl, `nookwave-postcard-${Date.now()}.png`)}
              className="px-5 py-2.5 rounded-xl bg-mint text-espresso font-black text-sm nook-btn inline-flex items-center gap-2"
            >
              <Download className="w-4 h-4" />
              一键下载高清 PNG 明信片
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
