import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ChevronUp,
  Dices,
  Image as ImageIcon,
  Lightbulb,
  Mic,
  RefreshCw,
  Send,
  Sparkles,
  Volume2,
  X,
} from 'lucide-react';
import {
  ChatMessage,
  IslanderProfile,
  LanguageCode,
  NookQuest,
  ReactionType,
  VoiceOutputMode,
} from '../types/island';
import { AnimalAvatar } from './AnimalAvatar';
import { PostcardPayload } from '../utils/postcardCanvas';

interface ChatPanelProps {
  messages: ChatMessage[];
  player: IslanderProfile;
  targetLang: LanguageCode;
  onChangeTargetLang: (lang: LanguageCode) => void;
  roomCode: string;
  voiceMode: VoiceOutputMode;
  isRecording: boolean;
  isDemoRunning: boolean;
  micVolume: number;
  onToggleMic: () => void;
  onStartHoldMic: () => void;
  onStopHoldMic: () => void;
  onRunDemo: () => void;
  onToggleVoiceMode: () => void;
  onSendMessage: (text: string) => Promise<void>;
  onRetryTranslate: (msg: ChatMessage) => void;
  onDrawIcebreaker: () => void;
  onTriggerReaction: (reaction: ReactionType) => void;
  onReplayAudio: (msg: ChatMessage) => void;
  onExportPostcard: (payload: PostcardPayload) => void;
  quests: NookQuest[];
  onClickQuest: (quest: NookQuest) => void;
}

const REACTIONS: Array<{ type: ReactionType; emoji: string; label: string }> = [
  { type: 'clap', emoji: '👏', label: '鼓掌' },
  { type: 'flower', emoji: '🌸', label: '冒花花' },
  { type: 'coffee', emoji: '☕', label: '递咖啡' },
  { type: 'firework', emoji: '🎉', label: '放烟花' },
  { type: 'shock', emoji: '😲', label: '震惊' },
  { type: 'dance', emoji: '💃', label: '摇摆' },
];

const TARGET_LANGS: Array<{ code: LanguageCode; label: string }> = [
  { code: 'ja', label: '🇯🇵 日语' },
  { code: 'en', label: '🇬🇧 英语' },
  { code: 'ko', label: '🇰🇷 韩语' },
  { code: 'fr', label: '🇫🇷 法语' },
  { code: 'ar', label: '🇦🇪 阿语' },
  { code: 'es', label: '🇪🇸 西语' },
  { code: 'zh', label: '🇨🇳 中文' },
];

export const ChatPanel: React.FC<ChatPanelProps> = ({
  messages,
  player,
  targetLang,
  onChangeTargetLang,
  roomCode,
  voiceMode,
  isRecording,
  isDemoRunning,
  micVolume,
  onToggleMic,
  onStartHoldMic,
  onStopHoldMic,
  onRunDemo,
  onToggleVoiceMode,
  onSendMessage,
  onRetryTranslate,
  onDrawIcebreaker,
  onTriggerReaction,
  onReplayAudio,
  onExportPostcard,
  quests,
  onClickQuest,
}) => {
  const [input, setInput] = useState('');
  const [showHistory, setShowHistory] = useState(false);
  const [showReactions, setShowReactions] = useState(false);
  const [expandedTips, setExpandedTips] = useState<Record<string, boolean>>({});
  const [sending, setSending] = useState(false);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const holdTimerRef = useRef<number | null>(null);
  const heldRef = useRef(false);

  useEffect(() => {
    if (showHistory && scrollRef.current) {
      scrollRef.current.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: 'smooth',
      });
    }
  }, [messages, showHistory]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || sending) return;
    const text = input.trim();
    setInput('');
    setSending(true);
    await onSendMessage(text);
    setSending(false);
  };

  const toggleTip = (id: string) => {
    setExpandedTips((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // Pointer handlers supporting both Click-to-Toggle and Hold-to-Talk (PTT)
  const handleMicPointerDown = () => {
    if (isDemoRunning) return;
    heldRef.current = false;
    holdTimerRef.current = window.setTimeout(() => {
      heldRef.current = true;
      if (!isRecording) {
        onStartHoldMic();
      }
    }, 260);
  };

  const handleMicPointerUp = () => {
    if (holdTimerRef.current) {
      window.clearTimeout(holdTimerRef.current);
      holdTimerRef.current = null;
    }
    if (heldRef.current) {
      heldRef.current = false;
      if (isRecording) onStopHoldMic();
    } else {
      onToggleMic();
    }
  };

  const latestMsg = messages[messages.length - 1];
  const active = isRecording || isDemoRunning;
  const ringScale = 1 + (micVolume / 100) * 0.16;

  return (
    <div className="relative flex flex-col justify-end bg-cream nook-card overflow-visible shrink-0">
      {/* Slim Stamp Quest Strip */}
      <div className="px-2.5 py-1 bg-mint/15 border-b-2 border-espresso/15 rounded-t-[1.35rem] flex items-center gap-1.5 overflow-x-auto no-scrollbar">
        <span className="text-[10px] font-black text-espresso shrink-0">🎫集章:</span>
        {quests.map((q) => (
          <button
            key={q.id}
            type="button"
            onClick={() => onClickQuest(q)}
            className={`px-2 py-0.5 rounded-full border text-[10px] font-black whitespace-nowrap shrink-0 transition-all ${
              q.completed
                ? 'bg-coral/25 border-coral-dark text-espresso'
                : 'bg-white border-espresso/35 text-espresso hover:border-espresso'
            }`}
          >
            {q.emoji} {q.label} +{q.reward}
            {q.completed && (
              <span className="ml-1 px-1 rounded bg-red-500 text-white text-[9px]">已达成</span>
            )}
          </button>
        ))}
      </div>

      {/* Single-Line Latest Subtitle Preview Bar (Click to pull up History Drawer) */}
      <div
        onClick={() => setShowHistory(true)}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') setShowHistory(true);
        }}
        className="px-3 py-2 bg-white/85 border-b-2 border-espresso/15 flex items-center justify-between gap-2 cursor-pointer hover:bg-cream-dark/40 transition-colors"
      >
        {latestMsg ? (
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <div className="w-6 h-6 rounded-full bg-cream border border-espresso flex items-center justify-center shrink-0 overflow-hidden">
              <AnimalAvatar
                species={latestMsg.sender.species}
                color={latestMsg.sender.color}
                avatarStyle={latestMsg.sender.avatarStyle}
                size={22}
              />
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-xs font-black text-espresso truncate">
                {latestMsg.sender.countryFlag} {latestMsg.sender.name.split(' ')[0]}：
                <span className="font-bold ml-1">{latestMsg.translatedText}</span>
              </div>
              <div className="text-[10px] font-semibold text-espresso-light truncate">
                {latestMsg.originalText}
              </div>
            </div>
          </div>
        ) : (
          <span className="text-xs font-bold text-espresso-light">
            📻 点击展开双语电波历史记录...
          </span>
        )}

        <div className="flex items-center gap-1 shrink-0">
          {latestMsg && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onReplayAudio(latestMsg);
              }}
              className="w-7 h-7 rounded-full bg-cream border border-espresso flex items-center justify-center hover:bg-coral/30"
              title="朗读本句"
            >
              <Volume2 className="w-3.5 h-3.5 text-espresso" />
            </button>
          )}
          <span className="inline-flex items-center gap-0.5 px-2 py-1 rounded-full bg-cream-dark border border-espresso/40 text-[10px] font-black text-espresso">
            <ChevronUp className="w-3 h-3" />
            记录({messages.length})
          </span>
        </div>
      </div>

      {/* Pop-up 6-Emoji Reactions Wheel */}
      <AnimatePresence>
        {showReactions && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.92 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.92 }}
            className="absolute bottom-14 left-3 right-3 sm:left-auto sm:right-16 sm:w-72 z-30 p-2 bg-cream nook-card grid grid-cols-6 gap-1.5"
          >
            {REACTIONS.map((r) => (
              <button
                key={r.type}
                type="button"
                onClick={() => {
                  onTriggerReaction(r.type);
                  setShowReactions(false);
                }}
                title={r.label}
                className="h-9 rounded-full bg-white border-2 border-espresso/40 hover:border-espresso hover:bg-coral/30 text-base flex items-center justify-center active:scale-95 transition-all"
              >
                {r.emoji}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Single-Row Compact Bottom Control Dock */}
      <div className="px-2.5 py-2 bg-cream-dark/65 rounded-b-[1.35rem] safe-bottom flex items-center gap-1.5">
        {/* [🐚 Hold/Click to Speak] */}
        <motion.button
          type="button"
          animate={active ? { scale: ringScale } : { scale: 1 }}
          onPointerDown={handleMicPointerDown}
          onPointerUp={handleMicPointerUp}
          disabled={isDemoRunning}
          title="按住说话 / 点击开麦实时翻译"
          className={`h-9 px-2.5 rounded-full border-2 border-espresso shadow-nook-sm inline-flex items-center gap-1 text-[11px] font-black whitespace-nowrap shrink-0 transition-colors ${
            active ? 'bg-coral text-espresso' : 'bg-mint text-espresso hover:bg-mint-dark'
          } disabled:opacity-60`}
        >
          <svg width="15" height="15" viewBox="0 0 64 64" fill="none" className="shrink-0">
            <path
              d="M32 10 C15 10, 6 24, 10 38 C12 45, 20 50, 24 52 L24 56 H40 L40 52 C44 50, 52 45, 54 38 C58 24, 49 10, 32 10 Z"
              fill="#FAF6EB"
              stroke="#4A4238"
              strokeWidth="5"
              strokeLinejoin="round"
            />
            <circle cx="32" cy="31" r="5" fill={active ? '#F4A261' : '#78C2AD'} />
          </svg>
          <span className="hidden sm:inline">{isRecording ? '松开发送' : '按住开麦'}</span>
        </motion.button>

        {/* Mini [🎙️ 演示] */}
        <button
          type="button"
          onClick={onRunDemo}
          disabled={isDemoRunning || isRecording}
          title="无麦克风一键模拟开麦演示"
          className="h-9 px-2 rounded-full bg-white border-2 border-espresso text-[11px] font-black text-espresso whitespace-nowrap shrink-0 inline-flex items-center gap-1 hover:bg-coral/30 disabled:opacity-50"
        >
          <Mic className="w-3.5 h-3.5 text-coral-dark" />
          <span>{isDemoRunning ? '演示中' : '演示'}</span>
        </button>

        {/* [✨ 表情] */}
        <button
          type="button"
          onClick={() => setShowReactions((v) => !v)}
          title="打开表情动作轮盘"
          className={`h-9 w-9 rounded-full border-2 border-espresso flex items-center justify-center shrink-0 transition-colors ${
            showReactions ? 'bg-coral text-espresso' : 'bg-white text-espresso hover:bg-cream-dark'
          }`}
        >
          <Sparkles className="w-4 h-4" />
        </button>

        {/* [输入框] + [发送] */}
        <form onSubmit={handleSubmit} className="flex-1 min-w-0 flex items-center gap-1.5">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="输入中文或任意语言..."
            className="flex-1 min-w-0 h-9 px-3 rounded-full bg-white border-2 border-espresso text-xs sm:text-sm font-bold text-espresso focus:outline-none focus:ring-2 focus:ring-mint"
          />
          <button
            type="submit"
            disabled={sending || !input.trim()}
            className="w-9 h-9 rounded-full bg-coral text-espresso nook-btn flex items-center justify-center shrink-0 disabled:opacity-50"
            aria-label="发送消息"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>

      {/* Pull-Up Full Bilingual History Drawer */}
      <AnimatePresence>
        {showHistory && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-espresso/50 backdrop-blur-sm sm:p-4">
            <motion.div
              initial={{ y: 40, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 40, opacity: 0 }}
              className="w-full max-w-xl h-[82dvh] sm:h-[78dvh] bg-cream nook-card rounded-b-none sm:rounded-3xl overflow-hidden flex flex-col"
            >
              {/* Drawer Header */}
              <div className="px-4 py-3 bg-cream-dark/80 border-b-[3px] border-espresso flex items-center justify-between gap-2 shrink-0">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-black text-espresso">📻 双语电波历史</span>
                  <button
                    type="button"
                    onClick={onDrawIcebreaker}
                    className="px-2.5 py-1 rounded-full bg-coral text-espresso border-2 border-espresso text-[10.5px] font-black inline-flex items-center gap-1"
                  >
                    <Dices className="w-3 h-3" />
                    <span>破冰签</span>
                  </button>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={onToggleVoiceMode}
                    className="px-2 py-1 rounded-full bg-white border-2 border-espresso text-[10px] font-black text-espresso"
                    title="切换语音播报模式"
                  >
                    {voiceMode === 'animalese' ? '🔊 电波萌音' : '🗣️ 外语TTS'}
                  </button>
                  <select
                    value={targetLang}
                    onChange={(e) => onChangeTargetLang(e.target.value as LanguageCode)}
                    className="px-2 py-1 rounded-xl bg-white border-2 border-espresso text-[11px] font-black text-espresso focus:outline-none"
                  >
                    {TARGET_LANGS.map((l) => (
                      <option key={l.code} value={l.code}>
                        {l.label}
                      </option>
                    ))}
                  </select>
                  <button
                    type="button"
                    onClick={() => setShowHistory(false)}
                    className="w-7 h-7 rounded-full bg-white border-2 border-espresso flex items-center justify-center"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Messages Feed */}
              <div ref={scrollRef} className="flex-1 overflow-y-auto nook-scroll p-3.5 space-y-3">
                {messages.map((msg) => {
                  const isSelf = msg.sender.id === player.id;
                  const tipOpen = Boolean(expandedTips[msg.id]);

                  return (
                    <div
                      key={msg.id}
                      className={`flex gap-2.5 ${isSelf ? 'flex-row-reverse' : 'flex-row'}`}
                    >
                      <div className="shrink-0 mt-1">
                        <div className="p-0.5 rounded-full bg-white border-2 border-espresso">
                          <AnimalAvatar
                            species={msg.sender.species}
                            color={msg.sender.color}
                            avatarStyle={msg.sender.avatarStyle}
                            size={32}
                          />
                        </div>
                      </div>

                      <div
                        className={`max-w-[84%] flex flex-col ${
                          isSelf ? 'items-end' : 'items-start'
                        }`}
                      >
                        <div className="text-[11px] font-black text-espresso mb-0.5 px-1">
                          {msg.sender.countryFlag} {msg.sender.name} ·{' '}
                          <span className="text-espresso-light font-bold">
                            {msg.sender.city.split('·')[0].trim()}
                          </span>
                        </div>

                        <div
                          className={`rounded-2xl border-2 border-espresso px-3.5 py-2.5 shadow-nook-sm space-y-1.5 ${
                            isSelf ? 'bg-mint/25' : 'bg-white'
                          }`}
                        >
                          <div className="text-sm font-black text-espresso leading-snug">
                            {msg.translatedText}
                          </div>
                          <div className="text-xs font-semibold text-espresso-light border-t border-dashed border-espresso/20 pt-1">
                            <div>{msg.originalText}</div>
                            {msg.pronunciation && (
                              <div className="text-[10px] opacity-80 italic mt-0.5">
                                {msg.pronunciation}
                              </div>
                            )}
                          </div>

                          <div className="flex flex-wrap items-center gap-1.5 pt-1">
                            <button
                              type="button"
                              onClick={() => onReplayAudio(msg)}
                              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-cream border border-espresso/40 text-[10px] font-black text-espresso hover:bg-coral/30"
                            >
                              <Volume2 className="w-3 h-3" />
                              <span>播放</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => onRetryTranslate(msg)}
                              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-cream border border-espresso/40 text-[10px] font-black text-espresso hover:bg-mint/30"
                            >
                              <RefreshCw className="w-3 h-3" />
                              <span>重试翻译</span>
                            </button>

                            {msg.culturalTip && (
                              <button
                                type="button"
                                onClick={() => toggleTip(msg.id)}
                                className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-[10px] font-black ${
                                  tipOpen
                                    ? 'bg-coral text-espresso border-espresso'
                                    : 'bg-cream-dark/70 text-espresso border-espresso/40'
                                }`}
                              >
                                <Lightbulb className="w-3 h-3" />
                                <span>文化贴士</span>
                              </button>
                            )}

                            <button
                              type="button"
                              onClick={() =>
                                onExportPostcard({
                                  sender: msg.sender,
                                  receiver: player,
                                  primaryText: msg.translatedText,
                                  secondaryText: msg.originalText,
                                  culturalTip: msg.culturalTip,
                                  roomCode,
                                  timestamp: msg.timestamp,
                                })
                              }
                              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-cream border border-espresso/40 text-[10px] font-black text-espresso hover:bg-mint/30"
                            >
                              <ImageIcon className="w-3 h-3" />
                              <span>明信片</span>
                            </button>
                          </div>

                          {tipOpen && msg.culturalTip && (
                            <div className="mt-1.5 p-2 rounded-xl bg-cream border border-espresso/30 text-[11px] font-bold text-espresso leading-relaxed">
                              {msg.culturalTip}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
