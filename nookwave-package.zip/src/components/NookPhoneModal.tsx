import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Check, Settings, X } from 'lucide-react';
import { IslanderProfile } from '../types/island';
import {
  checkEchoBridgeHealth,
  getEchoBridgeConfig,
  saveEchoBridgeConfig,
} from '../services/echoBridgePipeline';

interface NookPhoneModalProps {
  user: IslanderProfile;
  miles: number;
  roomCode: string;
  onOpenWardrobe: () => void;
  onToggleDecor: () => void;
  onOpenBottles: () => void;
  onOpenDodo: () => void;
  onOpenPassport: () => void;
  onDrawIcebreaker: () => void;
  onSummonBalloon: () => void;
  onShowPreviewToast: (msg: string) => void;
  onClose: () => void;
}

export const NookPhoneModal: React.FC<NookPhoneModalProps> = ({
  user,
  miles,
  roomCode,
  onOpenWardrobe,
  onToggleDecor,
  onOpenBottles,
  onOpenDodo,
  onOpenPassport,
  onDrawIcebreaker,
  onSummonBalloon,
  onShowPreviewToast,
  onClose,
}) => {
  const [ebOnline, setEbOnline] = useState<boolean | null>(null);
  const [showEbConfig, setShowEbConfig] = useState(false);
  const [ebUrl, setEbUrl] = useState(() => getEchoBridgeConfig().backendUrl);
  const [ebKey, setEbKey] = useState(() => getEchoBridgeConfig().dashscopeApiKey);
  const [ebAudio, setEbAudio] = useState(() => getEchoBridgeConfig().enableAudio);

  useEffect(() => {
    void checkEchoBridgeHealth().then(setEbOnline);
  }, []);

  const handleSaveEb = (e: React.FormEvent) => {
    e.preventDefault();
    saveEchoBridgeConfig({ backendUrl: ebUrl, dashscopeApiKey: ebKey, enableAudio: ebAudio });
    setShowEbConfig(false);
    void checkEchoBridgeHealth().then(setEbOnline);
    onShowPreviewToast('✅ EchoBridge 同传引擎配置已保存');
  };
  const apps = [
    {
      id: 'wardrobe',
      emoji: '👕',
      label: '形象DIY',
      bg: 'bg-coral/25',
      action: () => {
        onClose();
        onOpenWardrobe();
      },
    },
    {
      id: 'decor',
      emoji: '🔨',
      label: '岛屿装扮',
      bg: 'bg-mint/25',
      action: () => {
        onClose();
        onToggleDecor();
      },
    },
    {
      id: 'bottles',
      emoji: '🍾',
      label: '海边漂流瓶',
      bg: 'bg-sky-100',
      action: () => {
        onClose();
        onOpenBottles();
      },
    },
    {
      id: 'dodo',
      emoji: '✈️',
      label: 'Dodo联机',
      bg: 'bg-amber-100',
      action: () => {
        onClose();
        onOpenDodo();
      },
    },
    {
      id: 'passport',
      emoji: '🪪',
      label: '护照与好友',
      bg: 'bg-emerald-100',
      action: () => {
        onClose();
        onOpenPassport();
      },
    },
    {
      id: 'dream',
      emoji: '🌙',
      label: '梦境墙',
      bg: 'bg-indigo-100',
      action: () => {
        onClose();
        onShowPreviewToast('🌙 电波梦境墙（DA码异步串门）将在下一阶段接入！');
      },
    },
    {
      id: 'board',
      emoji: '📌',
      label: '公告栏',
      bg: 'bg-orange-100',
      action: () => {
        onClose();
        onShowPreviewToast('📌 码头双语涂鸦公告栏将在下一阶段接入！');
      },
    },
    {
      id: 'icebreaker',
      emoji: '🎲',
      label: '破冰话题',
      bg: 'bg-rose-100',
      action: () => {
        onClose();
        onDrawIcebreaker();
      },
    },
    {
      id: 'balloon',
      emoji: '🎈',
      label: '召唤气球',
      bg: 'bg-yellow-100',
      action: () => {
        onClose();
        onSummonBalloon();
      },
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-espresso/50 backdrop-blur-sm p-4">
      <motion.div
        initial={{ scale: 0.9, y: 20, opacity: 0 }}
        animate={{ scale: 1, y: 0, opacity: 1 }}
        className="w-full max-w-xs bg-cream border-[4px] border-espresso rounded-[2.2rem] shadow-nook-lg overflow-hidden"
      >
        {/* NookPhone Status Bar */}
        <div className="px-5 pt-3 pb-2 bg-cream-dark/70 border-b-2 border-espresso/15 flex items-center justify-between text-[11px] font-black text-espresso">
          <span>📱 NookPhone</span>
          <span>🎫 {miles}</span>
          <button
            type="button"
            onClick={onClose}
            className="w-6 h-6 rounded-full bg-white border-2 border-espresso flex items-center justify-center hover:bg-coral/30"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Island Owner Header */}
        <div className="px-5 pt-3 pb-1 text-center">
          <div className="text-xs font-black text-espresso truncate">
            🏝️ {user.islandName || `${user.name}的电波岛`}
          </div>
          <div className="text-[10px] font-bold text-espresso-light">
            Dodo Code: {roomCode}
          </div>
        </div>

        {/* EchoBridge Real-Time Engine Status Pill */}
        <div className="px-4 pt-2">
          <div className="px-3 py-1.5 rounded-2xl bg-white border-2 border-espresso/30 flex items-center justify-between gap-2 text-[10.5px] font-black">
            <div className="flex items-center gap-1.5 min-w-0">
              <span
                className={`w-2 h-2 rounded-full shrink-0 ${
                  ebOnline === true
                    ? 'bg-sage'
                    : ebOnline === false
                      ? 'bg-coral'
                      : 'bg-espresso-light'
                }`}
              />
              <span className="truncate text-espresso">
                EchoBridge 同传：{ebOnline === true ? '已连接' : ebOnline === false ? '本地兜底中' : '检测中...'}
              </span>
            </div>
            <button
              type="button"
              onClick={() => setShowEbConfig((v) => !v)}
              className="text-espresso-light hover:text-espresso shrink-0"
              title="配置 EchoBridge 同传服务"
            >
              <Settings className="w-3.5 h-3.5" />
            </button>
          </div>

          {showEbConfig && (
            <form
              onSubmit={handleSaveEb}
              className="mt-2 p-2.5 rounded-2xl bg-white border-2 border-espresso space-y-2 text-[11px]"
            >
              <input
                type="text"
                value={ebUrl}
                onChange={(e) => setEbUrl(e.target.value)}
                placeholder="EchoBridge 地址 (默认 http://127.0.0.1:8910)"
                className="w-full px-2.5 py-1 rounded-xl bg-cream border border-espresso font-bold"
              />
              <input
                type="password"
                value={ebKey}
                onChange={(e) => setEbKey(e.target.value)}
                placeholder="DashScope Key (后端已配可留空)"
                className="w-full px-2.5 py-1 rounded-xl bg-cream border border-espresso font-bold"
              />
              <label className="flex items-center gap-1.5 font-bold text-espresso cursor-pointer">
                <input
                  type="checkbox"
                  checked={ebAudio}
                  onChange={(e) => setEbAudio(e.target.checked)}
                />
                <span>开启 24kHz 原声复刻译音播放</span>
              </label>
              <button
                type="submit"
                className="w-full py-1 rounded-xl bg-mint text-espresso font-black nook-btn inline-flex items-center justify-center gap-1"
              >
                <Check className="w-3 h-3" />
                <span>保存并重连检测</span>
              </button>
            </form>
          )}
        </div>

        {/* 3x3 App Grid */}
        <div className="p-4 grid grid-cols-3 gap-3">
          {apps.map((app) => (
            <button
              key={app.id}
              type="button"
              onClick={app.action}
              className="flex flex-col items-center gap-1 group focus:outline-none"
            >
              <div
                className={`w-14 h-14 rounded-2xl ${app.bg} border-2 border-espresso shadow-nook-sm flex items-center justify-center text-2xl group-hover:scale-105 group-active:translate-y-0.5 transition-all`}
              >
                {app.emoji}
              </div>
              <span className="text-[10.5px] font-black text-espresso whitespace-nowrap">
                {app.label}
              </span>
            </button>
          ))}
        </div>

        {/* Home Indicator */}
        <div className="pb-3 pt-1 flex justify-center">
          <div className="w-20 h-1.5 rounded-full bg-espresso/25" />
        </div>
      </motion.div>
    </div>
  );
};
