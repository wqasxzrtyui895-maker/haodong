import { AvatarStyle, IslanderProfile, SpeciesType } from '../types/island';

export interface PostcardPayload {
  sender: IslanderProfile;
  receiver: IslanderProfile;
  primaryText: string;
  secondaryText: string;
  culturalTip?: string;
  roomCode: string;
  timestamp: number;
}

function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
): void {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function wrapLines(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number,
  maxLines: number
): string[] {
  const chars = Array.from(text);
  const lines: string[] = [];
  let current = '';

  for (const ch of chars) {
    const test = current + ch;
    if (ctx.measureText(test).width > maxWidth && current.length > 0) {
      lines.push(current);
      current = ch;
      if (lines.length >= maxLines) break;
    } else {
      current = test;
    }
  }
  if (lines.length < maxLines && current) {
    lines.push(current);
  } else if (lines.length === maxLines && current) {
    lines[maxLines - 1] = lines[maxLines - 1].slice(0, -1) + '…';
  }
  return lines;
}

function drawCanvasAnimal(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  r: number,
  species: SpeciesType,
  color: string,
  avatarStyle?: AvatarStyle
): void {
  const fur = avatarStyle?.furColor || color;
  const headwear = avatarStyle?.headwear || 'none';
  const eyewear = avatarStyle?.eyewear || 'none';

  ctx.save();
  ctx.lineWidth = 4;
  ctx.strokeStyle = '#4A4238';
  ctx.fillStyle = fur;

  // Ears by species
  if (species === 'fennec' || species === 'calico') {
    ctx.beginPath();
    ctx.moveTo(cx - r * 0.72, cy - r * 0.35);
    ctx.lineTo(cx - r * 0.95, cy - r * 1.15);
    ctx.lineTo(cx - r * 0.25, cy - r * 0.8);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(cx + r * 0.72, cy - r * 0.35);
    ctx.lineTo(cx + r * 0.95, cy - r * 1.15);
    ctx.lineTo(cx + r * 0.25, cy - r * 0.8);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  } else if (species === 'shiba' || species === 'tiger') {
    ctx.beginPath();
    ctx.moveTo(cx - r * 0.75, cy - r * 0.45);
    ctx.lineTo(cx - r * 0.65, cy - r * 1.08);
    ctx.lineTo(cx - r * 0.2, cy - r * 0.82);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(cx + r * 0.75, cy - r * 0.45);
    ctx.lineTo(cx + r * 0.65, cy - r * 1.08);
    ctx.lineTo(cx + r * 0.2, cy - r * 0.82);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  } else {
    const earOffset = species === 'koala' ? 0.85 : 0.68;
    const earR = species === 'koala' ? r * 0.38 : r * 0.28;
    ctx.fillStyle = species === 'panda' ? '#4A4238' : fur;
    ctx.beginPath();
    ctx.arc(cx - r * earOffset, cy - r * 0.62, earR, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(cx + r * earOffset, cy - r * 0.62, earR, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  }

  // Head circle
  ctx.fillStyle = species === 'calico' ? '#FAF6EB' : fur;
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Panda eye patches
  if (species === 'panda') {
    ctx.fillStyle = '#4A4238';
    ctx.beginPath();
    ctx.ellipse(cx - r * 0.34, cy - r * 0.08, r * 0.2, r * 0.24, -0.3, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(cx + r * 0.34, cy - r * 0.08, r * 0.2, r * 0.24, 0.3, 0, Math.PI * 2);
    ctx.fill();
  }

  // Snout patch
  ctx.fillStyle = '#FAF6EB';
  ctx.beginPath();
  ctx.ellipse(cx, cy + r * 0.22, r * 0.42, r * 0.3, 0, 0, Math.PI * 2);
  ctx.fill();

  // Eyes
  ctx.fillStyle = species === 'panda' ? '#FAF6EB' : '#4A4238';
  ctx.beginPath();
  ctx.arc(cx - r * 0.32, cy - r * 0.08, r * 0.09, 0, Math.PI * 2);
  ctx.arc(cx + r * 0.32, cy - r * 0.08, r * 0.09, 0, Math.PI * 2);
  ctx.fill();

  // Rosy cheeks
  ctx.fillStyle = eyewear === 'blush' ? 'rgba(242, 132, 130, 0.78)' : 'rgba(244, 162, 97, 0.55)';
  ctx.beginPath();
  ctx.arc(cx - r * 0.52, cy + r * 0.14, r * 0.14, 0, Math.PI * 2);
  ctx.arc(cx + r * 0.52, cy + r * 0.14, r * 0.14, 0, Math.PI * 2);
  ctx.fill();

  // Nose
  ctx.fillStyle = '#4A4238';
  ctx.beginPath();
  ctx.ellipse(cx, cy + r * 0.12, r * 0.11, r * 0.08, 0, 0, Math.PI * 2);
  ctx.fill();

  // Eyewear
  if (eyewear === 'glasses' || eyewear === 'sunglasses') {
    ctx.strokeStyle = '#4A4238';
    ctx.lineWidth = 2.5;
    ctx.fillStyle = eyewear === 'sunglasses' ? '#2F2A24' : 'rgba(255,255,255,0.25)';
    ctx.beginPath();
    ctx.arc(cx - r * 0.32, cy - r * 0.08, r * 0.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(cx + r * 0.32, cy - r * 0.08, r * 0.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  }

  // Headwear
  if (headwear === 'leaf') {
    ctx.fillStyle = '#52B788';
    ctx.strokeStyle = '#4A4238';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.ellipse(cx + r * 0.18, cy - r * 1.08, r * 0.22, r * 0.12, -0.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  } else if (headwear === 'crown') {
    ctx.fillStyle = '#FFE66D';
    ctx.strokeStyle = '#4A4238';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(cx - r * 0.35, cy - r * 0.92);
    ctx.lineTo(cx - r * 0.25, cy - r * 1.25);
    ctx.lineTo(cx, cy - r * 1.05);
    ctx.lineTo(cx + r * 0.25, cy - r * 1.25);
    ctx.lineTo(cx + r * 0.35, cy - r * 0.92);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  } else if (headwear === 'beret') {
    ctx.fillStyle = '#F28482';
    ctx.strokeStyle = '#4A4238';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.ellipse(cx, cy - r * 0.96, r * 0.5, r * 0.22, -0.15, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  } else if (headwear === 'strawHat') {
    ctx.fillStyle = '#E9C46A';
    ctx.strokeStyle = '#4A4238';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.ellipse(cx, cy - r * 0.9, r * 0.72, r * 0.16, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  }

  ctx.restore();
}

export function renderPostcardDataUrl(payload: PostcardPayload): string {
  const width = 1080;
  const height = 680;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  // Outer mint/coral airmail border stripes
  ctx.fillStyle = '#FAF6EB';
  ctx.fillRect(0, 0, width, height);

  const stripeW = 36;
  for (let x = -height; x < width + height; x += stripeW * 2) {
    ctx.fillStyle = '#78C2AD';
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x + stripeW, 0);
    ctx.lineTo(x + stripeW - 24, 24);
    ctx.lineTo(x - 24, 24);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#F4A261';
    ctx.beginPath();
    ctx.moveTo(x + stripeW, 0);
    ctx.lineTo(x + stripeW * 2, 0);
    ctx.lineTo(x + stripeW * 2 - 24, 24);
    ctx.lineTo(x + stripeW - 24, 24);
    ctx.closePath();
    ctx.fill();
  }

  // Inner postcard frame
  ctx.fillStyle = '#FAF6EB';
  ctx.strokeStyle = '#4A4238';
  ctx.lineWidth = 6;
  drawRoundedRect(ctx, 28, 34, width - 56, height - 68, 32);
  ctx.fill();
  ctx.stroke();

  // Subtle paper dots
  ctx.fillStyle = 'rgba(74, 66, 56, 0.045)';
  for (let px = 60; px < width - 60; px += 28) {
    for (let py = 60; py < height - 60; py += 28) {
      ctx.beginPath();
      ctx.arc(px, py, 1.5, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // Header badge: Dodo Air Mail
  ctx.fillStyle = '#78C2AD';
  drawRoundedRect(ctx, 64, 66, 290, 48, 24);
  ctx.fill();
  ctx.strokeStyle = '#4A4238';
  ctx.lineWidth = 3;
  ctx.stroke();

  ctx.fillStyle = '#FAF6EB';
  ctx.font = 'bold 22px system-ui, -apple-system, sans-serif';
  ctx.fillText('✈ NOOKWAVE AIRMAIL', 88, 98);

  // Postmark Stamp on top right
  ctx.save();
  ctx.translate(925, 130);
  ctx.rotate(-0.14);
  ctx.strokeStyle = '#E0843B';
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.arc(0, 0, 62, 0, Math.PI * 2);
  ctx.stroke();
  ctx.setLineDash([5, 5]);
  ctx.beginPath();
  ctx.arc(0, 0, 50, 0, Math.PI * 2);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.fillStyle = '#E0843B';
  ctx.font = 'bold 16px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(payload.sender.city.split('·')[0].trim().toUpperCase(), 0, -8);
  ctx.font = 'bold 20px system-ui, sans-serif';
  ctx.fillText(payload.sender.countryFlag, 0, 18);
  ctx.font = '13px system-ui, sans-serif';
  ctx.fillText(payload.roomCode, 0, 38);
  ctx.restore();

  // Bilingual message card
  ctx.fillStyle = '#FFFFFF';
  ctx.strokeStyle = '#4A4238';
  ctx.lineWidth = 4;
  drawRoundedRect(ctx, 64, 148, 760, 290, 26);
  ctx.fill();
  ctx.stroke();

  // Primary translated quote
  ctx.fillStyle = '#4A4238';
  ctx.font = 'bold 31px "PingFang SC", "Hiragino Sans GB", system-ui, sans-serif';
  const primaryLines = wrapLines(ctx, payload.primaryText, 690, 3);
  primaryLines.forEach((line, idx) => {
    ctx.fillText(line, 98, 212 + idx * 44);
  });

  // Divider dashed line
  ctx.strokeStyle = 'rgba(74, 66, 56, 0.25)';
  ctx.lineWidth = 2;
  ctx.setLineDash([8, 6]);
  ctx.beginPath();
  ctx.moveTo(98, 344);
  ctx.lineTo(788, 344);
  ctx.stroke();
  ctx.setLineDash([]);

  // Secondary original quote
  ctx.fillStyle = '#7A6F62';
  ctx.font = '21px "PingFang SC", system-ui, sans-serif';
  const secLines = wrapLines(ctx, payload.secondaryText, 690, 2);
  secLines.forEach((line, idx) => {
    ctx.fillText(line, 98, 382 + idx * 30);
  });

  // Cultural tip pill if available
  if (payload.culturalTip) {
    ctx.fillStyle = '#EFE7D3';
    drawRoundedRect(ctx, 64, 460, 760, 48, 16);
    ctx.fill();
    ctx.fillStyle = '#4A4238';
    ctx.font = '18px "PingFang SC", system-ui, sans-serif';
    const tipLine = wrapLines(ctx, payload.culturalTip, 720, 1)[0] || '';
    ctx.fillText(tipLine, 84, 491);
  }

  // Both animal avatars on the right / bottom
  drawCanvasAnimal(
    ctx,
    900,
    315,
    44,
    payload.sender.species,
    payload.sender.color,
    payload.sender.avatarStyle
  );
  drawCanvasAnimal(
    ctx,
    975,
    365,
    40,
    payload.receiver.species,
    payload.receiver.color,
    payload.receiver.avatarStyle
  );

  ctx.fillStyle = '#4A4238';
  ctx.font = 'bold 16px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(`${payload.sender.name} × ${payload.receiver.name}`, 936, 434);
  ctx.textAlign = 'left';

  // Footer: Date + Island Name + NookWave Watermark
  const dateStr = new Date(payload.timestamp).toLocaleDateString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  });
  const islandLabel =
    payload.receiver.islandName || payload.sender.islandName || '森友电波岛';
  ctx.fillStyle = '#7A6F62';
  ctx.font = 'bold 20px system-ui, sans-serif';
  ctx.fillText(`📅 ${dateStr}  ·  🏝️ ${islandLabel} (${payload.roomCode})`, 64, 588);

  ctx.fillStyle = '#52B788';
  ctx.font = 'bold 24px system-ui, sans-serif';
  ctx.textAlign = 'right';
  ctx.fillText('🌿 NookWave · 森友电波岛', width - 64, 588);
  ctx.textAlign = 'left';

  return canvas.toDataURL('image/png');
}

export function downloadPostcardPng(dataUrl: string, filename = 'nookwave-postcard.png'): void {
  const link = document.createElement('a');
  link.href = dataUrl;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
