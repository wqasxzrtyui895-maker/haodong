import { ReactionType, SpeciesType } from '../types/island';

class AnimaleseAudioEngine {
  private ctx: AudioContext | null = null;
  private muted = false;
  private activeTimeoutIds: number[] = [];

  private getContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    return this.ctx;
  }

  public async resume(): Promise<void> {
    const ctx = this.getContext();
    if (ctx && ctx.state === 'suspended') {
      try {
        await ctx.resume();
      } catch {
        // Ignore autoplay restriction errors until user gesture
      }
    }
  }

  public setMuted(muted: boolean): void {
    this.muted = muted;
    if (muted) {
      this.stopAll();
    }
  }

  public isMuted(): boolean {
    return this.muted;
  }

  public stopAll(): void {
    for (const id of this.activeTimeoutIds) {
      window.clearTimeout(id);
    }
    this.activeTimeoutIds = [];
  }

  private getSpeciesPitchRange(species: SpeciesType): [number, number] {
    switch (species) {
      case 'fennec':
      case 'calico':
        return [520, 740];
      case 'shiba':
      case 'koala':
      case 'tiger':
        return [340, 480];
      case 'panda':
      case 'capybara':
      case 'polarbear':
        return [210, 310];
      default:
        return [360, 500];
    }
  }

  /**
   * Synthesize cute Animalese-style syllables for a given text and species.
   */
  public speak(text: string, species: SpeciesType = 'shiba'): void {
    if (this.muted || !text.trim()) return;
    const ctx = this.getContext();
    if (!ctx) return;
    if (ctx.state === 'suspended') {
      void ctx.resume();
    }

    this.stopAll();

    const [minFreq, maxFreq] = this.getSpeciesPitchRange(species);
    const trimmed = text.trim();
    const isQuestion = trimmed.endsWith('?') || trimmed.endsWith('？');
    const isExclamation = trimmed.endsWith('!') || trimmed.endsWith('！');
    const hasTilde = trimmed.includes('~') || trimmed.includes('～');

    // Strip spaces and cap syllable count so long messages stay pleasant (~1.6s max)
    const chars = Array.from(trimmed.replace(/\s+/g, '')).slice(0, 18);
    if (chars.length === 0) return;

    const stepMs = 68;
    const now = ctx.currentTime;

    chars.forEach((ch, idx) => {
      const code = ch.charCodeAt(0);
      const ratio = (code % 37) / 36;
      let freq = minFreq + ratio * (maxFreq - minFreq);

      // Emotion intonation adjustments near the end of phrase
      const isNearEnd = idx >= chars.length - 3;
      if (isQuestion && isNearEnd) {
        const progress = (idx - (chars.length - 3)) / 2;
        freq *= 1 + 0.28 * Math.max(0, progress);
      } else if (isExclamation && idx >= chars.length - 2) {
        freq *= idx === chars.length - 1 ? 1.32 : 1.15;
      }

      const startTime = now + idx * (stepMs / 1000);
      const duration = 0.055;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const filter = ctx.createBiquadFilter();

      osc.type =
        species === 'capybara' || species === 'panda' || species === 'polarbear'
          ? 'triangle'
          : 'square';
      osc.frequency.setValueAtTime(freq, startTime);

      if (hasTilde) {
        // Gentle vibrato for '~'
        const lfo = ctx.createOscillator();
        const lfoGain = ctx.createGain();
        lfo.frequency.setValueAtTime(14, startTime);
        lfoGain.gain.setValueAtTime(18, startTime);
        lfo.connect(lfoGain);
        lfoGain.connect(osc.frequency);
        lfo.start(startTime);
        lfo.stop(startTime + duration + 0.02);
      }

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(1800, startTime);

      gain.gain.setValueAtTime(0.001, startTime);
      gain.gain.exponentialRampToValueAtTime(0.085, startTime + 0.012);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc.start(startTime);
      osc.stop(startTime + duration + 0.01);
    });
  }

  /**
   * Cheerful Dodo Airlines seaplane boarding glide + chime.
   */
  public playBoardingSound(): void {
    if (this.muted) return;
    const ctx = this.getContext();
    if (!ctx) return;
    if (ctx.state === 'suspended') {
      void ctx.resume();
    }

    const now = ctx.currentTime;
    const notes = [523.25, 659.25, 783.99, 1046.5]; // C5 E5 G5 C6
    notes.forEach((freq, i) => {
      const t = now + i * 0.085;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq * 0.96, t);
      osc.frequency.exponentialRampToValueAtTime(freq, t + 0.05);

      gain.gain.setValueAtTime(0.001, t);
      gain.gain.exponentialRampToValueAtTime(0.14, t + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.24);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.26);
    });
  }

  /**
   * Shell walkie-talkie chirp when pressing/releasing the mic button.
   */
  public playShellChirp(on: boolean): void {
    if (this.muted) return;
    const ctx = this.getContext();
    if (!ctx) return;
    if (ctx.state === 'suspended') {
      void ctx.resume();
    }

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(on ? 540 : 780, now);
    osc.frequency.exponentialRampToValueAtTime(on ? 880 : 460, now + 0.09);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.exponentialRampToValueAtTime(0.11, now + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.11);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.12);
  }

  /**
   * Crisp "dong-dong" Animal Crossing style furniture placement sound.
   */
  public playBuildSound(): void {
    if (this.muted) return;
    const ctx = this.getContext();
    if (!ctx) return;
    if (ctx.state === 'suspended') {
      void ctx.resume();
    }

    const now = ctx.currentTime;
    [392, 587.33].forEach((freq, i) => {
      const t = now + i * 0.08;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(0.001, t);
      gain.gain.exponentialRampToValueAtTime(0.16, t + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.14);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.16);
    });
  }

  /**
   * Cheerful Nook Miles quest stamp / unlock chime.
   */
  public playQuestCompleteSound(): void {
    if (this.muted) return;
    const ctx = this.getContext();
    if (!ctx) return;
    if (ctx.state === 'suspended') {
      void ctx.resume();
    }
    const now = ctx.currentTime;
    [587.33, 739.99, 880, 1174.66].forEach((freq, i) => {
      const t = now + i * 0.07;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(0.001, t);
      gain.gain.exponentialRampToValueAtTime(0.14, t + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.22);
    });
  }

  /**
   * Crisp "pop!" when popping a floating gift balloon.
   */
  public playBalloonPopSound(): void {
    if (this.muted) return;
    const ctx = this.getContext();
    if (!ctx) return;
    if (ctx.state === 'suspended') {
      void ctx.resume();
    }
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(380, now);
    osc.frequency.exponentialRampToValueAtTime(95, now + 0.09);
    gain.gain.setValueAtTime(0.22, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.11);
  }

  /**
   * Unique sound effect per island reaction.
   */
  public playReactionSound(reaction: ReactionType): void {
    if (this.muted) return;
    const ctx = this.getContext();
    if (!ctx) return;
    if (ctx.state === 'suspended') {
      void ctx.resume();
    }

    const now = ctx.currentTime;
    const playTone = (freq: number, delay: number, dur: number, type: OscillatorType = 'triangle') => {
      const t = now + delay;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(0.001, t);
      gain.gain.exponentialRampToValueAtTime(0.11, t + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.001, t + dur);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + dur + 0.02);
    };

    switch (reaction) {
      case 'clap':
        playTone(420, 0, 0.07, 'square');
        playTone(540, 0.09, 0.07, 'square');
        playTone(640, 0.18, 0.09, 'square');
        break;
      case 'flower':
        playTone(659, 0, 0.14, 'sine');
        playTone(784, 0.08, 0.14, 'sine');
        playTone(988, 0.16, 0.22, 'sine');
        break;
      case 'coffee':
        playTone(392, 0, 0.15, 'triangle');
        playTone(494, 0.12, 0.2, 'triangle');
        break;
      case 'firework':
        playTone(330, 0, 0.12, 'sine');
        playTone(660, 0.1, 0.12, 'sine');
        playTone(1046, 0.18, 0.28, 'triangle');
        break;
      case 'shock':
        playTone(880, 0, 0.08, 'sawtooth');
        playTone(520, 0.07, 0.14, 'sawtooth');
        break;
      case 'dance':
        playTone(523, 0, 0.1, 'triangle');
        playTone(587, 0.1, 0.1, 'triangle');
        playTone(659, 0.2, 0.1, 'triangle');
        playTone(784, 0.3, 0.16, 'triangle');
        break;
    }
  }
}

export const animaleseAudio = new AnimaleseAudioEngine();
